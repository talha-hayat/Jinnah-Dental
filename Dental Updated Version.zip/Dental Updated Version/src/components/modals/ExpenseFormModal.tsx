'use client';

import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

// Types
type ExpenseCategory = 'rent' | 'salary' | 'supplies' | 'utilities' | 'equipment' | 'medication' | 'maintenance' | 'other';
type PaymentMethod = 'cash' | 'card' | 'bank_transfer' | 'cheque' | 'online';

interface Expense {
  id: string;
  title: string;
  amount: number;
  category: ExpenseCategory;
  paymentMethod: PaymentMethod;
  date: string;
  description: string;
  vendor?: string;
  receiptNumber?: string;
  status: 'paid' | 'pending' | 'cancelled';
  createdAt: string;
  updatedAt: string;
  paidBy?: string;
  attachment?: string;
}

// Shared database version
const DATABASE_VERSION = 1; // Version badhao taake upgrade ho

// Main database open function
const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('ClinicDB', DATABASE_VERSION);
    
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      const oldVersion = event.oldVersion || 0;
      console.log(`IndexedDB: Upgrading from v${oldVersion} to v${DATABASE_VERSION}`);
      
      // Sab zaroori stores ko create/check karo
      const requiredStores = [
        'expenses',
        'staff',
        'salaryPayments',
        'attendance',
        'queueItems',
        'users',
        'patients',
        'bills'
      ];
      
      requiredStores.forEach(storeName => {
        if (!db.objectStoreNames.contains(storeName)) {
          console.log(`Creating new store: ${storeName}`);
          db.createObjectStore(storeName, { keyPath: 'id' });
        } else {
          console.log(`Store already exists: ${storeName}`);
        }
      });
    };
    
    request.onsuccess = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      console.log('Database opened. Stores available:', Array.from(db.objectStoreNames));
      resolve(db);
    };
    
    request.onerror = (event) => {
      console.error('Error opening database:', (event.target as IDBOpenDBRequest).error);
      reject((event.target as IDBOpenDBRequest).error);
    };
  });
};

// Initialize database and ensure expenses store exists
const initializeDatabase = async (): Promise<boolean> => {
  try {
    console.log('Initializing database...');
    const db = await openDB();
    const storeNames = Array.from(db.objectStoreNames);
    db.close();
    
    if (storeNames.includes('expenses')) {
      console.log('Expenses store exists');
      return true;
    } else {
      console.warn('Expenses store missing, forcing upgrade...');
      // Force upgrade by reopening with higher version
      return await forceUpgradeDatabase();
    }
  } catch (error) {
    console.error('Database initialization failed:', error);
    return false;
  }
};

// Force database upgrade
const forceUpgradeDatabase = async (): Promise<boolean> => {
  return new Promise((resolve) => {
    // Pehle existing database close karo
    const deleteRequest = indexedDB.deleteDatabase('ClinicDB');
    
    deleteRequest.onsuccess = () => {
      console.log('Old database deleted, creating new one...');
      
      // Naya database banao
      const request = indexedDB.open('ClinicDB', DATABASE_VERSION); // Ek aur version badhao
      
      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        console.log('Creating all required stores in new database...');
        
        // Sab stores create karo
        [
          'expenses',
          'staff',
          'salaryPayments',
          'attendance',
          'queueItems',
          'users'
        ].forEach(storeName => {
          if (!db.objectStoreNames.contains(storeName)) {
            db.createObjectStore(storeName, { keyPath: 'id' });
            console.log(`Created store: ${storeName}`);
          }
        });
      };
      
      request.onsuccess = () => {
        console.log('New database created successfully');
        resolve(true);
      };
      
      request.onerror = () => {
        console.error('Failed to create new database');
        resolve(false);
      };
    };
    
    deleteRequest.onerror = () => {
      console.error('Failed to delete old database');
      resolve(false);
    };
  });
};

// Simple put item function
const putItem = async (storeName: string, item: any): Promise<void> => {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await openDB();
      
      // Check if store exists
      if (!db.objectStoreNames.contains(storeName)) {
        db.close();
        console.error(`Store "${storeName}" not found. Available:`, Array.from(db.objectStoreNames));
        reject(new Error(`Store "${storeName}" does not exist`));
        return;
      }
      
      const transaction = db.transaction(storeName, 'readwrite');
      const store = transaction.objectStore(storeName);
      
      transaction.oncomplete = () => {
        db.close();
        resolve();
      };
      
      transaction.onerror = (event) => {
        db.close();
        reject(transaction.error);
      };
      
      store.put(item);
    } catch (error) {
      reject(error);
    }
  });
};

// Category options
const categoryOptions: { value: ExpenseCategory; label: string }[] = [
  { value: 'rent', label: 'Rent' },
  { value: 'salary', label: 'Salary' },
  { value: 'supplies', label: 'Supplies' },
  { value: 'utilities', label: 'Utilities' },
  { value: 'equipment', label: 'Equipment' },
  { value: 'medication', label: 'Medication' },
  { value: 'maintenance', label: 'Maintenance' },
  { value: 'other', label: 'Other' }
];

// Payment method options
const paymentMethodOptions: { value: PaymentMethod; label: string }[] = [
  { value: 'cash', label: 'Cash' },
  { value: 'card', label: 'Card' },
  { value: 'bank_transfer', label: 'Bank Transfer' },
  { value: 'cheque', label: 'Cheque' },
  { value: 'online', label: 'Online' }
];

// Status options
const statusOptions = [
  { value: 'paid', label: 'Paid' },
  { value: 'pending', label: 'Pending' },
  { value: 'cancelled', label: 'Cancelled' }
];

interface ExpenseFormModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (expenseData: any) => void;
  expense?: Expense | null;
  isEditing?: boolean;
}

export default function ExpenseFormModal({
  open,
  onClose,
  onSubmit,
  expense,
  isEditing = false
}: ExpenseFormModalProps) {
  const [formData, setFormData] = useState({
    title: '',
    amount: '',
    category: 'rent' as ExpenseCategory,
    paymentMethod: 'cash' as PaymentMethod,
    date: new Date().toISOString().split('T')[0],
    description: '',
    vendor: '',
    receiptNumber: '',
    status: 'pending' as 'paid' | 'pending' | 'cancelled',
    paidBy: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [dbInitialized, setDbInitialized] = useState(false);

  // Initialize database on component mount
  useEffect(() => {
    const init = async () => {
      const success = await initializeDatabase();
      setDbInitialized(success);
      if (!success) {
        toast.error('Failed to initialize database. Please refresh page.');
      }
    };
    init();
  }, []);

  useEffect(() => {
    if (expense) {
      setFormData({
        title: expense.title || '',
        amount: expense.amount?.toString() || '',
        category: expense.category || 'rent',
        paymentMethod: expense.paymentMethod || 'cash',
        date: expense.date ? expense.date.split('T')[0] : new Date().toISOString().split('T')[0],
        description: expense.description || '',
        vendor: expense.vendor || '',
        receiptNumber: expense.receiptNumber || '',
        status: expense.status || 'pending',
        paidBy: expense.paidBy || ''
      });
    } else {
      // Reset form for new expense
      setFormData({
        title: '',
        amount: '',
        category: 'rent',
        paymentMethod: 'cash',
        date: new Date().toISOString().split('T')[0],
        description: '',
        vendor: '',
        receiptNumber: '',
        status: 'pending',
        paidBy: ''
      });
    }
  }, [expense]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!dbInitialized) {
      toast.error('Database not ready. Please wait...');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Validate
      if (!formData.title.trim()) {
        toast.error('Title is required');
        setIsSubmitting(false);
        return;
      }
      
      if (!formData.amount || parseFloat(formData.amount) <= 0) {
        toast.error('Valid amount is required');
        setIsSubmitting(false);
        return;
      }
      
      if (!formData.date) {
        toast.error('Date is required');
        setIsSubmitting(false);
        return;
      }
      
      // Prepare expense data
      const expenseData: any = {
        ...formData,
        amount: parseFloat(formData.amount),
        date: new Date(formData.date).toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      // Generate ID
      if (isEditing && expense) {
        expenseData.id = expense.id;
      } else {
        expenseData.id = `exp-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      }
      
      console.log('Saving expense:', expenseData);
      
      // Try to save to IndexedDB
      try {
        await putItem('expenses', expenseData);
        console.log('Expense saved successfully to IndexedDB');
        toast.success('Expense saved successfully');
        
        // Call parent's onSubmit
        onSubmit(expenseData);
        
        // Close modal
        onClose();
        
      } catch (saveError) {
        console.error('Failed to save to IndexedDB:', saveError);
        
        // Agar store nahi hai to database reset karo
        if (saveError.message?.includes('does not exist')) {
          toast.info('Setting up expenses storage... Please try again.');
          setDbInitialized(false);
          const reinit = await initializeDatabase();
          setDbInitialized(reinit);
          
          if (reinit) {
            toast.success('Database ready. Please submit again.');
          } else {
            toast.error('Failed to setup database. Please refresh page.');
          }
        } else {
          toast.error('Failed to save expense: ' + saveError.message);
        }
      }
      
    } catch (error) {
      console.error('Error in form submission:', error);
      toast.error('An unexpected error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // Quick database reset function for emergency
  const handleResetDatabase = async () => {
    if (confirm('This will delete all local data and create fresh database. Continue?')) {
      setIsSubmitting(true);
      try {
        await forceUpgradeDatabase();
        setDbInitialized(true);
        toast.success('Database reset successful');
      } catch (error) {
        toast.error('Failed to reset database');
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-semibold">
            {isEditing ? 'Edit Expense' : 'Add New Expense'}
            {!dbInitialized && (
              <span className="text-xs text-red-600 ml-2">(Database Initializing...)</span>
            )}
          </h2>
          <div className="flex items-center gap-2">
            <button
              onClick={handleResetDatabase}
              className="text-xs px-2 py-1 bg-red-100 text-red-700 rounded hover:bg-red-200"
              title="Reset Database"
            >
              Reset DB
            </button>
            <button
              onClick={onClose}
              className="p-1 hover:bg-gray-100 rounded"
              disabled={isSubmitting}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {/* Title */}
          <div>
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              name="title"
              value={formData.title}
              onChange={handleChange}
              placeholder="e.g., Monthly Rent, Supplies Purchase"
              required
              disabled={isSubmitting}
            />
          </div>

          {/* Amount and Category */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="amount">Amount (USD) *</Label>
              <Input
                id="amount"
                name="amount"
                type="number"
                step="0.01"
                value={formData.amount}
                onChange={handleChange}
                placeholder="0.00"
                min="0.01"
                required
                disabled={isSubmitting}
              />
            </div>
            <div>
              <Label htmlFor="category">Category *</Label>
              <select
                id="category"
                name="category"
                value={formData.category}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg disabled:bg-gray-100 disabled:cursor-not-allowed"
                required
                disabled={isSubmitting}
              >
                {categoryOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Payment Method and Status */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="paymentMethod">Payment Method</Label>
              <select
                id="paymentMethod"
                name="paymentMethod"
                value={formData.paymentMethod}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg disabled:bg-gray-100 disabled:cursor-not-allowed"
                disabled={isSubmitting}
              >
                {paymentMethodOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Label htmlFor="status">Status</Label>
              <select
                id="status"
                name="status"
                value={formData.status}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg disabled:bg-gray-100 disabled:cursor-not-allowed"
                disabled={isSubmitting}
              >
                {statusOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Date and Receipt Number */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="date">Date *</Label>
              <Input
                id="date"
                name="date"
                type="date"
                value={formData.date}
                onChange={handleChange}
                required
                disabled={isSubmitting}
              />
            </div>
            <div>
              <Label htmlFor="receiptNumber">Receipt Number</Label>
              <Input
                id="receiptNumber"
                name="receiptNumber"
                value={formData.receiptNumber}
                onChange={handleChange}
                placeholder="OPT-001"
                disabled={isSubmitting}
              />
            </div>
          </div>

          {/* Vendor and Paid By */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="vendor">Vendor/Supplier</Label>
              <Input
                id="vendor"
                name="vendor"
                value={formData.vendor}
                onChange={handleChange}
                placeholder="Company name"
                disabled={isSubmitting}
              />
            </div>
            <div>
              <Label htmlFor="paidBy">Paid By</Label>
              <Input
                id="paidBy"
                name="paidBy"
                value={formData.paidBy}
                onChange={handleChange}
                placeholder="Person who made payment"
                disabled={isSubmitting}
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              placeholder="Details about this expense..."
              rows={3}
              disabled={isSubmitting}
            />
          </div>

          {/* Buttons */}
          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-green-600 hover:bg-green-700"
              disabled={isSubmitting || !dbInitialized}
            >
              {isSubmitting ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  {isEditing ? 'Updating...' : 'Adding...'}
                </div>
              ) : !dbInitialized ? (
                'Database Not Ready'
              ) : isEditing ? (
                'Update Expense'
              ) : (
                'Add Expense'
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}