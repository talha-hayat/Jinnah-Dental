'use client';

import React, { useState, useEffect } from 'react';
import { X, User, Phone, Calendar, MapPin, Activity, DollarSign, FileText, Edit, Trash2, Clock, UserCheck, AlertCircle, TrendingUp, CreditCard, History, ClipboardList, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Patient, QueueItem, Bill } from '@/types';
import { format, parseISO } from 'date-fns';
import { toast } from 'sonner';

interface PatientDetailsModalProps {
  patient: Patient;
  patientInfo?: Patient | null;
  onClose: () => void;
  onEdit: () => void;
  onDelete: () => void;
  showActions?: boolean;
  // Optional: Pass history data directly if not fetching in modal
  queueHistory?: QueueItem[];
  bills?: Bill[];
}

export default function PatientDetailsModal({
  patient,
  patientInfo,
  onClose,
  onEdit,
  onDelete,
  showActions = true,
  queueHistory = [],
  bills = []
}: PatientDetailsModalProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'queue' | 'bills'>('overview');
  const [loading, setLoading] = useState(false);

  const [history, setHistory] = useState<{
    queueHistory: QueueItem[];
    bills: Bill[];
  }>({
    queueHistory: [],
    bills: []
  });

  // Use props if provided, otherwise fetch
  useEffect(() => {
    // Safer condition: check if props were actually passed
    if (queueHistory !== undefined || bills !== undefined) {
      setHistory({
        queueHistory: queueHistory || [],
        bills: bills || []
      });
    } else {
      // Fallback: fetch data (for backward compatibility)
      fetchPatientHistory();
    }
  }, [queueHistory, bills]);

  const fetchPatientHistory = async () => {
    try {
      setLoading(true);
      // You can keep your fetch logic here if needed
      // For now, we'll use empty arrays since data is passed via props
      setHistory({
        queueHistory: [],
        bills: []
      });
    } catch (error) {
      console.error('Error fetching patient history:', error);
      toast.error('Failed to load patient history');
    } finally {
      setLoading(false);
    }
  };

  // Use patient document data directly for financial overview
  const totalTreatments = patient.totalVisits || 0;
  const totalBilled = patient.totalTreatmentFees || 0;
  const totalPaid = patient.totalPaid || 0;
  const pendingBalance = patient.pendingBalance || 0;
  const openingBalance = patient.openingBalance || 0;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in_treatment': return 'bg-yellow-100 text-yellow-800';
      case 'waiting': return 'bg-blue-100 text-blue-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'bg-green-100 text-green-800';
      case 'partial': return 'bg-yellow-100 text-yellow-800';
      case 'pending': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (amount: number | undefined) => {
    const numAmount = amount || 0;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(numAmount);
  };

  const safeFormatDate = (dateString: string | undefined | null): string => {
    if (!dateString) return 'N/A';

    try {
      const date = parseISO(dateString);
      if (isNaN(date.getTime())) return 'Invalid Date';
      return format(date, 'MMM dd, yyyy hh:mm a');
    } catch {
      try {
        const date = new Date(dateString);
        if (isNaN(date.getTime())) return 'N/A';
        return format(date, 'MMM dd, yyyy hh:mm a');
      } catch {
        return 'N/A';
      }
    }
  };

  if (!patient) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-6xl max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center gap-4">
            <div className="bg-primary/10 p-3 rounded-full">
              <User className="w-8 h-8 text-primary" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">{patient.name || 'N/A'}</h2>
              <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                <span>ID: <strong>{patient.patientNumber || patient.id || 'N/A'}</strong></span>
                <span>•</span>
                <span>Since {safeFormatDate(patient.createdAt)}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {showActions && (
              <>
                <Button variant="outline" size="sm" onClick={onEdit} className="gap-2">
                  <Edit className="w-4 h-4" /> Edit
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onDelete}
                  className="gap-2 border-red-200 text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4" /> Delete
                </Button>
              </>
            )}
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Financial Overview – DIRECT from patient document */}
        <div className="p-6 bg-gray-50 border-b">
          <h3 className="text-lg font-semibold mb-5 flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-primary" />
            Financial Overview
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            <div className="bg-white p-5 rounded-xl border shadow-sm text-center">
              <div className="text-sm text-gray-600 mb-2">Total Treatments</div>
              <div className="text-4xl font-bold text-purple-700">
                {patient.totalVisits || 0}
              </div>
            </div>

            {/* <div className="bg-white p-5 rounded-xl border shadow-sm text-center">
              <div className="text-sm text-gray-600 mb-2">Total Billed</div>
              <div className="text-4xl font-bold text-blue-700">
                {formatCurrency(patient.totalTreatmentFees || 0)}
              </div>
            </div> */}

            <div className="bg-white p-5 rounded-xl border shadow-sm text-center">
              <div className="text-sm text-gray-600 mb-2">Total Paid</div>
              <div className="text-4xl font-bold text-green-700">
                {formatCurrency(patient.totalPaid || 0)}
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border shadow-sm text-center">
              <div className="text-sm text-gray-600 mb-2">Pending Balance</div>
              <div className={`text-4xl font-bold ${
                (patient.pendingBalance || 0) > 0 ? 'text-red-600' :
                (patient.pendingBalance || 0) < 0 ? 'text-blue-600' : 'text-gray-800'
              }`}>
                {formatCurrency(Math.abs(patient.pendingBalance || 0))}
                {(patient.pendingBalance || 0) > 0 && <div className="text-base mt-1">Due</div>}
                {(patient.pendingBalance || 0) < 0 && <div className="text-base mt-1">Credit</div>}
              </div>
            </div>
          </div>

          <div className="mt-4 text-center text-sm text-gray-600">
            Opening Balance: {formatCurrency(patient.openingBalance || 0)}
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b px-6 pt-2">
          <div className="flex space-x-6">
            <button
              className={`pb-3 px-2 font-medium text-sm border-b-2 ${
                activeTab === 'overview' ? 'border-primary text-primary' : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
              onClick={() => setActiveTab('overview')}
            >
              Overview
            </button>
            <button
              className={`pb-3 px-2 font-medium text-sm border-b-2 ${
                activeTab === 'queue' ? 'border-primary text-primary' : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
              onClick={() => setActiveTab('queue')}
            >
              Queue History ({history?.queueHistory?.length || 0})
            </button>
            <button
              className={`pb-3 px-2 font-medium text-sm border-b-2 ${
                activeTab === 'bills' ? 'border-primary text-primary' : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
              onClick={() => setActiveTab('bills')}
            >
              Bills ({history?.bills?.length || 0})
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
              <span className="ml-2">Loading patient history...</span>
            </div>
          ) : (
            <>
              {/* Overview Tab */}
              {activeTab === 'overview' && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Personal Information */}
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <User className="w-5 h-5" /> Personal Information
                    </h3>
                    <div className="space-y-4 bg-gray-50 p-5 rounded-xl border">
                      <div className="flex items-center gap-3">
                        <Phone className="w-5 h-5 text-gray-500" />
                        <div>
                          <div className="text-sm text-gray-600">Phone</div>
                          <div className="font-medium">{patient.phone || 'N/A'}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Calendar className="w-5 h-5 text-gray-500" />
                        <div>
                          <div className="text-sm text-gray-600">Age / Gender</div>
                          <div className="font-medium">{patient.age || 'N/A'} years / {patient.gender || 'N/A'}</div>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <MapPin className="w-5 h-5 text-gray-500 mt-1" />
                        <div>
                          <div className="text-sm text-gray-600">Address</div>
                          <div className="font-medium">{patient.address || 'N/A'}</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Recent Activity */}
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <History className="w-5 h-5" /> Recent Activity
                    </h3>
                    {history?.queueHistory?.length > 0 ? (
                      <div className="space-y-3">
                        {history.queueHistory.slice(0, 3).map(item => (
                          <div key={item.id} className="bg-gray-50 p-4 rounded-xl border">
                            <div className="flex justify-between items-start">
                              <div>
                                <div className="font-medium">{item.treatment || 'Treatment'}</div>
                                <div className="text-sm text-gray-600 mt-1">
                                  {safeFormatDate(item.checkInTime)}
                                </div>
                              </div>
                              <Badge className={getStatusColor(item.status || '')}>
                                {item.status?.replace('_', ' ').toUpperCase()}
                              </Badge>
                            </div>
                            <div className="mt-3 flex justify-between text-sm">
                              <span>Fee: {formatCurrency(item.fee)}</span>
                              <span>Doctor: {item.doctor || 'N/A'}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-10 text-gray-500 bg-gray-50 rounded-xl border">
                        No recent activity
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Queue History Tab */}
              {activeTab === 'queue' && (
                <div className="space-y-6">
                  <h3 className="text-lg font-semibold">Queue History</h3>
                  {history?.queueHistory?.length > 0 ? (
                    <div className="border rounded-xl overflow-hidden">
                      <table className="w-full">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="p-4 text-left text-sm font-medium">Date</th>
                            <th className="p-4 text-left text-sm font-medium">Token</th>
                            <th className="p-4 text-left text-sm font-medium">Treatment</th>
                            <th className="p-4 text-left text-sm font-medium">Status</th>
                            <th className="p-4 text-left text-sm font-medium">Fee</th>
                            <th className="p-4 text-left text-sm font-medium">Doctor</th>
                          </tr>
                        </thead>
                        <tbody>
                          {history.queueHistory.map(item => (
                            <tr key={item.id} className="border-t hover:bg-gray-50">
                              <td className="p-4 text-sm">{safeFormatDate(item.checkInTime)}</td>
                              <td className="p-4 text-sm font-medium">#{item.tokenNumber || '—'}</td>
                              <td className="p-4 text-sm">{item.treatment || '—'}</td>
                              <td className="p-4">
                                <Badge className={getStatusColor(item.status || '')}>
                                  {(item.status || '').replace('_', ' ').toUpperCase()}
                                </Badge>
                              </td>
                              <td className="p-4 text-sm">{formatCurrency(item.fee)}</td>
                              <td className="p-4 text-sm">{item.doctor || 'N/A'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-16 text-gray-500 bg-gray-50 rounded-xl border">
                      No queue history found
                    </div>
                  )}
                </div>
              )}

              {/* Bills Tab */}
              {activeTab === 'bills' && (
                <div className="space-y-6">
                  <h3 className="text-lg font-semibold">Bill History</h3>
                  {history?.bills?.length > 0 ? (
                    <div className="space-y-4">
                      {history.bills.map(bill => (
                        <div key={bill.id} className="border rounded-xl p-5 hover:bg-gray-50">
                          <div className="flex justify-between items-start mb-3">
                            <div>
                              <div className="font-medium flex items-center gap-2">
                                <FileText className="w-4 h-4 text-gray-600" />
                                Bill #{bill.billNumber || '—'}
                              </div>
                              <div className="text-sm text-gray-500 mt-1">
                                {safeFormatDate(bill.createdDate)}
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-xl font-bold text-green-700">
                                {formatCurrency(bill.totalAmount)}
                              </div>
                              <Badge className={`mt-2 ${getPaymentStatusColor(bill.paymentStatus || '')}`}>
                                {bill.paymentStatus?.toUpperCase() || 'UNKNOWN'}
                              </Badge>
                            </div>
                          </div>
                          <div className="text-sm">
                            <div className="font-medium">{bill.treatment || 'General Treatment'}</div>
                            {bill.notes && <div className="text-gray-600 mt-1">{bill.notes}</div>}
                          </div>
                          <div className="mt-3 pt-3 border-t grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-gray-600">Paid:</span>{' '}
                              <span className="font-medium text-green-600">{formatCurrency(bill.amountPaid)}</span>
                            </div>
                            <div className="text-right">
                              <span className="text-gray-600">Method:</span>{' '}
                              <span className="font-medium">{bill.paymentMethod || '—'}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-16 text-gray-500 bg-gray-50 rounded-xl border">
                      No bills generated yet
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t flex justify-between items-center bg-gray-50">
          <div className="text-sm text-gray-600">
            Last updated: {patient.updatedAt ? safeFormatDate(patient.updatedAt) : 'Never'}
          </div>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </div>
      </div>
    </div>
  );
}