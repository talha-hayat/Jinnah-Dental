import { db } from '@/lib/firebase';
import { 
  collection, 
  query, 
  where, 
  getDocs,
  doc, 
  updateDoc,
  serverTimestamp 
} from 'firebase/firestore';

export const syncPatientAfterTreatment = async (patientNumber: string) => {
  try {
    console.log(`Syncing patient ${patientNumber}...`);
    
    // 1. Find patient
    const patientsRef = collection(db, 'patients');
    const patientQuery = query(patientsRef, where('patientNumber', '==', patientNumber));
    const patientSnapshot = await getDocs(patientQuery);
    
    if (patientSnapshot.empty) {
      console.warn(`Patient ${patientNumber} not found`);
      return null;
    }
    
    const patientDoc = patientSnapshot.docs[0];
    const patientId = patientDoc.id;
    const currentPatient = patientDoc.data();
    
    console.log('Current patient data:', currentPatient);
    
    // 2. Get ALL queue items for this patient (including completed, cancelled, etc.)
    const queueRef = collection(db, 'queue');
    const queueQuery = query(queueRef, where('patientNumber', '==', patientNumber));
    const queueSnapshot = await getDocs(queueQuery);
    
    // 3. Get ALL bills for this patient
    const billsRef = collection(db, 'bills');
    const billsQuery = query(billsRef, where('patientId', '==', patientNumber));
    const billsSnapshot = await getDocs(billsQuery);
    
    // 4. DEBUG: Log all data
    const queueItems = queueSnapshot.docs.map(doc => {
      const data = doc.data();
      console.log(`Queue item ${doc.id}:`, {
        fee: data.fee,
        previousPending: data.previousPending,
        amountPaid: data.amountPaid,
        status: data.status
      });
      return data;
    });
    
    const bills = billsSnapshot.docs.map(doc => {
      const data = doc.data();
      console.log(`Bill ${doc.id}:`, {
        amountPaid: data.amountPaid,
        totalAmount: data.totalAmount
      });
      return data;
    });
    
    // 5. CALCULATE CORRECT STATS
    
    // Get opening balance from patient record (or use 0 if not set)
    const openingBalance = currentPatient.openingBalance || 0;
    console.log(`Opening balance: ${openingBalance}`);
    
    // Calculate total treatment fees (only from completed treatments)
    const completedTreatments = queueItems.filter((item: any) => 
      item.status === 'completed' || item.status === 'in_treatment'
    );
    
    const totalTreatmentFees = completedTreatments.reduce(
      (sum: number, item: any) => sum + (parseFloat(item.fee) || 0), 
      0
    );
    console.log(`Total treatment fees: ${totalTreatmentFees}`);
    
    // Calculate total paid from ALL sources
    // First from queue items (amountPaid field)
    const totalPaidFromQueue = queueItems.reduce(
      (sum: number, item: any) => sum + (parseFloat(item.amountPaid) || 0), 
      0
    );
    
    // Then from bills
    const totalPaidFromBills = bills.reduce(
      (sum: number, bill: any) => sum + (parseFloat(bill.amountPaid) || 0), 
      0
    );
    
    const totalPaid = totalPaidFromQueue + totalPaidFromBills;
    console.log(`Total paid: ${totalPaid} (queue: ${totalPaidFromQueue}, bills: ${totalPaidFromBills})`);
    
    // Calculate total due and pending balance
    const totalDue = openingBalance + totalTreatmentFees;
    const pendingBalance = totalDue - totalPaid;
    
    console.log('CALCULATION SUMMARY:');
    console.log(`- Opening Balance: ${openingBalance}`);
    console.log(`- Total Treatments: ${totalTreatmentFees}`);
    console.log(`- Total Due: ${totalDue}`);
    console.log(`- Total Paid: ${totalPaid}`);
    console.log(`- Pending Balance: ${pendingBalance}`);
    
    // Count total visits (completed treatments)
    const totalVisits = completedTreatments.length;
    
    // Find most recent visit
    const lastVisit = completedTreatments.length > 0 
      ? completedTreatments.sort((a: any, b: any) => {
          const dateA = new Date(a.treatmentEndTime || a.checkInTime || 0).getTime();
          const dateB = new Date(b.treatmentEndTime || b.checkInTime || 0).getTime();
          return dateB - dateA;
        })[0]?.treatmentEndTime || completedTreatments[0]?.checkInTime
      : undefined;
    
    // 6. Update patient with CORRECT values
    const updateData = {
      totalVisits,
      totalPaid,
      pendingBalance,
      ...(lastVisit && { lastVisit }),
      updatedAt: serverTimestamp()
    };
    
    console.log('Updating patient with:', updateData);
    
    await updateDoc(doc(db, 'patients', patientId), updateData);
    
    return {
      ...updateData,
      openingBalance,
      totalTreatmentFees,
      totalDue
    };
  } catch (error) {
    console.error('Error syncing patient:', error);
    throw error;
  }
};