'use client';

import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  UserCog, 
  Edit, 
  DollarSign, 
  Phone, 
  Mail, 
  Calendar,
  Clock,
  Briefcase,
  Trash2,
  Filter,
  X,
  TrendingUp,
  CalendarDays
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';
import StaffFormModal from '@/components/modals/StaffFormModal';
import StaffDetailsModal from '@/components/modals/StaffDetailsModal';
import PaySalaryModal from '@/components/modals/PaySalaryModal';
import { Staff, SalaryPayment } from '@/types';

// Helper functions
const calculatePendingSalary = (staffMember: Staff): number => {
  if (!staffMember.joinDate) return staffMember.salary;
  
  const joinDate = new Date(staffMember.joinDate);
  const today = new Date();
  
  // If join date is in future, no pending salary
  if (joinDate > today) return 0;
  
  const timeDiff = today.getTime() - joinDate.getTime();
  const daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
  
  const workingDaysPerWeek = staffMember.workingDaysPerWeek || 6;
  const weeksInMonth = 4.33;
  
  switch(staffMember.salaryDuration) {
    case 'daily':
      // Calculate only working days
      const workingDaysSinceJoining = Math.floor(daysDiff * (workingDaysPerWeek / 7));
      return Math.round(workingDaysSinceJoining * staffMember.salary);
    
    case 'weekly':
      const weeksSinceJoining = daysDiff / 7;
      return Math.round(weeksSinceJoining * staffMember.salary);
    
    case 'monthly':
    default:
      const monthsSinceJoining = daysDiff / 30; // Approximate
      return Math.round(monthsSinceJoining * staffMember.salary);
  }
};

const calculateNextSalaryDate = (staffMember: Staff): string => {
  if (!staffMember.lastSalaryDate) {
    // If no salary paid yet, next salary is based on join date
    const joinDate = new Date(staffMember.joinDate);
    const nextDate = new Date(joinDate);
    
    switch(staffMember.salaryDuration) {
      case 'daily':
        nextDate.setDate(joinDate.getDate() + 1);
        break;
      case 'weekly':
        nextDate.setDate(joinDate.getDate() + 7);
        break;
      case 'monthly':
        nextDate.setMonth(joinDate.getMonth() + 1);
        break;
    }
    return nextDate.toISOString().split('T')[0];
  }
  
  const lastSalaryDate = new Date(staffMember.lastSalaryDate);
  const nextDate = new Date(lastSalaryDate);
  
  switch(staffMember.salaryDuration) {
    case 'daily':
      nextDate.setDate(lastSalaryDate.getDate() + 1);
      break;
    case 'weekly':
      nextDate.setDate(lastSalaryDate.getDate() + 7);
      break;
    case 'monthly':
      nextDate.setMonth(lastSalaryDate.getMonth() + 1);
      break;
  }
  
  return nextDate.toISOString().split('T')[0];
};

const formatPeriod = (staffMember: Staff): string => {
  if (!staffMember.joinDate) return 'N/A';
  
  const joinDate = new Date(staffMember.joinDate);
  const today = new Date();
  
  const timeDiff = today.getTime() - joinDate.getTime();
  const daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24));
  
  switch(staffMember.salaryDuration) {
    case 'daily':
      return `Day ${daysDiff + 1}`;
    
    case 'weekly':
      const weeks = Math.floor(daysDiff / 7);
      return `Week ${weeks + 1}`;
    
    case 'monthly':
      const months = Math.floor(daysDiff / 30);
      return `Month ${months + 1}`;
    
    default:
      return 'N/A';
  }
};

// Mock staff data with salary duration
const initialStaff: Staff[] = [
  { 
    id: '1', 
    name: 'Dr. John Smith', 
    role: 'Dentist', 
    phone: '+1 234-567-8901', 
    email: 'john.smith@clinic.com',
    status: 'Active',
    salary: 5000,
    salaryDuration: 'monthly',
    joinDate: '2023-01-15',
    address: '123 Main St, New York',
    specialization: 'General Dentistry',
    experience: '5 years',
    pendingSalary: 5000,
    totalPaid: 15000,
    workingDaysPerWeek: 6,
    lastSalaryDate: '2024-01-01',
    nextSalaryDate: '2024-02-01'
  },
  { 
    id: '2', 
    name: 'Dr. Sarah Williams', 
    role: 'Orthodontist', 
    phone: '+1 234-567-8902', 
    email: 'sarah.w@clinic.com',
    status: 'Active',
    salary: 1200,
    salaryDuration: 'weekly',
    joinDate: '2023-03-20',
    address: '456 Oak Ave, Chicago',
    specialization: 'Braces & Aligners',
    experience: '7 years',
    pendingSalary: 2400,
    totalPaid: 31200,
    workingDaysPerWeek: 5,
    lastSalaryDate: '2024-01-22',
    nextSalaryDate: '2024-01-29'
  },
  { 
    id: '3', 
    name: 'Emily Brown', 
    role: 'Dental Hygienist', 
    phone: '+1 234-567-8903', 
    email: 'emily.b@clinic.com',
    status: 'Active',
    salary: 200,
    salaryDuration: 'daily',
    joinDate: '2023-06-10',
    address: '789 Pine Rd, Miami',
    specialization: 'Teeth Cleaning',
    experience: '3 years',
    pendingSalary: 1400,
    totalPaid: 14400,
    workingDaysPerWeek: 6,
    lastSalaryDate: '2024-01-26',
    nextSalaryDate: '2024-01-27'
  },
  { 
    id: '4', 
    name: 'Mike Johnson', 
    role: 'Assistant', 
    phone: '+1 234-567-8904', 
    email: 'mike.j@clinic.com',
    status: 'On Leave',
    salary: 1800,
    salaryDuration: 'monthly',
    joinDate: '2023-08-05',
    address: '101 Elm St, Boston',
    specialization: 'Patient Assistance',
    experience: '2 years',
    pendingSalary: 1800,
    totalPaid: 9000,
    workingDaysPerWeek: 6,
    lastSalaryDate: '2023-12-01',
    nextSalaryDate: '2024-02-01'
  },
];

// Mock salary payments with period types
const initialSalaryPayments: SalaryPayment[] = [
  {
    id: 's1',
    staffId: '1',
    staffName: 'Dr. John Smith',
    amount: 5000,
    date: '2024-01-01',
    period: 'Month 13',
    periodType: 'monthly',
    status: 'paid',
    paymentMethod: 'bank',
    notes: 'Monthly salary for January 2024',
    startDate: '2024-01-01',
    endDate: '2024-01-31'
  },
  {
    id: 's2',
    staffId: '2',
    staffName: 'Dr. Sarah Williams',
    amount: 1200,
    date: '2024-01-22',
    period: 'Week 45',
    periodType: 'weekly',
    status: 'paid',
    paymentMethod: 'cash',
    notes: 'Weekly salary',
    startDate: '2024-01-15',
    endDate: '2024-01-21'
  },
  {
    id: 's3',
    staffId: '3',
    staffName: 'Emily Brown',
    amount: 1200,
    date: '2024-01-26',
    period: 'Day 230-235',
    periodType: 'daily',
    status: 'paid',
    paymentMethod: 'bank',
    notes: '6 days salary',
    startDate: '2024-01-20',
    endDate: '2024-01-25'
  },
];

export default function AdminStaff() {
  const [staff, setStaff] = useState<Staff[]>(initialStaff.map(s => ({
    ...s,
    pendingSalary: calculatePendingSalary(s),
    nextSalaryDate: calculateNextSalaryDate(s)
  })));
  
  const [salaryPayments, setSalaryPayments] = useState<SalaryPayment[]>(initialSalaryPayments);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRole, setSelectedRole] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedDuration, setSelectedDuration] = useState('all');
  const [showStaffForm, setShowStaffForm] = useState(false);
  const [showStaffDetails, setShowStaffDetails] = useState<Staff | null>(null);
  const [showPaySalary, setShowPaySalary] = useState<Staff | null>(null);
  const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  // Filter staff
  const filteredStaff = staff.filter(member => {
    const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         member.phone.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         member.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRole = selectedRole === 'all' || member.role === selectedRole;
    const matchesStatus = selectedStatus === 'all' || member.status === selectedStatus;
    const matchesDuration = selectedDuration === 'all' || member.salaryDuration === selectedDuration;
    
    return matchesSearch && matchesRole && matchesStatus && matchesDuration;
  });

  // Get unique values
  const roles = Array.from(new Set(staff.map(s => s.role)));
  const statuses = Array.from(new Set(staff.map(s => s.status)));
  const durations = Array.from(new Set(staff.map(s => s.salaryDuration)));

  // Handle add/edit staff
  const handleStaffSubmit = async (staffData: Partial<Staff>) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const salaryAmount = Number(staffData.salary) || 0;
    const joinDate = staffData.joinDate || new Date().toISOString().split('T')[0];
    
    if (isEditing && selectedStaff) {
      const updatedStaff = {
        ...selectedStaff,
        ...staffData,
        salary: salaryAmount,
        salaryDuration: staffData.salaryDuration || 'monthly',
        workingDaysPerWeek: Number(staffData.workingDaysPerWeek) || 6,
        pendingSalary: calculatePendingSalary({
          ...selectedStaff,
          ...staffData,
          salary: salaryAmount,
          salaryDuration: staffData.salaryDuration || 'monthly',
          joinDate: joinDate
        } as Staff),
        nextSalaryDate: calculateNextSalaryDate({
          ...selectedStaff,
          ...staffData,
          salaryDuration: staffData.salaryDuration || 'monthly',
          lastSalaryDate: selectedStaff.lastSalaryDate || joinDate
        } as Staff)
      };
      
      setStaff(prev => prev.map(s => 
        s.id === selectedStaff.id ? updatedStaff : s
      ));
      toast.success(`${staffData.name} updated successfully`);
    } else {
      const newStaff: Staff = {
        id: String(staff.length + 1),
        name: staffData.name || '',
        role: staffData.role || '',
        phone: staffData.phone || '',
        email: staffData.email || '',
        status: 'Active',
        salary: salaryAmount,
        salaryDuration: staffData.salaryDuration || 'monthly',
        joinDate: joinDate,
        address: staffData.address || '',
        specialization: staffData.specialization || '',
        experience: staffData.experience || '',
        pendingSalary: salaryAmount, // First month/week/day salary pending
        totalPaid: 0,
        workingDaysPerWeek: Number(staffData.workingDaysPerWeek) || 6,
        lastSalaryDate: joinDate,
        nextSalaryDate: calculateNextSalaryDate({
          salaryDuration: staffData.salaryDuration || 'monthly',
          lastSalaryDate: joinDate,
          joinDate: joinDate
        } as Staff)
      };
      
      setStaff(prev => [...prev, newStaff]);
      toast.success(`${staffData.name} added to staff`);
    }
    
    setShowStaffForm(false);
    setSelectedStaff(null);
  };

  // Handle delete staff
  const handleDeleteStaff = async (staffMember: Staff) => {
    if (confirm(`Delete ${staffMember.name} from staff?`)) {
      await new Promise(resolve => setTimeout(resolve, 300));
      setStaff(prev => prev.filter(s => s.id !== staffMember.id));
      toast.success(`${staffMember.name} deleted`);
    }
  };

  // Handle pay salary
  const handlePaySalary = async (staffMember: Staff, paymentData: any) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const paymentDate = new Date();
    const period = formatPeriod(staffMember);
    
    // Calculate period start and end dates
    let startDate = new Date();
    let endDate = new Date();
    
    switch(staffMember.salaryDuration) {
      case 'daily':
        startDate.setDate(paymentDate.getDate() - 1);
        break;
      case 'weekly':
        startDate.setDate(paymentDate.getDate() - 7);
        break;
      case 'monthly':
        startDate.setMonth(paymentDate.getMonth() - 1);
        break;
    }
    
    // Update staff
    setStaff(prev => prev.map(s => {
      if (s.id === staffMember.id) {
        const newPending = Math.max(0, s.pendingSalary - paymentData.amount);
        const newTotalPaid = s.totalPaid + paymentData.amount;
        
        return {
          ...s,
          pendingSalary: newPending,
          totalPaid: newTotalPaid,
          lastSalaryDate: paymentDate.toISOString().split('T')[0],
          nextSalaryDate: calculateNextSalaryDate({
            ...s,
            lastSalaryDate: paymentDate.toISOString().split('T')[0],
            salaryDuration: s.salaryDuration
          })
        };
      }
      return s;
    }));
    
    // Add payment record
    const newPayment: SalaryPayment = {
      id: `s${salaryPayments.length + 1}`,
      staffId: staffMember.id,
      staffName: staffMember.name,
      amount: paymentData.amount,
      date: paymentDate.toISOString().split('T')[0],
      period: period,
      periodType: staffMember.salaryDuration,
      status: 'paid',
      paymentMethod: paymentData.paymentMethod,
      notes: paymentData.notes,
      startDate: startDate.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0]
    };
    
    setSalaryPayments(prev => [...prev, newPayment]);
    toast.success(`Salary paid for ${period} - $${paymentData.amount}`);
    setShowPaySalary(null);
  };

  // Calculate stats
  const totalStaff = staff.length;
  const activeStaff = staff.filter(s => s.status === 'Active').length;
  
  const totalPendingSalary = staff.reduce((sum, s) => sum + s.pendingSalary, 0);
  const totalPaidSalary = staff.reduce((sum, s) => sum + s.totalPaid, 0);
  
  // Calculate monthly equivalent salary for all staff
  const totalMonthlyEquivalent = staff.reduce((sum, s) => {
    let monthlyEquivalent = s.salary;
    switch(s.salaryDuration) {
      case 'daily':
        monthlyEquivalent = s.salary * (s.workingDaysPerWeek || 6) * 4.33;
        break;
      case 'weekly':
        monthlyEquivalent = s.salary * 4.33;
        break;
    }
    return sum + monthlyEquivalent;
  }, 0);

  // Calculate salary by duration
  const salaryByDuration = {
    daily: staff.filter(s => s.salaryDuration === 'daily').reduce((sum, s) => sum + s.pendingSalary, 0),
    weekly: staff.filter(s => s.salaryDuration === 'weekly').reduce((sum, s) => sum + s.pendingSalary, 0),
    monthly: staff.filter(s => s.salaryDuration === 'monthly').reduce((sum, s) => sum + s.pendingSalary, 0)
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Staff Management</h1>
          <p className="text-muted-foreground">
            Total: {totalStaff} staff • Active: {activeStaff} • Monthly Budget: ${totalMonthlyEquivalent.toFixed(2)}
          </p>
        </div>
        <Button 
          onClick={() => {
            setSelectedStaff(null);
            setIsEditing(false);
            setShowStaffForm(true);
          }}
          className="gap-2 bg-gradient-to-r from-blue-600 to-blue-700"
        >
          <Plus className="w-4 h-4" />
          Add New Staff
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-blue-700">{totalStaff}</div>
              <div className="text-sm text-blue-600 font-medium">Total Staff</div>
            </div>
            <UserCog className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-green-700">${totalPendingSalary.toFixed(2)}</div>
              <div className="text-sm text-green-600 font-medium">Pending Salary</div>
            </div>
            <TrendingUp className="w-8 h-8 text-green-600" />
          </div>
        </div>
        
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-purple-700">${totalPaidSalary.toFixed(2)}</div>
              <div className="text-sm text-purple-600 font-medium">Total Paid</div>
            </div>
            <DollarSign className="w-8 h-8 text-purple-600" />
          </div>
        </div>
        
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-yellow-700">{activeStaff}</div>
              <div className="text-sm text-yellow-600 font-medium">Active Staff</div>
            </div>
            <Briefcase className="w-8 h-8 text-yellow-600" />
          </div>
        </div>
      </div>

      {/* Pending Salary by Duration */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-red-50 border border-red-200 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-lg font-bold text-red-700">${salaryByDuration.daily.toFixed(2)}</div>
              <div className="text-sm text-red-600">Daily Pending</div>
            </div>
            <CalendarDays className="w-6 h-6 text-red-600" />
          </div>
        </div>
        
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-lg font-bold text-orange-700">${salaryByDuration.weekly.toFixed(2)}</div>
              <div className="text-sm text-orange-600">Weekly Pending</div>
            </div>
            <Calendar className="w-6 h-6 text-orange-600" />
          </div>
        </div>
        
        <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-lg font-bold text-indigo-700">${salaryByDuration.monthly.toFixed(2)}</div>
              <div className="text-sm text-indigo-600">Monthly Pending</div>
            </div>
            <Clock className="w-6 h-6 text-indigo-600" />
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search by name, phone, or email..." 
              className="pl-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} className="absolute right-3 top-1/2 -translate-y-1/2">
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            )}
          </div>
          <Button variant="outline" onClick={() => {
            setSearchTerm('');
            setSelectedRole('all');
            setSelectedStatus('all');
            setSelectedDuration('all');
          }}>
            Clear Filters
          </Button>
        </div>

        <div className="flex flex-wrap gap-3">
          <select
            value={selectedRole}
            onChange={(e) => setSelectedRole(e.target.value)}
            className="px-3 py-2 border rounded-lg"
          >
            <option value="all">All Roles</option>
            {roles.map(role => (
              <option key={role} value={role}>{role}</option>
            ))}
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 border rounded-lg"
          >
            <option value="all">All Status</option>
            {statuses.map(status => (
              <option key={status} value={status}>{status}</option>
            ))}
          </select>

          <select
            value={selectedDuration}
            onChange={(e) => setSelectedDuration(e.target.value)}
            className="px-3 py-2 border rounded-lg"
          >
            <option value="all">All Durations</option>
            {durations.map(duration => (
              <option key={duration} value={duration}>
                {duration.charAt(0).toUpperCase() + duration.slice(1)}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Staff Cards */}
      {filteredStaff.length === 0 ? (
        <div className="text-center py-12 border-2 border-dashed border-gray-200 rounded-lg">
          <UserCog className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No staff members found</p>
          <p className="text-sm text-gray-400 mt-1">Try adjusting your search or filters</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredStaff.map((staffMember) => (
            <Card 
              key={staffMember.id} 
              className="hover:shadow-lg transition-shadow cursor-pointer group"
              onDoubleClick={() => setShowStaffDetails(staffMember)}
            >
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                    <UserCog className="w-6 h-6 text-blue-600" />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-bold text-lg">{staffMember.name}</p>
                        <div className="flex items-center gap-2">
                          <Briefcase className="w-3 h-3 text-muted-foreground" />
                          <span className="text-sm text-blue-600 font-medium">{staffMember.role}</span>
                        </div>
                      </div>
                      <Badge className={
                        staffMember.status === 'Active' ? 'bg-green-100 text-green-800' :
                        staffMember.status === 'On Leave' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }>
                        {staffMember.status}
                      </Badge>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Phone className="w-3 h-3 text-muted-foreground" />
                        <span>{staffMember.phone}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Mail className="w-3 h-3 text-muted-foreground" />
                        <span>{staffMember.email}</span>
                      </div>
                      
                      {/* Salary Info */}
                      <div className="border-t pt-2 mt-2">
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-2">
                            <DollarSign className="w-3 h-3 text-muted-foreground" />
                            <span className="font-medium">${staffMember.salary}</span>
                          </div>
                          <Badge className="text-xs bg-blue-100 text-blue-800">
                            {staffMember.salaryDuration}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">Pending:</span>
                          <span className={`font-medium ${staffMember.pendingSalary > 0 ? 'text-red-600' : 'text-green-600'}`}>
                            ${staffMember.pendingSalary.toFixed(2)}
                          </span>
                        </div>
                        
                        {staffMember.nextSalaryDate && (
                          <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                            <Calendar className="w-3 h-3" />
                            <span>Next: {new Date(staffMember.nextSalaryDate).toLocaleDateString()}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-2 mt-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedStaff(staffMember);
                          setIsEditing(true);
                          setShowStaffForm(true);
                        }}
                        className="gap-1"
                      >
                        <Edit className="w-3 h-3" />
                        Edit
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          setShowPaySalary(staffMember);
                        }}
                        className="gap-1 text-green-600 border-green-200 hover:bg-green-50"
                        disabled={staffMember.pendingSalary <= 0}
                      >
                        <DollarSign className="w-3 h-3" />
                        Pay Salary
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteStaff(staffMember);
                        }}
                        className="gap-1 text-red-600 border-red-200 hover:bg-red-50"
                      >
                        <Trash2 className="w-3 h-3" />
                        Delete
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Recent Salary Payments */}
      {salaryPayments.length > 0 && (
        <div className="bg-white rounded-lg border p-4">
          <h3 className="font-semibold mb-3">Recent Salary Payments</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Date</th>
                  <th className="text-left p-2">Staff</th>
                  <th className="text-left p-2">Period</th>
                  <th className="text-left p-2">Type</th>
                  <th className="text-left p-2">Amount</th>
                  <th className="text-left p-2">Method</th>
                </tr>
              </thead>
              <tbody>
                {salaryPayments.slice(0, 5).map(payment => (
                  <tr key={payment.id} className="border-b hover:bg-gray-50">
                    <td className="p-2">{new Date(payment.date).toLocaleDateString()}</td>
                    <td className="p-2 font-medium">{payment.staffName}</td>
                    <td className="p-2">
                      <Badge className="bg-blue-100 text-blue-800 text-xs">
                        {payment.period}
                      </Badge>
                    </td>
                    <td className="p-2">
                      <Badge className={
                        payment.periodType === 'daily' ? 'bg-green-100 text-green-800' :
                        payment.periodType === 'weekly' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-purple-100 text-purple-800'
                      }>
                        {payment.periodType}
                      </Badge>
                    </td>
                    <td className="p-2 font-medium">${payment.amount}</td>
                    <td className="p-2">
                      <span className="px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-800">
                        {payment.paymentMethod}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modals */}
      <StaffFormModal
        open={showStaffForm}
        onClose={() => {
          setShowStaffForm(false);
          setSelectedStaff(null);
        }}
        onSubmit={handleStaffSubmit}
        staff={selectedStaff}
        isEditing={isEditing}
      />

      <StaffDetailsModal
        open={!!showStaffDetails}
        onClose={() => setShowStaffDetails(null)}
        staff={showStaffDetails}
        salaryPayments={salaryPayments.filter(p => p.staffId === showStaffDetails?.id)}
        onEdit={() => {
          if (showStaffDetails) {
            setSelectedStaff(showStaffDetails);
            setIsEditing(true);
            setShowStaffForm(true);
            setShowStaffDetails(null);
          }
        }}
        onDelete={handleDeleteStaff}
        onPaySalary={() => {
          if (showStaffDetails) {
            setShowPaySalary(showStaffDetails);
            setShowStaffDetails(null);
          }
        }}
      />

      <PaySalaryModal
        open={!!showPaySalary}
        onClose={() => setShowPaySalary(null)}
        staff={showPaySalary}
        onSubmit={handlePaySalary}
      />
    </div>
  );
}