import React, { useState, useEffect } from 'react';
import { Plus, Search, Filter, AlertTriangle, Package, Edit, Trash2, X, Save, TrendingDown, Receipt } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from '@/hooks/use-toast';

// Local storage keys
const INVENTORY_STORAGE_KEY = 'dental-inventory-data';
const SALES_STORAGE_KEY = 'dental-sales-data';

const defaultInventory = [
  { id: '1', name: 'Composite Resin', sku: 'CR-001', quantity: 5, min: 20, category: 'Materials', expiry: '2024-06', price: 25.99 },
  { id: '2', name: 'Dental Gloves (M)', sku: 'DG-002', quantity: 12, min: 50, category: 'Supplies', expiry: '2025-01', price: 8.99 },
  { id: '3', name: 'Anesthetic Cartridges', sku: 'AC-003', quantity: 8, min: 30, category: 'Anesthetics', expiry: '2024-08', price: 12.50 },
  { id: '4', name: 'Dental Mirrors', sku: 'DM-004', quantity: 45, min: 20, category: 'Instruments', expiry: '', price: 15.75 },
  { id: '5', name: 'Cotton Rolls', sku: 'CT-005', quantity: 200, min: 100, category: 'Supplies', expiry: '2025-03', price: 4.99 },
];

const categories = ['Materials', 'Supplies', 'Anesthetics', 'Instruments', 'Equipment', 'Medications'];

export default function AdminInventory() {
  // State management
  const [inventory, setInventory] = useState([]);
  const [sales, setSales] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isSellDialogOpen, setIsSellDialogOpen] = useState(false);
  const [selectedItemForSale, setSelectedItemForSale] = useState(null);
  const [editingItem, setEditingItem] = useState(null);
  const [lowStockItems, setLowStockItems] = useState([]);
  const [activeTab, setActiveTab] = useState('inventory');
  const [saleQuantity, setSaleQuantity] = useState(1);
  const [saleNotes, setSaleNotes] = useState('');

  // Form state for new item
  const [newItem, setNewItem] = useState({
    name: '',
    sku: '',
    quantity: 0,
    min: 0,
    category: 'Supplies',
    expiry: '',
    price: 0
  });

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedInventory = localStorage.getItem(INVENTORY_STORAGE_KEY);
    const savedSales = localStorage.getItem(SALES_STORAGE_KEY);
    
    if (savedInventory) {
      setInventory(JSON.parse(savedInventory));
    } else {
      setInventory(defaultInventory);
    }
    
    if (savedSales) {
      setSales(JSON.parse(savedSales));
    }
  }, []);

  // Save to localStorage whenever inventory or sales change
  useEffect(() => {
    localStorage.setItem(INVENTORY_STORAGE_KEY, JSON.stringify(inventory));
    localStorage.setItem(SALES_STORAGE_KEY, JSON.stringify(sales));
    
    // Update low stock items
    const lowStock = inventory.filter(item => item.quantity < item.min);
    setLowStockItems(lowStock);
  }, [inventory, sales]);

  // Filter inventory based on search and category
  const filteredInventory = inventory.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.sku.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Calculate total sales value
  const totalSalesValue = sales.reduce((total, sale) => total + (sale.price * sale.quantity), 0);

  // CRUD Operations for Inventory
  const handleAddItem = () => {
    if (!newItem.name || !newItem.sku) {
      toast({
        title: "Validation Error",
        description: "Name and SKU are required fields.",
        variant: "destructive"
      });
      return;
    }

    const newItemWithId = {
      ...newItem,
      id: Date.now().toString(),
      quantity: parseInt(newItem.quantity) || 0,
      min: parseInt(newItem.min) || 0,
      price: parseFloat(newItem.price) || 0
    };

    setInventory([...inventory, newItemWithId]);
    setNewItem({ name: '', sku: '', quantity: 0, min: 0, category: 'Supplies', expiry: '', price: 0 });
    setIsAddDialogOpen(false);
    
    toast({
      title: "Success",
      description: "Item added to inventory successfully.",
    });
  };

  const handleEditItem = (item) => {
    setEditingItem({ ...item });
    setIsEditDialogOpen(true);
  };

  const handleSaveEdit = () => {
    if (!editingItem.name || !editingItem.sku) {
      toast({
        title: "Validation Error",
        description: "Name and SKU are required fields.",
        variant: "destructive"
      });
      return;
    }

    setInventory(inventory.map(item => 
      item.id === editingItem.id ? { 
        ...editingItem,
        quantity: parseInt(editingItem.quantity) || 0,
        min: parseInt(editingItem.min) || 0,
        price: parseFloat(editingItem.price) || 0
      } : item
    ));
    
    setIsEditDialogOpen(false);
    setEditingItem(null);
    
    toast({
      title: "Success",
      description: "Item updated successfully.",
    });
  };

  const handleDeleteItem = (id) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      setInventory(inventory.filter(item => item.id !== id));
      toast({
        title: "Deleted",
        description: "Item removed from inventory.",
      });
    }
  };

  // Sales Operations
  const handleSellItem = (item) => {
    setSelectedItemForSale(item);
    setSaleQuantity(1);
    setSaleNotes('');
    setIsSellDialogOpen(true);
  };

  const handleConfirmSale = () => {
    if (!selectedItemForSale) return;

    const quantityToSell = parseInt(saleQuantity) || 1;
    
    if (quantityToSell <= 0) {
      toast({
        title: "Invalid Quantity",
        description: "Please enter a valid quantity greater than 0.",
        variant: "destructive"
      });
      return;
    }

    if (quantityToSell > selectedItemForSale.quantity) {
      toast({
        title: "Insufficient Stock",
        description: `Only ${selectedItemForSale.quantity} units available.`,
        variant: "destructive"
      });
      return;
    }

    // Create sale record
    const saleRecord = {
      id: Date.now().toString(),
      itemId: selectedItemForSale.id,
      itemName: selectedItemForSale.name,
      sku: selectedItemForSale.sku,
      quantity: quantityToSell,
      price: selectedItemForSale.price,
      total: selectedItemForSale.price * quantityToSell,
      date: new Date().toISOString(),
      notes: saleNotes,
      soldBy: "Admin" // You can make this dynamic based on logged in user
    };

    // Update sales records
    setSales([saleRecord, ...sales]);

    // Update inventory quantity
    setInventory(inventory.map(item => 
      item.id === selectedItemForSale.id 
        ? { ...item, quantity: item.quantity - quantityToSell }
        : item
    ));

    // Reset and close dialog
    setIsSellDialogOpen(false);
    setSelectedItemForSale(null);
    setSaleQuantity(1);
    setSaleNotes('');

    toast({
      title: "Sale Recorded",
      description: `${quantityToSell} unit(s) of ${selectedItemForSale.name} sold successfully.`,
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewItem(prev => ({ ...prev, [name]: value }));
  };

  const handleEditInputChange = (e) => {
    const { name, value } = e.target;
    setEditingItem(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Inventory Management</h1>
          <p className="text-muted-foreground">Track and manage clinic supplies</p>
          {lowStockItems.length > 0 && (
            <div className="mt-2 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-destructive" />
              <span className="text-sm text-destructive">
                {lowStockItems.length} item(s) below minimum stock
              </span>
            </div>
          )}
        </div>
        <Button className="gap-2" onClick={() => setIsAddDialogOpen(true)}>
          <Plus className="w-4 h-4" />
          Add Item
        </Button>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full md:w-auto grid-cols-2">
          <TabsTrigger value="inventory">Inventory</TabsTrigger>
          <TabsTrigger value="sales">Sales History</TabsTrigger>
        </TabsList>

        {/* Inventory Tab */}
        <TabsContent value="inventory" className="space-y-6">
          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Search inventory..." 
                className="pl-9"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="All">All Categories</SelectItem>
                  {categories.map(category => (
                    <SelectItem key={category} value={category}>{category}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button variant="outline" className="gap-2" onClick={() => {
                setSearchTerm('');
                setSelectedCategory('All');
              }}>
                <X className="w-4 h-4" />
                Clear
              </Button>
            </div>
          </div>

          {/* Inventory Table */}
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border bg-muted/30">
                      <th className="text-left p-4 font-medium text-muted-foreground">Item</th>
                      <th className="text-left p-4 font-medium text-muted-foreground">SKU</th>
                      <th className="text-left p-4 font-medium text-muted-foreground">Category</th>
                      <th className="text-center p-4 font-medium text-muted-foreground">Quantity</th>
                      <th className="text-center p-4 font-medium text-muted-foreground">Price</th>
                      <th className="text-center p-4 font-medium text-muted-foreground">Status</th>
                      <th className="text-left p-4 font-medium text-muted-foreground">Expiry</th>
                      <th className="text-left p-4 font-medium text-muted-foreground">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {filteredInventory.map((item) => {
                      const isLow = item.quantity < item.min;
                      const isOutOfStock = item.quantity === 0;
                      return (
                        <tr key={item.id} className="hover:bg-muted/30 transition-colors">
                          <td className="p-4">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                                <Package className="w-4 h-4 text-primary" />
                              </div>
                              <span className="font-medium">{item.name}</span>
                            </div>
                          </td>
                          <td className="p-4 text-muted-foreground">{item.sku}</td>
                          <td className="p-4">
                            <Badge variant="secondary">{item.category}</Badge>
                          </td>
                          <td className="p-4 text-center">
                            <span className={isLow ? 'text-destructive font-semibold' : isOutOfStock ? 'text-muted-foreground' : ''}>
                              {item.quantity}
                            </span>
                            <span className="text-muted-foreground"> / {item.min}</span>
                          </td>
                          <td className="p-4 text-center">
                            ${item.price.toFixed(2)}
                          </td>
                          <td className="p-4 text-center">
                            {isOutOfStock ? (
                              <Badge className="bg-muted text-muted-foreground border-muted">
                                Out of Stock
                              </Badge>
                            ) : isLow ? (
                              <Badge className="bg-destructive/10 text-destructive border-destructive/20">
                                <AlertTriangle className="w-3 h-3 mr-1" />
                                Low Stock
                              </Badge>
                            ) : (
                              <Badge className="bg-success/10 text-success border-success/20">
                                In Stock
                              </Badge>
                            )}
                          </td>
                          <td className="p-4 text-muted-foreground">
                            {item.expiry || 'N/A'}
                          </td>
                          <td className="p-4">
                            <div className="flex gap-2">
                              <Button 
                                variant="outline" 
                                size="sm" 
                                className="h-8 gap-1"
                                onClick={() => handleSellItem(item)}
                                disabled={item.quantity === 0}
                              >
                                <TrendingDown className="w-3 h-3" />
                                Sell
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="h-8 w-8 p-0"
                                onClick={() => handleEditItem(item)}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                                onClick={() => handleDeleteItem(item.id)}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                {filteredInventory.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    No items found. Try adjusting your search or add a new item.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Sales Tab */}
        <TabsContent value="sales" className="space-y-6">
          {/* Sales Summary */}
          <Card>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-muted/30 p-4 rounded-lg">
                  <div className="text-sm text-muted-foreground">Total Sales</div>
                  <div className="text-2xl font-bold">${totalSalesValue.toFixed(2)}</div>
                </div>
                <div className="bg-muted/30 p-4 rounded-lg">
                  <div className="text-sm text-muted-foreground">Items Sold</div>
                  <div className="text-2xl font-bold">
                    {sales.reduce((total, sale) => total + sale.quantity, 0)}
                  </div>
                </div>
                <div className="bg-muted/30 p-4 rounded-lg">
                  <div className="text-sm text-muted-foreground">Total Transactions</div>
                  <div className="text-2xl font-bold">{sales.length}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Sales Table */}
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Item</TableHead>
                      <TableHead>SKU</TableHead>
                      <TableHead className="text-center">Quantity</TableHead>
                      <TableHead className="text-right">Price</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                      <TableHead>Sold By</TableHead>
                      <TableHead>Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sales.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                          <Receipt className="w-12 h-12 mx-auto mb-2 opacity-50" />
                          <div>No sales records found</div>
                        </TableCell>
                      </TableRow>
                    ) : (
                      sales.map((sale) => (
                        <TableRow key={sale.id}>
                          <TableCell>
                            {new Date(sale.date).toLocaleDateString()}
                          </TableCell>
                          <TableCell className="font-medium">{sale.itemName}</TableCell>
                          <TableCell>{sale.sku}</TableCell>
                          <TableCell className="text-center">{sale.quantity}</TableCell>
                          <TableCell className="text-right">${sale.price.toFixed(2)}</TableCell>
                          <TableCell className="text-right font-semibold">
                            ${sale.total.toFixed(2)}
                          </TableCell>
                          <TableCell>{sale.soldBy}</TableCell>
                          <TableCell className="text-muted-foreground">
                            {sale.notes || '-'}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add Item Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Inventory Item</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Item Name *</Label>
              <Input
                id="name"
                name="name"
                value={newItem.name}
                onChange={handleInputChange}
                placeholder="Enter item name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sku">SKU *</Label>
              <Input
                id="sku"
                name="sku"
                value={newItem.sku}
                onChange={handleInputChange}
                placeholder="Enter SKU"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="quantity">Current Quantity</Label>
                <Input
                  id="quantity"
                  name="quantity"
                  type="number"
                  value={newItem.quantity}
                  onChange={handleInputChange}
                  min="0"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="min">Minimum Stock</Label>
                <Input
                  id="min"
                  name="min"
                  type="number"
                  value={newItem.min}
                  onChange={handleInputChange}
                  min="0"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="price">Price ($)</Label>
                <Input
                  id="price"
                  name="price"
                  type="number"
                  step="0.01"
                  value={newItem.price}
                  onChange={handleInputChange}
                  min="0"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select 
                  value={newItem.category} 
                  onValueChange={(value) => setNewItem(prev => ({ ...prev, category: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(category => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="expiry">Expiry Date (YYYY-MM)</Label>
              <Input
                id="expiry"
                name="expiry"
                value={newItem.expiry}
                onChange={handleInputChange}
                placeholder="2024-12"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddItem}>
              <Save className="w-4 h-4 mr-2" />
              Add Item
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Item Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Inventory Item</DialogTitle>
          </DialogHeader>
          {editingItem && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Item Name *</Label>
                <Input
                  id="edit-name"
                  name="name"
                  value={editingItem.name}
                  onChange={handleEditInputChange}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-sku">SKU *</Label>
                <Input
                  id="edit-sku"
                  name="sku"
                  value={editingItem.sku}
                  onChange={handleEditInputChange}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-quantity">Current Quantity</Label>
                  <Input
                    id="edit-quantity"
                    name="quantity"
                    type="number"
                    value={editingItem.quantity}
                    onChange={handleEditInputChange}
                    min="0"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-min">Minimum Stock</Label>
                  <Input
                    id="edit-min"
                    name="min"
                    type="number"
                    value={editingItem.min}
                    onChange={handleEditInputChange}
                    min="0"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-price">Price ($)</Label>
                  <Input
                    id="edit-price"
                    name="price"
                    type="number"
                    step="0.01"
                    value={editingItem.price}
                    onChange={handleEditInputChange}
                    min="0"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-category">Category</Label>
                  <Select 
                    value={editingItem.category} 
                    onValueChange={(value) => setEditingItem(prev => ({ ...prev, category: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(category => (
                        <SelectItem key={category} value={category}>{category}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-expiry">Expiry Date (YYYY-MM)</Label>
                <Input
                  id="edit-expiry"
                  name="expiry"
                  value={editingItem.expiry}
                  onChange={handleEditInputChange}
                  placeholder="2024-12"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveEdit}>
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Sell Item Dialog */}
      <Dialog open={isSellDialogOpen} onOpenChange={setIsSellDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Sell Item</DialogTitle>
            <DialogDescription>
              Record a sale for {selectedItemForSale?.name}
            </DialogDescription>
          </DialogHeader>
          {selectedItemForSale && (
            <div className="space-y-4 py-4">
              <div className="bg-muted/30 p-4 rounded-lg space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Available Stock:</span>
                  <span className={`font-semibold ${selectedItemForSale.quantity < selectedItemForSale.min ? 'text-destructive' : ''}`}>
                    {selectedItemForSale.quantity} units
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Price per unit:</span>
                  <span className="font-semibold">${selectedItemForSale.price.toFixed(2)}</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="sale-quantity">Quantity to Sell *</Label>
                <Input
                  id="sale-quantity"
                  type="number"
                  value={saleQuantity}
                  onChange={(e) => setSaleQuantity(e.target.value)}
                  min="1"
                  max={selectedItemForSale.quantity}
                />
                <p className="text-xs text-muted-foreground">
                  Maximum available: {selectedItemForSale.quantity} units
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="sale-notes">Notes (Optional)</Label>
                <Input
                  id="sale-notes"
                  value={saleNotes}
                  onChange={(e) => setSaleNotes(e.target.value)}
                  placeholder="Add any notes about this sale"
                />
              </div>
              
              <div className="bg-primary/5 p-4 rounded-lg space-y-2">
                <div className="flex justify-between">
                  <span>Total Amount:</span>
                  <span className="text-xl font-bold text-primary">
                    ${(selectedItemForSale.price * (parseInt(saleQuantity) || 0)).toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>Remaining stock after sale:</span>
                  <span>
                    {selectedItemForSale.quantity - (parseInt(saleQuantity) || 0)} units
                  </span>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsSellDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleConfirmSale}>
              <TrendingDown className="w-4 h-4 mr-2" />
              Confirm Sale
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}