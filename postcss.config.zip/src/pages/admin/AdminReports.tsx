import React from 'react';
import { FileText, Download, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const reportTypes = [
  { name: 'Daily Summary', description: 'Overview of daily operations and revenue' },
  { name: 'Monthly Financial', description: 'Detailed financial statement' },
  { name: 'Patient Statistics', description: 'Patient demographics and visit patterns' },
  { name: 'Inventory Report', description: 'Stock levels and usage trends' },
  { name: 'Staff Performance', description: 'Doctor and staff productivity metrics' },
];

export default function AdminReports() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold">Reports</h1>
        <p className="text-muted-foreground">Generate and download clinic reports</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {reportTypes.map((report) => (
          <Card key={report.name}>
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-lg bg-primary/10">
                  <FileText className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold">{report.name}</h3>
                  <p className="text-sm text-muted-foreground mt-1">{report.description}</p>
                  <Button variant="outline" size="sm" className="mt-4 gap-2">
                    <Download className="w-4 h-4" />
                    Generate
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
