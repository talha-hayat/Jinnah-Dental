import React from 'react';
import { DollarSign, TrendingUp, TrendingDown, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { StatCard } from '@/components/dashboard/StatCard';

export default function AdminFinances() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Financial Overview</h1>
          <p className="text-muted-foreground">Track revenue, expenses, and profit</p>
        </div>
        <Button variant="outline" className="gap-2">
          <Download className="w-4 h-4" />
          Export Report
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Revenue"
          value="$45,230"
          subtitle="This month"
          icon={DollarSign}
          trend={{ value: 12.5, isPositive: true }}
          variant="primary"
        />
        <StatCard
          title="Total Expenses"
          value="$18,420"
          subtitle="This month"
          icon={TrendingDown}
          trend={{ value: 5.2, isPositive: false }}
          variant="warning"
        />
        <StatCard
          title="Net Profit"
          value="$26,810"
          subtitle="This month"
          icon={TrendingUp}
          trend={{ value: 18.3, isPositive: true }}
          variant="success"
        />
        <StatCard
          title="Outstanding"
          value="$3,450"
          subtitle="Pending collection"
          icon={DollarSign}
          variant="info"
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-center py-8">
            Transaction history will appear here
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
