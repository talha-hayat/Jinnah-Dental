import React from 'react';
import { 
  DollarSign, 
  Users, 
  TrendingUp, 
  TrendingDown, 
  Package, 
  AlertTriangle,
  Calendar,
  Receipt
} from 'lucide-react';
import { StatCard } from '@/components/dashboard/StatCard';
import { RecentPatients } from '@/components/dashboard/RecentPatients';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

// Demo data for charts
const revenueData = [
  { name: 'Mon', revenue: 4200, expenses: 2100 },
  { name: 'Tue', revenue: 3800, expenses: 1800 },
  { name: 'Wed', revenue: 5100, expenses: 2300 },
  { name: 'Thu', revenue: 4600, expenses: 1900 },
  { name: 'Fri', revenue: 6200, expenses: 2500 },
  { name: 'Sat', revenue: 5400, expenses: 2200 },
  { name: 'Sun', revenue: 0, expenses: 500 },
];

const treatmentData = [
  { name: 'Root Canal', value: 35, color: 'hsl(187, 72%, 38%)' },
  { name: 'Filling', value: 25, color: 'hsl(152, 69%, 40%)' },
  { name: 'Cleaning', value: 20, color: 'hsl(38, 92%, 50%)' },
  { name: 'Extraction', value: 12, color: 'hsl(210, 92%, 45%)' },
  { name: 'Other', value: 8, color: 'hsl(340, 65%, 55%)' },
];

const lowStockItems = [
  { name: 'Composite Resin', current: 5, min: 20 },
  { name: 'Dental Gloves (M)', current: 12, min: 50 },
  { name: 'Anesthetic Cartridges', current: 8, min: 30 },
];

export default function AdminDashboard() {
  return (
    <div className="space-y-6 animate-fade-in">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        <p className="text-muted-foreground">Overview of clinic performance and finances</p>
      </div>

      {/* Financial Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Revenue"
          value="$45,230"
          subtitle="This month"
          icon={DollarSign}
          trend={{ value: 12.5, isPositive: true }}
          variant="primary"
        />
        <StatCard
          title="Total Expenses"
          value="$18,420"
          subtitle="This month"
          icon={TrendingDown}
          trend={{ value: 5.2, isPositive: false }}
          variant="warning"
        />
        <StatCard
          title="Net Profit"
          value="$26,810"
          subtitle="This month"
          icon={TrendingUp}
          trend={{ value: 18.3, isPositive: true }}
          variant="success"
        />
        <StatCard
          title="Outstanding Dues"
          value="$3,450"
          subtitle="From 12 patients"
          icon={Receipt}
          variant="info"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base font-semibold">Weekly Revenue vs Expenses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="expenses" fill="hsl(var(--warning))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Treatment Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold">Treatment Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={treatmentData}
                    innerRadius={50}
                    outerRadius={70}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {treatmentData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 space-y-2">
              {treatmentData.map((item) => (
                <div key={item.name} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-muted-foreground">{item.name}</span>
                  </div>
                  <span className="font-medium">{item.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Patients */}
        <RecentPatients />

        {/* Low Stock Alerts */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-warning" />
              Low Stock Alerts
            </CardTitle>
            <Badge variant="destructive">{lowStockItems.length}</Badge>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {lowStockItems.map((item) => (
                <div key={item.name} className="flex items-center justify-between p-3 rounded-lg bg-warning/5 border border-warning/20">
                  <div>
                    <p className="font-medium text-sm">{item.name}</p>
                    <p className="text-xs text-muted-foreground">
                      Min. required: {item.min} units
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-warning">{item.current}</p>
                    <p className="text-xs text-muted-foreground">in stock</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
