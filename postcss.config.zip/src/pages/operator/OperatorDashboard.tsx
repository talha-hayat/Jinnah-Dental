'use client';

import React, { useState, useEffect } from 'react';
import { 
  Users, Calendar, Clock, CheckCircle2, UserPlus, Activity, 
  Loader2, User, Eye, PlusCircle 
} from 'lucide-react';
import { StatCard } from '@/components/dashboard/StatCard';
import QueueSection  from '@/components/dashboard/QueueSection';
import { CalendarWidget } from '@/components/dashboard/CalendarWidget';
import { Button } from '@/components/ui/button';
import { QueueItem, Patient } from '@/types';
import { toast } from 'sonner';
import { 
  getAllQueueItems, 
  updateQueueItem, 
  deleteQueueItem,
  getTodayTokenCount 
} from '@/services/queueService';
import PatientModal from '@/components/modals/PatientFormModal';
import { addPatient, getAllPatients } from '@/services/patientService';

const doctors = ['Dr. Smith', 'Dr. Johnson', 'Dr. Wilson', 'Dr. Brown', 'Dr. Taylor'];
const treatments = [
  'General Checkup', 
  'Teeth Cleaning', 
  'Filling', 
  'Root Canal', 
  'X-Ray', 
  'Consultation',
  'Teeth Whitening',
  'Extraction',
  'Crown Fitting'
];

export default function OperatorDashboard() {
  const [queueData, setQueueData] = useState<QueueItem[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [showPatientModal, setShowPatientModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingQueue, setLoadingQueue] = useState(true);
  const [loadingPatients, setLoadingPatients] = useState(true);
  const [todayTokenCount, setTodayTokenCount] = useState(0);
  const [savingPatient, setSavingPatient] = useState(false);

  // Firebase se data fetch karna
  useEffect(() => {
    fetchQueueData();
    fetchPatientsData();
    fetchTodayTokenCount();
  }, []);

  const fetchQueueData = async () => {
    try {
      setLoadingQueue(true);
      const data = await getAllQueueItems();
      setQueueData(data);
    } catch (error) {
      console.error('Error fetching queue data:', error);
      toast.error('Failed to load queue data');
    } finally {
      setLoadingQueue(false);
    }
  };

  const fetchPatientsData = async () => {
    try {
      setLoadingPatients(true);
      const data = await getAllPatients();
      setPatients(data);
    } catch (error) {
      console.error('Error fetching patients:', error);
      toast.error('Failed to load patients');
    } finally {
      setLoadingPatients(false);
    }
  };

  const fetchTodayTokenCount = async () => {
    try {
      const count = await getTodayTokenCount();
      setTodayTokenCount(count);
    } catch (error) {
      console.error('Error fetching today token count:', error);
    }
  };

  const waitingPatients = queueData.filter(p => p.status === 'waiting');
  const inTreatmentPatients = queueData.filter(p => p.status === 'in-treatment');
  const completedPatients = queueData.filter(p => p.status === 'completed');

  // ✅ YEH NAYA FUNCTION HAI: New Patient save karna
  const handleSavePatient = async (patientData: any) => {
    try {
      setSavingPatient(true);

      // Add new patient to Firebase
      const newPatientData = {
        name: patientData.name,
        phone: patientData.phone,
        age: Number(patientData.age),
        gender: patientData.gender,
        address: patientData.address,
        medicalHistory: patientData.medicalHistory,
        createdAt: new Date().toISOString()
      };

      const newPatientId = await addPatient(newPatientData);

      // Update local state with new patient
      const newPatient: Patient = {
        id: newPatientId,
        ...newPatientData
      };
      
      setPatients(prev => [newPatient, ...prev]);
      
      // Automatically patient ko queue mein add karna (optional)
      // await addPatientToQueue(newPatient);
      
      toast.success(`${patientData.name} successfully registered`);
      setShowPatientModal(false);
      
    } catch (error) {
      console.error('Error saving patient:', error);
      toast.error('Failed to save patient. Please try again.');
    } finally {
      setSavingPatient(false);
    }
  };

  // ✅ OPTIONAL: Patient ko automatically queue mein add karna
  const addPatientToQueue = async (patient: Patient) => {
    try {
      const newTokenNumber = todayTokenCount + 1;
      
      const queueItemData = {
        patientId: patient.id,
        patientName: patient.name,
        phone: patient.phone,
        tokenNumber: newTokenNumber,
        status: 'waiting' as const,
        checkInTime: new Date().toISOString(),
        treatment: 'Consultation', // Default treatment
        doctor: doctors[0], // Default doctor
      };

      // Add to queue service (agar aap chahte hain)
      // await addQueueItem(queueItemData);
      
      toast.info(`${patient.name} added to queue with token #${newTokenNumber}`);
      
      // Refresh data
      await fetchQueueData();
      await fetchTodayTokenCount();
      
    } catch (error) {
      console.error('Error adding to queue:', error);
    }
  };

  const handleQueueAction = async (item: QueueItem, action: string) => {
    setIsLoading(true);
    
    try {
      const now = new Date().toISOString();
      
      if (action === 'start-treatment') {
        await updateQueueItem(item.id, {
          status: 'in-treatment',
          treatmentStartTime: now
        });
        
        toast.success(`Started treatment for ${item.patientName}`);
      }
      
      if (action === 'complete') {
        await updateQueueItem(item.id, {
          status: 'completed',
          treatmentEndTime: now
        });
        
        toast.success(`Completed treatment for ${item.patientName}`);
      }
      
      if (action === 'cancel') {
        await updateQueueItem(item.id, {
          status: 'cancelled',
          cancelledAt: now
        });
        
        toast.info(`Cancelled ${item.patientName}'s treatment`);
      }
      
      // Refresh queue data
      await fetchQueueData();
    } catch (error) {
      console.error('Error performing queue action:', error);
      toast.error('Failed to update queue');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddPatient = () => {
    // Patient modal open karna
    setShowPatientModal(true);
  };

  // const handleAddQuickPatient = async () => {
  //   // Quick patient add (demo purpose)
  //   setIsLoading(true);
    
  //   try {
  //     const names = ['Alex Turner', 'Sophia Martinez', 'David Kim', 'Emma Wilson', 'Raj Patel'];
  //     const randomName = names[Math.floor(Math.random() * names.length)];
  //     const randomPhone = '+1' + Math.floor(Math.random() * 900000000 + 100000000);
      
  //     const newPatientData = {
  //       name: randomName,
  //       phone: randomPhone,
  //       age: Math.floor(Math.random() * 60) + 20,
  //       gender: Math.random() > 0.5 ? 'Male' : 'Female',
  //       address: 'Demo Address',
  //       medicalHistory: 'No known allergies',
  //       createdAt: new Date().toISOString()
  //     };

  //     const newPatientId = await addPatient(newPatientData);
      
  //     const newPatient: Patient = {
  //       id: newPatientId,
  //       ...newPatientData
  //     };
      
  //     setPatients(prev => [newPatient, ...prev]);
  //     toast.success(`Quick patient ${randomName} added`);
      
  //   } catch (error) {
  //     console.error('Error adding quick patient:', error);
  //     toast.error('Failed to add patient');
  //   } finally {
  //     setIsLoading(false);
  //   }
  // };

  const handleTransferPatient = async (item: QueueItem, newDoctor: string) => {
    try {
      await updateQueueItem(item.id, {
        doctor: newDoctor
      });
      
      // Refresh data
      await fetchQueueData();
      
      toast.info(`Transferred ${item.patientName} to ${newDoctor}`);
    } catch (error) {
      console.error('Error transferring patient:', error);
      toast.error('Failed to transfer patient');
    }
  };

  const handleRemoveFromQueue = async (item: QueueItem) => {
    if (confirm(`Are you sure you want to remove ${item.patientName} from the queue?`)) {
      try {
        await deleteQueueItem(item.id);
        
        // Refresh data
        await fetchQueueData();
        
        toast.info(`Removed ${item.patientName} from queue`);
      } catch (error) {
        console.error('Error removing from queue:', error);
        toast.error('Failed to remove from queue');
      }
    }
  };

  const getNextTokenNumber = () => {
    if (queueData.length === 0) return 1;
    const maxToken = queueData.reduce((max, item) => 
      item.tokenNumber > max ? item.tokenNumber : max, 0
    );
    return maxToken + 1;
  };

  const handleStartAllWaiting = async () => {
    if (waitingPatients.length === 0) {
      toast.warning("No waiting patients");
      return;
    }

    setIsLoading(true);
    
    try {
      const now = new Date().toISOString();
      
      // Sabhi waiting patients ko start karna
      const updatePromises = waitingPatients.map(patient =>
        updateQueueItem(patient.id, {
          status: 'in-treatment',
          treatmentStartTime: now
        })
      );
      
      await Promise.all(updatePromises);
      
      // Refresh data
      await fetchQueueData();
      
      toast.success(`Started treatment for ${waitingPatients.length} patients`);
    } catch (error) {
      console.error('Error starting all patients:', error);
      toast.error('Failed to start treatments');
    } finally {
      setIsLoading(false);
    }
  };

  const handleStartNextPatient = async () => {
    if (waitingPatients.length === 0) {
      toast.warning("No waiting patients");
      return;
    }
    
    const nextPatient = waitingPatients[0];
    await handleQueueAction(nextPatient, 'start-treatment');
  };

  // const handleViewPatients = () => {
  //   // Patients page pe redirect karna
  //   window.location.href = '/dashboard/patients';
  // };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold">Operator Dashboard</h1>
            {loadingQueue && (
              <Loader2 className="w-4 h-4 animate-spin text-primary" />
            )}
          </div>
          <p className="text-muted-foreground">Manage queue and patient registration</p>
        </div>
        <div className="flex flex-wrap gap-3">
          {/* <Button 
            variant="outline" 
            className="gap-2"
            onClick={handleViewPatients}
            disabled={loadingPatients}
          >
            <Eye className="w-4 h-4" />
            View All Patients
          </Button> */}
          {/* <Button 
            variant="outline" 
            className="gap-2"
            onClick={handleAddQuickPatient}
            disabled={isLoading || loadingPatients}
          >
            <PlusCircle className="w-4 h-4" />
            Quick Add Patient
          </Button> */}
          <Button 
            className="gap-2 bg-gradient-to-r from-blue-600 to-blue-700"
            onClick={handleAddPatient}
            disabled={isLoading}
          >
            <User className="w-4 h-4" />
            Register New Patient
          </Button>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Patients"
          value={patients.length}
          subtitle="Registered patients"
          icon={Users}
          variant="info"
        />
        <StatCard
          title="Waiting Patients"
          value={waitingPatients.length}
          subtitle="In queue"
          icon={Clock}
          variant="warning"
          trend={waitingPatients.length > 2 ? "high" : "low"}
        />
        <StatCard
          title="In Treatment"
          value={inTreatmentPatients.length}
          subtitle="Currently being treated"
          icon={Activity}
          variant="primary"
        />
        <StatCard
          title="Completed Today"
          value={completedPatients.length}
          subtitle="Finished treatments"
          icon={CheckCircle2}
          variant="success"
          trend={completedPatients.length > 3 ? "high" : "low"}
        />
      </div>

      {/* Quick Actions Bar */}
      <div className="flex flex-wrap gap-2 p-3 bg-gray-50 rounded-lg">
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => {
            const nextToken = getNextTokenNumber();
            toast.info(`Next token number: ${nextToken}`);
          }}
          disabled={loadingQueue}
        >
          Check Next Token
        </Button>
        <Button 
          variant="outline" 
          size="sm"
          onClick={handleStartAllWaiting}
          disabled={isLoading || loadingQueue || waitingPatients.length === 0}
        >
          Start All Waiting
        </Button>
        <Button 
          variant="outline" 
          size="sm"
          onClick={handleStartNextPatient}
          disabled={isLoading || loadingQueue || waitingPatients.length === 0}
        >
          Start Next Patient
        </Button>
        <Button 
          variant="outline" 
          size="sm"
          onClick={fetchQueueData}
          disabled={isLoading || loadingQueue}
        >
          Refresh Queue
        </Button>
      </div>

      {/* Queue Management */}
      <div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 gap-3">
          <h2 className="text-lg font-semibold">Today's Queue</h2>
          <div className="flex items-center gap-4">
            <div className="text-sm text-muted-foreground">
              Total in queue: <span className="font-semibold">{queueData.length}</span>
            </div>
            <div className="flex gap-1">
              <span className="w-3 h-3 rounded-full bg-yellow-500"></span>
              <span className="text-xs">Waiting ({waitingPatients.length})</span>
              <span className="w-3 h-3 rounded-full bg-blue-500 ml-2"></span>
              <span className="text-xs">In Treatment ({inTreatmentPatients.length})</span>
              <span className="w-3 h-3 rounded-full bg-green-500 ml-2"></span>
              <span className="text-xs">Completed ({completedPatients.length})</span>
            </div>
          </div>
        </div>
        
        {loadingQueue ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
            <span className="ml-2">Loading queue data...</span>
          </div>
        ) : queueData.length === 0 ? (
          <div className="text-center py-12 border-2 border-dashed border-gray-200 rounded-lg">
            <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">No patients in queue today</p>
            <p className="text-sm text-gray-400 mt-1">Add patients to start the queue</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <QueueSection
              title="Waiting"
              items={waitingPatients}
              status="waiting"
              onAction={handleQueueAction}
              onTransfer={handleTransferPatient}
              onRemove={handleRemoveFromQueue}
              doctors={doctors}
              isLoading={isLoading}
            />
            <QueueSection
              title="In Treatment"
              items={inTreatmentPatients}
              status="in-treatment"
              onAction={handleQueueAction}
              onTransfer={handleTransferPatient}
              doctors={doctors}
              isLoading={isLoading}
            />
            <QueueSection
              title="Completed"
              items={completedPatients}
              status="completed"
              onAction={handleQueueAction}
            />
          </div>
        )}
      </div>

      {/* Patient Modal */}
      {showPatientModal && (
        <PatientModal
          open={showPatientModal}
          onClose={() => {
            setShowPatientModal(false);
          }}
          onSubmit={handleSavePatient}
          patient={null}
          isEditing={false}
          title="Register New Patient"
          loading={savingPatient}
        />
      )}
    </div>
  );
}