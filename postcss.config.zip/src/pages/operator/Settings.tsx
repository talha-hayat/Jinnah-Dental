'use client';

import React, { useState } from 'react';
import { 
  Save,
  Download,
  Upload,
  Lock,
  User,
  Calendar,
  Clock,
  DollarSign,
  Plus,
  Edit,
  Trash2,
  Search,
  Database,
  Settings as SettingsIcon,
  FileText,
  Eye,
  EyeOff,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Treatment } from '@/types';
import TreatmentFormModal from '@/components/modals/TreatmentFormModal';

// Mock Data
const initialTreatments: Treatment[] = [
  { id: '1', name: 'General Checkup', fee: 50, category: 'consultation', duration: 15 },
  { id: '2', name: 'Teeth Cleaning', fee: 80, category: 'cleaning', duration: 30 },
  { id: '3', name: 'Filling', fee: 120, category: 'restoration', duration: 45 },
  { id: '4', name: 'Root Canal', fee: 500, category: 'endodontics', duration: 90 },
  { id: '5', name: 'Teeth Whitening', fee: 200, category: 'cosmetic', duration: 60 },
  { id: '6', name: 'Dental Crown', fee: 400, category: 'prosthodontics', duration: 120 },
  { id: '7', name: 'Tooth Extraction', fee: 150, category: 'surgery', duration: 30 },
];

const doctors = ['Dr. Smith', 'Dr. Johnson', 'Dr. Wilson', 'Dr. Brown', 'Dr. Taylor'];

const backupHistory = [
  { id: '1', date: '2024-01-15', type: 'full', size: '45 MB', status: 'success' },
  { id: '2', date: '2024-01-10', type: 'partial', size: '12 MB', status: 'success' },
  { id: '3', date: '2024-01-05', type: 'full', size: '43 MB', status: 'success' },
  { id: '4', date: '2024-01-01', type: 'partial', size: '8 MB', status: 'success' },
];

export default function OperatorSettings() {
  const [activeTab, setActiveTab] = useState('security');
  const [treatments, setTreatments] = useState<Treatment[]>(initialTreatments);
  const [selectedTreatment, setSelectedTreatment] = useState<Treatment | null>(null);
  const [showTreatmentForm, setShowTreatmentForm] = useState(false);
  const [isEditingTreatment, setIsEditingTreatment] = useState(false);
  
  // Password Change
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Clinic Settings
  const [clinicData, setClinicData] = useState({
    clinicName: 'City Dental Clinic',
    address: '123 Main Street, New York, NY 10001',
    phone: '+1 (555) 987-6543',
    email: 'info@citydental.com',
    taxRate: '5',
    currency: 'USD',
    businessHours: '9:00 AM - 6:00 PM',
  });

  // Backup Selection
  const [backupSelection, setBackupSelection] = useState({
    patients: true,
    appointments: true,
    bills: true,
    inventory: true,
    staff: true,
    treatments: true,
    expenses: true,
  });

  // Handle change password
  const handleChangePassword = () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast.error('New passwords do not match');
      return;
    }
    if (passwordData.newPassword.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }
    
    toast.success('Password changed successfully');
    setPasswordData({
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
    });
  };

  // Handle save clinic settings
  const handleSaveClinicSettings = () => {
    toast.success('Clinic settings saved');
  };

  // Handle backup
  const handleBackup = () => {
    const selectedItems = Object.entries(backupSelection)
      .filter(([_, value]) => value)
      .map(([key]) => key);
    
    if (selectedItems.length === 0) {
      toast.error('Select at least one item to backup');
      return;
    }

    toast.info('Creating backup...');
    
    // Simulate backup process
    setTimeout(() => {
      toast.success(`Backup created successfully (${selectedItems.join(', ')})`);
      // In real app, trigger download here
      downloadBackup();
    }, 1500);
  };

  // Handle download backup
  const downloadBackup = () => {
    const backupData = {
      timestamp: new Date().toISOString(),
      clinic: clinicData,
      treatments: treatments,
      totalSize: '25 MB',
      items: Object.keys(backupSelection).filter(key => backupSelection[key as keyof typeof backupSelection])
    };

    const dataStr = JSON.stringify(backupData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `clinic_backup_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Handle download individual data
  const handleDownloadData = (type: string) => {
    let data: any = {};
    
    switch(type) {
      case 'patients':
        data = { patients: [] };
        break;
      case 'doctors':
        data = { doctors };
        break;
      case 'treatments':
        data = { treatments };
        break;
      case 'bills':
        data = { bills: [] };
        break;
      case 'staff':
        data = { staff: [] };
        break;
      default:
        data = { message: 'Data export' };
    }

    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${type}_export_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast.success(`${type.charAt(0).toUpperCase() + type.slice(1)} data exported`);
  };

  // Handle restore backup
  const handleRestoreBackup = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.json')) {
      toast.error('Please select a JSON backup file');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        toast.success('Backup file loaded successfully');
        console.log('Backup data:', data);
      } catch (error) {
        toast.error('Invalid backup file format');
      }
    };
    reader.readAsText(file);
  };

  // Handle treatment CRUD
  const handleAddTreatment = () => {
    setSelectedTreatment(null);
    setIsEditingTreatment(false);
    setShowTreatmentForm(true);
  };

  const handleEditTreatment = (treatment: Treatment) => {
    setSelectedTreatment(treatment);
    setIsEditingTreatment(true);
    setShowTreatmentForm(true);
  };

  const handleDeleteTreatment = (treatment: Treatment) => {
    if (confirm(`Delete treatment "${treatment.name}"?`)) {
      setTreatments(prev => prev.filter(t => t.id !== treatment.id));
      toast.success(`Treatment "${treatment.name}" deleted`);
    }
  };

  const handleSaveTreatment = (treatmentData: any) => {
    if (isEditingTreatment && selectedTreatment) {
      setTreatments(prev => prev.map(t => 
        t.id === selectedTreatment.id 
          ? { 
              ...t, 
              name: treatmentData.name,
              fee: parseFloat(treatmentData.fee),
              category: treatmentData.category,
              duration: parseInt(treatmentData.duration),
              description: treatmentData.description
            }
          : t
      ));
      toast.success('Treatment updated');
    } else {
      const newTreatment: Treatment = {
        id: `t${treatments.length + 1}`,
        name: treatmentData.name,
        fee: parseFloat(treatmentData.fee),
        category: treatmentData.category,
        duration: parseInt(treatmentData.duration),
        description: treatmentData.description
      };
      setTreatments(prev => [...prev, newTreatment]);
      toast.success(`Treatment "${treatmentData.name}" added`);
    }
    setShowTreatmentForm(false);
  };

  // Handle toggle all backup selections
  const toggleAllBackup = (checked: boolean) => {
    setBackupSelection({
      patients: checked,
      appointments: checked,
      bills: checked,
      inventory: checked,
      staff: checked,
      treatments: checked,
      expenses: checked,
    });
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <div className="space-y-6 p-4 md:p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Settings</h1>
          <p className="text-muted-foreground">Manage clinic settings and configurations</p>
        </div>
        <Button 
          variant="outline" 
          className="gap-2"
          onClick={handleBackup}
        >
          <Database className="w-4 h-4" />
          Create Backup
        </Button>
      </div>

      {/* Tabs - Only 4 tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid grid-cols-2 sm:grid-cols-4">
          <TabsTrigger value="security">
            <Lock className="w-4 h-4 mr-2" />
            Security
          </TabsTrigger>
          <TabsTrigger value="clinic">
            <SettingsIcon className="w-4 h-4 mr-2" />
            Clinic
          </TabsTrigger>
          <TabsTrigger value="treatments">
            <FileText className="w-4 h-4 mr-2" />
            Treatments
          </TabsTrigger>
          <TabsTrigger value="backup">
            <Database className="w-4 h-4 mr-2" />
            Backup
          </TabsTrigger>
        </TabsList>

        {/* Security Tab */}
        <TabsContent value="security" className="space-y-6">
          <div className="bg-white rounded-lg border p-6">
            <h3 className="text-lg font-medium mb-4">Change Password</h3>
            <div className="space-y-4 max-w-md">
              <div>
                <label className="block text-sm font-medium mb-2">Current Password</label>
                <div className="relative">
                  <Input
                    type={showCurrentPassword ? "text" : "password"}
                    value={passwordData.currentPassword}
                    onChange={(e) => setPasswordData({...passwordData, currentPassword: e.target.value})}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 -translate-y-1/2"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                  >
                    {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">New Password</label>
                <div className="relative">
                  <Input
                    type={showNewPassword ? "text" : "password"}
                    value={passwordData.newPassword}
                    onChange={(e) => setPasswordData({...passwordData, newPassword: e.target.value})}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 -translate-y-1/2"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                  >
                    {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Confirm New Password</label>
                <div className="relative">
                  <Input
                    type={showConfirmPassword ? "text" : "password"}
                    value={passwordData.confirmPassword}
                    onChange={(e) => setPasswordData({...passwordData, confirmPassword: e.target.value})}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 -translate-y-1/2"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
              <div className="pt-2">
                <Button onClick={handleChangePassword}>
                  <Lock className="w-4 h-4 mr-2" />
                  Change Password
                </Button>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Clinic Settings Tab */}
        <TabsContent value="clinic" className="space-y-6">
          <div className="bg-white rounded-lg border p-6">
            <h3 className="text-lg font-medium mb-4">Clinic Information</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Clinic Name</label>
                <Input
                  value={clinicData.clinicName}
                  onChange={(e) => setClinicData({...clinicData, clinicName: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Address</label>
                <Input
                  value={clinicData.address}
                  onChange={(e) => setClinicData({...clinicData, address: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Phone</label>
                  <Input
                    value={clinicData.phone}
                    onChange={(e) => setClinicData({...clinicData, phone: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Email</label>
                  <Input
                    type="email"
                    value={clinicData.email}
                    onChange={(e) => setClinicData({...clinicData, email: e.target.value})}
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Tax Rate (%)</label>
                  <Input
                    type="number"
                    value={clinicData.taxRate}
                    onChange={(e) => setClinicData({...clinicData, taxRate: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Currency</label>
                  <select
                    value={clinicData.currency}
                    onChange={(e) => setClinicData({...clinicData, currency: e.target.value})}
                    className="w-full px-3 py-2 border rounded-lg"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="PKR">PKR (₨)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Business Hours</label>
                  <Input
                    value={clinicData.businessHours}
                    onChange={(e) => setClinicData({...clinicData, businessHours: e.target.value})}
                  />
                </div>
              </div>
              <div className="pt-4">
                <Button onClick={handleSaveClinicSettings}>
                  <Save className="w-4 h-4 mr-2" />
                  Save Clinic Settings
                </Button>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Treatments Tab */}
        <TabsContent value="treatments" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">Manage Treatments</h3>
            <Button onClick={handleAddTreatment} className="gap-2">
              <Plus className="w-4 h-4" />
              Add Treatment
            </Button>
          </div>

          <div className="bg-white rounded-lg border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="text-left p-3 font-medium">Treatment</th>
                    <th className="text-left p-3 font-medium">Category</th>
                    <th className="text-left p-3 font-medium">Fee</th>
                    <th className="text-left p-3 font-medium">Duration</th>
                    <th className="text-left p-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {treatments.map((treatment) => (
                    <tr key={treatment.id} className="border-b hover:bg-gray-50">
                      <td className="p-3">
                        <div className="font-medium">{treatment.name}</div>
                        {treatment.description && (
                          <div className="text-sm text-gray-500">{treatment.description}</div>
                        )}
                      </td>
                      <td className="p-3">
                        <Badge variant="outline">{treatment.category}</Badge>
                      </td>
                      <td className="p-3 font-bold">{formatCurrency(treatment.fee)}</td>
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4" />
                          {treatment.duration} min
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEditTreatment(treatment)}
                          >
                            <Edit className="w-3 h-3" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDeleteTreatment(treatment)}
                            className="text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </TabsContent>

        {/* Backup Tab */}
        <TabsContent value="backup" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Backup Settings */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white rounded-lg border p-6">
                <h3 className="text-lg font-medium mb-4">Backup Settings</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <label className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={Object.values(backupSelection).every(v => v)}
                        onChange={(e) => toggleAllBackup(e.target.checked)}
                        className="w-4 h-4"
                      />
                      <span className="font-medium">Select All</span>
                    </label>
                  </div>
                  
                  {Object.entries(backupSelection).map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between p-3 border rounded-lg">
                      <label className="flex items-center gap-3">
                        <input
                          type="checkbox"
                          checked={value}
                          onChange={(e) => setBackupSelection({...backupSelection, [key]: e.target.checked})}
                          className="w-4 h-4"
                        />
                        <span>{key.charAt(0).toUpperCase() + key.slice(1)}</span>
                      </label>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDownloadData(key)}
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Restore Backup */}
              <div className="bg-white rounded-lg border p-6">
                <h3 className="text-lg font-medium mb-4">Restore Backup</h3>
                <div className="space-y-4">
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <Upload className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-600 mb-4">Upload backup file (.json format)</p>
                    <label className="cursor-pointer">
                      <input
                        type="file"
                        accept=".json"
                        onChange={handleRestoreBackup}
                        className="hidden"
                      />
                      <Button variant="outline" asChild>
                        <span>Choose File</span>
                      </Button>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Backup History */}
            <div className="space-y-6">
              <div className="bg-white rounded-lg border p-6">
                <h3 className="text-lg font-medium mb-4">Backup History</h3>
                <div className="space-y-3">
                  {backupHistory.map((backup) => (
                    <div key={backup.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">{backup.date}</div>
                        <div className="text-sm text-gray-500">
                          {backup.type} • {backup.size}
                        </div>
                      </div>
                      <Badge className="bg-green-100 text-green-800">
                        {backup.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quick Actions */}
              <div className="bg-white rounded-lg border p-6">
                <h3 className="text-lg font-medium mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start gap-2"
                    onClick={() => handleDownloadData('patients')}
                  >
                    <Download className="w-4 h-4" />
                    Export Patients
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start gap-2"
                    onClick={() => handleDownloadData('doctors')}
                  >
                    <Download className="w-4 h-4" />
                    Export Doctors
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start gap-2"
                    onClick={() => handleDownloadData('treatments')}
                  >
                    <Download className="w-4 h-4" />
                    Export Treatments
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start gap-2"
                    onClick={() => handleBackup()}
                  >
                    <Database className="w-4 h-4" />
                    Create Full Backup
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Treatment Form Modal */}
      {showTreatmentForm && (
        <TreatmentFormModal
          open={showTreatmentForm}
          onClose={() => setShowTreatmentForm(false)}
          onSubmit={handleSaveTreatment}
          treatment={selectedTreatment}
          isEditing={isEditingTreatment}
        />
      )}
    </div>
  );
}