'use client';

import React, { useState, useEffect } from 'react';
import {
  UserPlus,
  Search,
  Edit,
  Trash2,
  DollarSign,
  ChevronLeft,
  ChevronRight,
  Loader2,
  Filter,
  Download,
  Phone,
  Calendar,
  MapPin,
  Activity,
  AlertCircle,
  CheckCircle,
  XCircle,
  Users,
  RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Patient, QueueItem, Bill } from '@/types';
import { toast } from 'sonner';
import PatientFormModal from '@/components/modals/PatientFormModal';
import PatientDetailsModal from '@/components/modals/PatientDetailsModal';
import {
  getAllPatients,
  addPatient,
  updatePatient,
  deletePatient,
  getPatientStats
} from '@/services/patientService';
import {
  getQueueItemsByPatientNumber
} from '@/services/queueService';
import {
  getBillsByPatientNumber
} from '@/services/billingService';
import { syncPatientAfterTreatment } from '@/services/syncService';
import { format, parseISO } from 'date-fns';

export default function OperatorPatients() {
  // State Management
  const [patients, setPatients] = useState<Patient[]>([]);
  const [filteredPatients, setFilteredPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [syncing, setSyncing] = useState(false);
  
  // Search & Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [balanceFilter, setBalanceFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('all');
  
  // Modals
  const [showPatientForm, setShowPatientForm] = useState(false);
  const [showPatientDetails, setShowPatientDetails] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [selectedPatientHistory, setSelectedPatientHistory] = useState<{
    queueHistory: QueueItem[];
    bills: Bill[];
  }>({ queueHistory: [], bills: [] });
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const patientsPerPage = 10;
  
  // Stats
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    pendingBalance: 0,
    totalVisits: 0,
    totalRevenue: 0
  });

  // Initial Data Fetch
  useEffect(() => {
    fetchPatients();
  }, []);

  // Filter patients when search or filters change
  useEffect(() => {
    applyFilters();
  }, [patients, searchTerm, statusFilter, balanceFilter, dateFilter]);

  // Fetch all patients
  const fetchPatients = async () => {
    try {
      setLoading(true);
      const data = await getAllPatients();
      
      // For each patient, fetch fresh stats
      const patientsWithStats = await Promise.all(
        data.map(async (patient) => {
          try {
            const stats = await getPatientStats(patient.patientNumber);
            const pendingBalance = stats.totalBilled - stats.totalPaid + (patient.openingBalance || 0);
            
            return {
              ...patient,
              totalVisits: stats.totalVisits || patient.totalVisits || 0,
              totalPaid: stats.totalPaid || patient.totalPaid || 0,
              pendingBalance: pendingBalance
            };
          } catch (error) {
            console.error(`Error fetching stats for patient ${patient.patientNumber}:`, error);
            return patient;
          }
        })
      );
      
      setPatients(patientsWithStats);
      calculateStats(patientsWithStats);
    } catch (error) {
      console.error('Error loading patients:', error);
      toast.error('Failed to load patients');
    } finally {
      setLoading(false);
    }
  };

  // Calculate statistics
  const calculateStats = (patientList: Patient[]) => {
    const total = patientList.length;
    const active = patientList.filter(p => p.isActive !== false).length;
    const pendingBalance = patientList.reduce((sum, p) => sum + (p.pendingBalance || 0), 0);
    const totalVisits = patientList.reduce((sum, p) => sum + (p.totalVisits || 0), 0);
    const totalRevenue = patientList.reduce((sum, p) => sum + (p.totalPaid || 0), 0);

    setStats({
      total,
      active,
      pendingBalance,
      totalVisits,
      totalRevenue
    });
  };

  // Apply filters to patients
  const applyFilters = () => {
    let result = patients;

    // Search filter
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase().trim();
      result = result.filter(patient => {
        const nameMatch = patient.name?.toLowerCase().includes(term) || false;
        const phoneMatch = patient.phone?.toLowerCase().includes(term) || false;
        const patientNumberMatch = patient.patientNumber?.toLowerCase().includes(term) || false;
        const emailMatch = patient.email?.toLowerCase().includes(term) || false;
        const addressMatch = patient.address?.toLowerCase().includes(term) || false;
        
        return nameMatch || phoneMatch || patientNumberMatch || emailMatch || addressMatch;
      });
    }

    // Status filter
    if (statusFilter !== 'all') {
      if (statusFilter === 'active') {
        result = result.filter(p => p.isActive !== false);
      } else if (statusFilter === 'inactive') {
        result = result.filter(p => p.isActive === false);
      }
    }

    // Balance filter
    if (balanceFilter !== 'all') {
      if (balanceFilter === 'zero') {
        result = result.filter(p => (p.pendingBalance || 0) === 0);
      } else if (balanceFilter === 'pending') {
        result = result.filter(p => (p.pendingBalance || 0) > 0);
      } else if (balanceFilter === 'credit') {
        result = result.filter(p => (p.pendingBalance || 0) < 0);
      }
    }

    setFilteredPatients(result);
    setCurrentPage(1);
  };

  // Handle search
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  // Handle add new patient
  const handleAddPatient = () => {
    setSelectedPatient(null);
    setShowPatientForm(true);
  };

  // Handle edit patient
  const handleEditPatient = (patient: Patient) => {
    setSelectedPatient(patient);
    setShowPatientForm(true);
  };

  // Handle delete patient
  const handleDeletePatient = async (patient: Patient) => {
    if (!confirm(`Are you sure you want to delete patient ${patient.name} (${patient.patientNumber})?\nThis action cannot be undone.`)) {
      return;
    }

    try {
      await deletePatient(patient.id);
      setPatients(prev => prev.filter(p => p.id !== patient.id));
      toast.success(`Patient ${patient.name} deleted successfully`);
      
      if (selectedPatient?.id === patient.id) {
        setShowPatientDetails(false);
        setSelectedPatient(null);
      }
    } catch (error) {
      console.error('Error deleting patient:', error);
      toast.error('Failed to delete patient');
    }
  };

  // Handle save patient
  const handleSavePatient = async (patientData: any) => {
    try {
      setSaving(true);

      const patientPayload = {
        name: patientData.name?.trim() || '',
        phone: patientData.phone?.trim() || '',
        age: patientData.age ? Number(patientData.age) : 0,
        gender: patientData.gender || 'other',
        address: patientData.address?.trim() || '',
        email: patientData.email?.trim() || '',
        emergencyContact: patientData.emergencyContact?.trim() || '',
        bloodGroup: patientData.bloodGroup?.trim() || '',
        allergies: patientData.allergies?.trim() || '',
        medicalHistory: patientData.medicalHistory?.trim() || '',
        notes: patientData.notes?.trim() || '',
        openingBalance: Number(patientData.openingBalance || 0)
      };

      if (patientData.id && patientData.isEditing) {
        await updatePatient(patientData.id, patientPayload);
        
        setPatients(prev => prev.map(p =>
          p.id === patientData.id
            ? { ...p, ...patientPayload }
            : p
        ));

        toast.success('Patient updated successfully');
      } else {
        const newPatientData = {
          ...patientPayload,
          patientNumber: patientData.patientNumber,
          registrationDate: new Date().toISOString(),
          totalVisits: 0,
          totalPaid: 0,
          pendingBalance: Number(patientData.openingBalance || 0),
          isActive: true
        };

        const result = await addPatient(newPatientData);
        
        const newPatient: Patient = {
          id: result.id,
          patientNumber: result.patientNumber,
          ...newPatientData
        };
        
        setPatients(prev => [newPatient, ...prev]);
        toast.success(`${patientData.name} added successfully (ID: ${result.patientNumber})`);
      }

      setShowPatientForm(false);
      setSelectedPatient(null);
    } catch (error) {
      console.error('Error saving patient:', error);
      toast.error('Failed to save patient');
    } finally {
      setSaving(false);
    }
  };

  // Handle view patient details
  const handleViewPatientDetails = async (patient: Patient) => {
    setSelectedPatient(patient);
    
    try {
      const [queueHistory, bills] = await Promise.all([
        getQueueItemsByPatientNumber(patient.patientNumber),
        getBillsByPatientNumber(patient.patientNumber)
      ]);
      
      setSelectedPatientHistory({
        queueHistory,
        bills
      });
      
      setShowPatientDetails(true);
    } catch (error) {
      console.error('Error fetching patient history:', error);
      toast.error('Failed to load patient history');
    }
  };

  // Handle sync patient
  const handleSyncPatient = async (patient: Patient) => {
    try {
      toast.info(`Syncing ${patient.name}...`);
      await syncPatientAfterTreatment(patient.patientNumber);
      
      // Refresh patient data
      const updatedStats = await getPatientStats(patient.patientNumber);
      const pendingBalance = updatedStats.totalBilled - updatedStats.totalPaid + (patient.openingBalance || 0);
      
      const updatedPatient = {
        ...patient,
        totalVisits: updatedStats.totalVisits,
        totalPaid: updatedStats.totalPaid,
        pendingBalance: pendingBalance
      };
      
      setPatients(prev => prev.map(p => 
        p.id === patient.id ? updatedPatient : p
      ));
      
      toast.success(`${patient.name} synced successfully`);
      
      if (selectedPatient?.id === patient.id) {
        setSelectedPatient(updatedPatient);
      }
    } catch (error) {
      console.error('Error syncing patient:', error);
      toast.error('Failed to sync patient');
    }
  };

  // Handle sync all patients
  const handleSyncAllPatients = async () => {
    try {
      setSyncing(true);
      toast.info('Syncing all patients...');
      
      // Refresh all patients
      await fetchPatients();
      
      toast.success('All patients synced successfully');
    } catch (error) {
      console.error('Error syncing all patients:', error);
      toast.error('Failed to sync patients');
    } finally {
      setSyncing(false);
    }
  };

  // Handle export data - ADD THIS FUNCTION
  const handleExportData = () => {
    try {
      if (filteredPatients.length === 0) {
        toast.error('No data to export');
        return;
      }

      const headers = ['Patient ID', 'Name', 'Phone', 'Age', 'Gender', 'Address', 'Total Visits', 'Total Paid', 'Pending Balance', 'Status'];
      const csvData = filteredPatients.map(p => [
        p.patientNumber || 'N/A',
        p.name || 'N/A',
        p.phone || 'N/A',
        p.age || 0,
        p.gender || 'N/A',
        p.address || '',
        p.totalVisits || 0,
        p.totalPaid || 0,
        p.pendingBalance || 0,
        p.isActive !== false ? 'Active' : 'Inactive'
      ]);

      const csvContent = [
        headers.join(','),
        ...csvData.map(row => row.map(cell => `"${cell}"`).join(','))
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `patients_${format(new Date(), 'yyyy-MM-dd')}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
      
      toast.success('Data exported successfully');
    } catch (error) {
      console.error('Error exporting data:', error);
      toast.error('Failed to export data');
    }
  };

  // Handle clear filters
  const handleClearFilters = () => {
    setSearchTerm('');
    setStatusFilter('all');
    setBalanceFilter('all');
    setDateFilter('all');
  };

  // Safe date formatting
  const safeFormatDate = (dateString: string | undefined | null): string => {
    if (!dateString) return 'N/A';
    
    try {
      const date = parseISO(dateString);
      if (isNaN(date.getTime())) {
        return 'Invalid Date';
      }
      return format(date, 'MMM dd, yyyy');
    } catch (error) {
      try {
        const date = new Date(dateString);
        if (isNaN(date.getTime())) {
          return 'N/A';
        }
        return format(date, 'MMM dd, yyyy');
      } catch {
        return 'N/A';
      }
    }
  };

  // Format currency
  const formatCurrency = (amount: number | undefined): string => {
    const numAmount = amount || 0;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(numAmount);
  };

  // Get status badge
  const getStatusBadge = (patient: Patient) => {
    if (patient.isActive === false) {
      return <Badge variant="destructive">Inactive</Badge>;
    }
    
    if ((patient.pendingBalance || 0) > 0) {
      return (
        <Badge variant="outline" className="border-orange-200 text-orange-800 bg-orange-50">
          Pending: {formatCurrency(patient.pendingBalance)}
        </Badge>
      );
    }
    
    return (
      <Badge variant="outline" className="border-green-200 text-green-800 bg-green-50">
        Active
      </Badge>
    );
  };

  // Get visits badge
  const getVisitsBadge = (patient: Patient) => {
    if (!patient.totalVisits || patient.totalVisits === 0) {
      return <Badge variant="outline" className="bg-gray-50">New</Badge>;
    }
    return <Badge variant="secondary">{patient.totalVisits} visit{patient.totalVisits !== 1 ? 's' : ''}</Badge>;
  };

  // Pagination calculations
  const indexOfLastPatient = currentPage * patientsPerPage;
  const indexOfFirstPatient = indexOfLastPatient - patientsPerPage;
  const currentPatients = filteredPatients.slice(indexOfFirstPatient, indexOfLastPatient);
  const totalPages = Math.ceil(filteredPatients.length / patientsPerPage);

  return (
    <div className="space-y-6 p-4 md:p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Patient Management</h1>
          <p className="text-muted-foreground">
            Manage all patient records
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={handleSyncAllPatients} 
            className="gap-2"
            disabled={syncing}
          >
            <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
            {syncing ? 'Syncing...' : 'Sync All'}
          </Button>
          <Button variant="outline" onClick={handleExportData} className="gap-2">
            <Download className="w-4 h-4" />
            Export
          </Button>
          <Button onClick={handleAddPatient} className="gap-2">
            <UserPlus className="w-4 h-4" />
            Add Patient
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold">{stats.total}</div>
              <div className="text-sm text-gray-600">Total Patients</div>
            </div>
            <Users className="w-8 h-8 text-blue-500" />
          </div>
        </div>
        
        <div className="bg-white border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold">{stats.active}</div>
              <div className="text-sm text-gray-600">Active</div>
            </div>
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
        </div>
        
        <div className="bg-white border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold">{formatCurrency(stats.pendingBalance)}</div>
              <div className="text-sm text-gray-600">Pending Balance</div>
            </div>
            <AlertCircle className="w-8 h-8 text-orange-500" />
          </div>
        </div>
        
        <div className="bg-white border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold">{stats.totalVisits}</div>
              <div className="text-sm text-gray-600">Total Visits</div>
            </div>
            <Activity className="w-8 h-8 text-purple-500" />
          </div>
        </div>
        
        <div className="bg-white border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold">{formatCurrency(stats.totalRevenue)}</div>
              <div className="text-sm text-gray-600">Total Revenue</div>
            </div>
            <DollarSign className="w-8 h-8 text-green-500" />
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white border rounded-lg p-4 space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, phone, ID..."
              className="pl-9"
              value={searchTerm}
              onChange={handleSearch}
            />
          </div>
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={balanceFilter} onValueChange={setBalanceFilter}>
            <SelectTrigger className="w-[180px]">
              <DollarSign className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Balance" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Balance</SelectItem>
              <SelectItem value="zero">Zero Balance</SelectItem>
              <SelectItem value="pending">Has Pending</SelectItem>
              <SelectItem value="credit">Has Credit</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" onClick={handleClearFilters}>
            Clear Filters
          </Button>
        </div>
        
        <div className="text-sm text-gray-500">
          Showing {filteredPatients.length} of {patients.length} patients
          {searchTerm && ` • Search: "${searchTerm}"`}
        </div>
      </div>

      {/* Loading State */}
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <span className="ml-2">Loading patients...</span>
        </div>
      ) : (
        <>
          {/* Patients Table */}
          <div className="bg-white rounded-lg border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Patient ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Age/Gender</TableHead>
                  <TableHead>Visits</TableHead>
                  <TableHead>Balance</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {currentPatients.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                      <div className="space-y-2">
                        <Users className="w-12 h-12 mx-auto text-gray-300" />
                        <p>No patients found</p>
                        <Button onClick={handleAddPatient} className="mt-2">
                          <UserPlus className="w-4 h-4 mr-2" />
                          Add Patient
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  currentPatients.map((patient) => (
                    <TableRow
                      key={patient.id}
                      className="cursor-pointer hover:bg-gray-50"
                      onClick={() => handleViewPatientDetails(patient)}
                    >
                      <TableCell>
                        <div className="font-mono font-bold">{patient.patientNumber}</div>
                        <div className="text-xs text-gray-500">
                          {safeFormatDate(patient.registrationDate)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{patient.name}</div>
                        {patient.email && (
                          <div className="text-xs text-gray-500 truncate max-w-[200px]">
                            {patient.email}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Phone className="w-3 h-3 text-gray-500" />
                          <span>{patient.phone}</span>
                        </div>
                        {patient.emergencyContact && (
                          <div className="text-xs text-gray-500">
                            Emergency: {patient.emergencyContact}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <div>
                          {patient.age} years
                        </div>
                        <div className="text-sm text-gray-600 capitalize">
                          {patient.gender}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getVisitsBadge(patient)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="font-medium">
                            {formatCurrency(patient.totalPaid)} paid
                          </div>
                          <div className={`text-sm ${(patient.pendingBalance || 0) > 0 ? 'text-orange-600' : 'text-green-600'}`}>
                            {formatCurrency(patient.pendingBalance)} pending
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(patient)}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleSyncPatient(patient);
                            }}
                            className="h-8 w-8 p-0"
                            title="Sync Data"
                          >
                            <RefreshCw className="w-3 h-3" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEditPatient(patient);
                            }}
                            className="h-8 w-8 p-0"
                            title="Edit"
                          >
                            <Edit className="w-3 h-3" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeletePatient(patient);
                            }}
                            className="h-8 w-8 p-0 text-red-600 border-red-200 hover:bg-red-50"
                            title="Delete"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {filteredPatients.length > 0 && (
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-sm text-muted-foreground">
                Showing {indexOfFirstPatient + 1} to {Math.min(indexOfLastPatient, filteredPatients.length)} of {filteredPatients.length} entries
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <span className="text-sm">
                  Page {currentPage} of {totalPages}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </>
      )}

      {/* Patient Form Modal */}
      {showPatientForm && (
        <PatientFormModal
          open={showPatientForm}
          onClose={() => {
            setShowPatientForm(false);
            setSelectedPatient(null);
          }}
          onSubmit={handleSavePatient}
          patient={selectedPatient}
          isEditing={!!selectedPatient}
          mode="patient"
          existingPatients={patients}
          title={selectedPatient ? 'Edit Patient' : 'Add New Patient'}
          loading={saving}
        />
      )}

      {/* Patient Details Modal */}
      {showPatientDetails && selectedPatient && (
        <PatientDetailsModal
          patient={selectedPatient}
          patientInfo={selectedPatient}
          onClose={() => {
            setShowPatientDetails(false);
            setSelectedPatient(null);
          }}
          onEdit={() => {
            setShowPatientDetails(false);
            setShowPatientForm(true);
          }}
          onDelete={() => handleDeletePatient(selectedPatient)}
          queueHistory={selectedPatientHistory.queueHistory}
          bills={selectedPatientHistory.bills}
        />
      )}
    </div>
  );
}