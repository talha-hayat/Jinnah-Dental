'use client';

import React, { useState } from 'react';
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Filter,
  Download,
  DollarSign,
  Tag,
  Calendar,
  User,
  Building,
  AlertCircle,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import ExpenseFormModal from '@/components/modals/ExpenseFormModal';

// Types
export type ExpenseCategory = 'rent' | 'salary' | 'supplies' | 'utilities' | 'equipment' | 'medication' | 'maintenance' | 'other';
export type PaymentMethod = 'cash' | 'card' | 'bank_transfer' | 'cheque' | 'online';

export interface Expense {
  id: string;
  title: string;
  amount: number;
  category: ExpenseCategory;
  paymentMethod: PaymentMethod;
  date: string;
  description: string;
  vendor?: string;
  receiptNumber?: string;
  status: 'paid' | 'pending' | 'cancelled';
  createdAt: string;
  updatedAt: string;
  paidBy?: string;
  attachment?: string;
}

// Mock Data
const initialExpenses: Expense[] = [
  {
    id: '1',
    title: 'Monthly Clinic Rent',
    amount: 2500,
    category: 'rent',
    paymentMethod: 'bank_transfer',
    date: '2024-01-10',
    description: 'January clinic rent payment',
    vendor: 'ABC Real Estate',
    receiptNumber: 'RENT-001',
    status: 'paid',
    createdAt: '2024-01-10T10:00:00',
    updatedAt: '2024-01-10T10:00:00',
    paidBy: 'Dr. Smith'
  },
  {
    id: '2',
    title: 'Dental Supplies Purchase',
    amount: 850,
    category: 'supplies',
    paymentMethod: 'card',
    date: '2024-01-12',
    description: 'Gloves, masks, and dental materials',
    vendor: 'MediDent Supplies',
    receiptNumber: 'SUP-2024-001',
    status: 'paid',
    createdAt: '2024-01-12T14:30:00',
    updatedAt: '2024-01-12T14:30:00',
    paidBy: 'Admin'
  },
  {
    id: '3',
    title: 'Staff Salary - January',
    amount: 4200,
    category: 'salary',
    paymentMethod: 'bank_transfer',
    date: '2024-01-05',
    description: 'Monthly salaries for clinic staff',
    vendor: '',
    receiptNumber: 'SAL-0124',
    status: 'pending',
    createdAt: '2024-01-04T09:00:00',
    updatedAt: '2024-01-04T09:00:00',
    paidBy: 'Accountant'
  },
  {
    id: '4',
    title: 'New X-Ray Machine',
    amount: 12000,
    category: 'equipment',
    paymentMethod: 'cheque',
    date: '2024-01-15',
    description: 'Digital X-ray machine for clinic',
    vendor: 'Dental Equipment Co.',
    receiptNumber: 'EQP-001',
    status: 'paid',
    createdAt: '2024-01-14T11:20:00',
    updatedAt: '2024-01-15T16:00:00',
    paidBy: 'Dr. Johnson'
  },
  {
    id: '5',
    title: 'Electricity Bill',
    amount: 350,
    category: 'utilities',
    paymentMethod: 'online',
    date: '2024-01-08',
    description: 'Monthly electricity bill',
    vendor: 'Power Utility Company',
    receiptNumber: 'EB-12456',
    status: 'paid',
    createdAt: '2024-01-07T08:45:00',
    updatedAt: '2024-01-08T12:00:00',
    paidBy: 'Reception'
  },
  {
    id: '6',
    title: 'Dental Medications',
    amount: 620,
    category: 'medication',
    paymentMethod: 'cash',
    date: '2024-01-18',
    description: 'Anesthesia and other medications',
    vendor: 'Pharma Supplies',
    receiptNumber: 'MED-0124',
    status: 'pending',
    createdAt: '2024-01-17T15:30:00',
    updatedAt: '2024-01-17T15:30:00',
    paidBy: 'Nurse'
  },
  {
    id: '7',
    title: 'AC Maintenance',
    amount: 280,
    category: 'maintenance',
    paymentMethod: 'cash',
    date: '2024-01-20',
    description: 'AC servicing and repair',
    vendor: 'Cool Air Services',
    receiptNumber: 'MNT-001',
    status: 'cancelled',
    createdAt: '2024-01-19T10:15:00',
    updatedAt: '2024-01-19T10:15:00',
    paidBy: 'Maintenance'
  },
  {
    id: '8',
    title: 'Office Internet',
    amount: 120,
    category: 'utilities',
    paymentMethod: 'card',
    date: '2024-01-03',
    description: 'Monthly internet bill',
    vendor: 'NetConnect ISP',
    receiptNumber: 'INT-0124',
    status: 'paid',
    createdAt: '2024-01-02T13:40:00',
    updatedAt: '2024-01-03T09:20:00'
  }
];

// Category Labels
const categoryLabels: Record<ExpenseCategory, { label: string; color: string }> = {
  rent: { label: 'Rent', color: 'bg-purple-100 text-purple-800' },
  salary: { label: 'Salary', color: 'bg-blue-100 text-blue-800' },
  supplies: { label: 'Supplies', color: 'bg-green-100 text-green-800' },
  utilities: { label: 'Utilities', color: 'bg-yellow-100 text-yellow-800' },
  equipment: { label: 'Equipment', color: 'bg-indigo-100 text-indigo-800' },
  medication: { label: 'Medication', color: 'bg-pink-100 text-pink-800' },
  maintenance: { label: 'Maintenance', color: 'bg-orange-100 text-orange-800' },
  other: { label: 'Other', color: 'bg-gray-100 text-gray-800' }
};

// Payment Method Labels
const paymentMethodLabels: Record<PaymentMethod, string> = {
  cash: 'Cash',
  card: 'Card',
  bank_transfer: 'Bank Transfer',
  cheque: 'Cheque',
  online: 'Online'
};

// Status Labels
const statusLabels: Record<Expense['status'], { label: string; color: string }> = {
  paid: { label: 'Paid', color: 'bg-green-100 text-green-800 border-green-200' },
  pending: { label: 'Pending', color: 'bg-yellow-100 text-yellow-800 border-yellow-200' },
  cancelled: { label: 'Cancelled', color: 'bg-red-100 text-red-800 border-red-200' }
};

export default function OperatorExpenses() {
  const [expenses, setExpenses] = useState<Expense[]>(initialExpenses);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedExpense, setSelectedExpense] = useState<Expense | null>(null);
  const [showExpenseForm, setShowExpenseForm] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedCategory, setSelectedCategory] = useState<ExpenseCategory | 'all'>('all');
  const [selectedStatus, setSelectedStatus] = useState<Expense['status'] | 'all'>('all');
  
  const itemsPerPage = 8;

  // Filter expenses
  const filteredExpenses = expenses.filter(expense => {
    const matchesSearch = expense.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         expense.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         expense.vendor?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         expense.receiptNumber?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || expense.category === selectedCategory;
    const matchesStatus = selectedStatus === 'all' || expense.status === selectedStatus;
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  // Pagination
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentExpenses = filteredExpenses.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(filteredExpenses.length / itemsPerPage);

  // Statistics
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const paidExpenses = expenses
    .filter(expense => expense.status === 'paid')
    .reduce((sum, expense) => sum + expense.amount, 0);
  const pendingExpenses = expenses
    .filter(expense => expense.status === 'pending')
    .reduce((sum, expense) => sum + expense.amount, 0);

  // Handle search
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1);
  };

  // Handle add expense
  const handleAddExpense = () => {
    setSelectedExpense(null);
    setIsEditing(false);
    setShowExpenseForm(true);
  };

  // Handle edit expense
  const handleEditExpense = (expense: Expense, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedExpense(expense);
    setIsEditing(true);
    setShowExpenseForm(true);
  };

  // Handle delete expense
  const handleDeleteExpense = async (expense: Expense, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm(`Delete expense "${expense.title}"?`)) {
      await new Promise(resolve => setTimeout(resolve, 300));
      setExpenses(prev => prev.filter(e => e.id !== expense.id));
      toast.success(`Expense "${expense.title}" deleted`);
    }
  };

  // Handle save expense
  const handleSaveExpense = async (expenseData: any) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    if (isEditing && selectedExpense) {
      // Update existing expense
      setExpenses(prev => prev.map(e => 
        e.id === selectedExpense.id 
          ? { 
              ...e, 
              ...expenseData,
              updatedAt: new Date().toISOString()
            }
          : e
      ));
      toast.success('Expense updated successfully');
    } else {
      // Add new expense
      const newExpense: Expense = {
        id: `exp-${Date.now()}`,
        title: expenseData.title,
        amount: parseFloat(expenseData.amount) || 0,
        category: expenseData.category,
        paymentMethod: expenseData.paymentMethod,
        date: expenseData.date,
        description: expenseData.description,
        vendor: expenseData.vendor,
        receiptNumber: expenseData.receiptNumber,
        status: expenseData.status,
        paidBy: expenseData.paidBy,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      setExpenses(prev => [newExpense, ...prev]);
      toast.success(`Expense "${expenseData.title}" added successfully`);
    }
    
    setShowExpenseForm(false);
  };

  // Handle status change
  const handleStatusChange = async (expense: Expense, newStatus: Expense['status']) => {
    await new Promise(resolve => setTimeout(resolve, 200));
    setExpenses(prev => prev.map(e => 
      e.id === expense.id 
        ? { ...e, status: newStatus, updatedAt: new Date().toISOString() }
        : e
    ));
    toast.success(`Status updated to ${newStatus}`);
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  // Export to CSV
  const handleExportCSV = () => {
    const headers = ['ID', 'Title', 'Amount', 'Category', 'Status', 'Date', 'Vendor', 'Payment Method', 'Description'];
    const csvData = expenses.map(expense => [
      expense.id,
      expense.title,
      expense.amount,
      categoryLabels[expense.category].label,
      statusLabels[expense.status].label,
      formatDate(expense.date),
      expense.vendor || 'N/A',
      paymentMethodLabels[expense.paymentMethod],
      expense.description
    ]);

    const csvContent = [
      headers.join(','),
      ...csvData.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `expenses_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    
    toast.success('Expenses exported to CSV');
  };

  // Calculate category totals
  const categoryTotals = expenses.reduce((acc, expense) => {
    if (!acc[expense.category]) {
      acc[expense.category] = 0;
    }
    acc[expense.category] += expense.amount;
    return acc;
  }, {} as Record<ExpenseCategory, number>);

  return (
    <div className="space-y-6 p-4 md:p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Expenses Management</h1>
          <p className="text-muted-foreground">Track and manage clinic expenses</p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={handleExportCSV}
            className="gap-2"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </Button>
          <Button 
            onClick={handleAddExpense}
            className="gap-2 bg-green-600 hover:bg-green-700"
          >
            <Plus className="w-4 h-4" />
            Add Expense
          </Button>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-blue-700">{formatCurrency(totalExpenses)}</div>
              <div className="text-sm text-blue-600 font-medium">Total Expenses</div>
            </div>
            <DollarSign className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-green-700">{formatCurrency(paidExpenses)}</div>
              <div className="text-sm text-green-600 font-medium">Paid Expenses</div>
            </div>
            <Building className="w-8 h-8 text-green-600" />
          </div>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-yellow-700">{formatCurrency(pendingExpenses)}</div>
              <div className="text-sm text-yellow-600 font-medium">Pending Expenses</div>
            </div>
            <AlertCircle className="w-8 h-8 text-yellow-600" />
          </div>
        </div>
      </div>

      {/* Category Summary */}
      <div className="bg-white rounded-lg border p-4">
        <h3 className="font-medium mb-3">Expenses by Category</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {Object.entries(categoryTotals).map(([category, amount]) => (
            <div key={category} className="border rounded-lg p-3">
              <div className="flex items-center justify-between">
                <Badge className={categoryLabels[category as ExpenseCategory].color}>
                  {categoryLabels[category as ExpenseCategory].label}
                </Badge>
                <span className="font-bold">{formatCurrency(amount)}</span>
              </div>
              <div className="mt-2 text-xs text-gray-500">
                {((amount / totalExpenses) * 100).toFixed(1)}% of total
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search expenses by title, description, vendor..." 
              className="pl-9"
              value={searchTerm}
              onChange={handleSearch}
            />
          </div>
          <Button 
            variant="outline" 
            onClick={() => {
              setSearchTerm('');
              setSelectedCategory('all');
              setSelectedStatus('all');
            }}
          >
            Clear Filters
          </Button>
        </div>

        <div className="flex flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4" />
            <select
              value={selectedCategory}
              onChange={(e) => {
                setSelectedCategory(e.target.value as ExpenseCategory | 'all');
                setCurrentPage(1);
              }}
              className="px-3 py-2 border rounded-lg text-sm"
            >
              <option value="all">All Categories</option>
              {Object.entries(categoryLabels).map(([value, { label }]) => (
                <option key={value} value={value}>{label}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <Tag className="w-4 h-4" />
            <select
              value={selectedStatus}
              onChange={(e) => {
                setSelectedStatus(e.target.value as Expense['status'] | 'all');
                setCurrentPage(1);
              }}
              className="px-3 py-2 border rounded-lg text-sm"
            >
              <option value="all">All Status</option>
              {Object.entries(statusLabels).map(([value, { label }]) => (
                <option key={value} value={value}>{label}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Expenses Table */}
      <div className="bg-white rounded-lg border overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="text-left p-3 font-medium">Title</th>
                <th className="text-left p-3 font-medium">Amount</th>
                <th className="text-left p-3 font-medium">Category</th>
                <th className="text-left p-3 font-medium">Date</th>
                <th className="text-left p-3 font-medium">Status</th>
                <th className="text-left p-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {currentExpenses.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center p-8 text-muted-foreground">
                    No expenses found
                  </td>
                </tr>
              ) : (
                currentExpenses.map((expense) => (
                  <tr 
                    key={expense.id}
                    className="border-b hover:bg-gray-50 transition-colors"
                  >
                    <td className="p-3">
                      <div className="font-medium">{expense.title}</div>
                      <div className="text-xs text-muted-foreground truncate max-w-[200px]">
                        {expense.description}
                      </div>
                      {expense.vendor && (
                        <div className="text-xs text-gray-600 mt-1">
                          <User className="inline w-3 h-3 mr-1" />
                          {expense.vendor}
                        </div>
                      )}
                    </td>
                    <td className="p-3">
                      <div className="font-bold">{formatCurrency(expense.amount)}</div>
                      <div className="text-xs text-gray-500">
                        {paymentMethodLabels[expense.paymentMethod]}
                      </div>
                    </td>
                    <td className="p-3">
                      <Badge className={categoryLabels[expense.category].color}>
                        {categoryLabels[expense.category].label}
                      </Badge>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-3 h-3 text-gray-500" />
                        <span>{formatDate(expense.date)}</span>
                      </div>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <Badge 
                          variant="outline" 
                          className={statusLabels[expense.status].color}
                        >
                          {statusLabels[expense.status].label}
                        </Badge>
                        {expense.status === 'pending' && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleStatusChange(expense, 'paid')}
                            className="h-6 text-xs"
                          >
                            Mark Paid
                          </Button>
                        )}
                      </div>
                    </td>
                    <td className="p-3">
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => handleEditExpense(expense, e)}
                          className="h-8 w-8 p-0"
                          title="Edit"
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => handleDeleteExpense(expense, e)}
                          className="h-8 w-8 p-0 text-red-600 border-red-200 hover:bg-red-50"
                          title="Delete"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {filteredExpenses.length > 0 && (
          <div className="flex flex-col sm:flex-row items-center justify-between p-3 border-t gap-3">
            <div className="text-sm text-muted-foreground">
              Showing {indexOfFirstItem + 1}-{Math.min(indexOfLastItem, filteredExpenses.length)} of {filteredExpenses.length}
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <span className="flex items-center px-3 text-sm">
                Page {currentPage} of {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Expense Form Modal */}
      {showExpenseForm && (
        <ExpenseFormModal
          open={showExpenseForm}
          onClose={() => setShowExpenseForm(false)}
          onSubmit={handleSaveExpense}
          expense={selectedExpense}
          isEditing={isEditing}
        />
      )}
    </div>
  );
}