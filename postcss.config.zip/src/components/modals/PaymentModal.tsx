'use client';

import React, { useState, useEffect, useRef } from 'react';
import { X, DollarSign, Receipt, History, Printer, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { QueueItem, Bill } from '@/types';
import { toast } from 'sonner';

interface PaymentModalProps {
  queueItem: QueueItem;
  bills?: Bill[];
  onClose: () => void;
  onSubmit: (queueItem: QueueItem, data: any) => void;
}

export default function PaymentModal({
  queueItem,
  bills = [],
  onClose,
  onSubmit
}: PaymentModalProps) {
  const [paymentData, setPaymentData] = useState({
    amount: 0,
    paymentMethod: 'cash',
    discount: 0,
    notes: ''
  });

  const [totalFee, setTotalFee] = useState(0);
  const [remainingAmount, setRemainingAmount] = useState(0);
  const [previousPending, setPreviousPending] = useState(0);
  const [isPrinting, setIsPrinting] = useState(false);

  // Safe number conversion
  const toNumber = (value: any): number => {
    if (value === null || value === undefined) return 0;
    const num = Number(value);
    return isNaN(num) ? 0 : num;
  };

  useEffect(() => {
    const paidAmount = toNumber(queueItem.amountPaid);
    const fee = toNumber(queueItem.fee);
    const pending = toNumber(queueItem.previousPending);

    setTotalFee(fee);
    setPreviousPending(pending);

    const totalDue = fee + pending;
    const remaining = Math.max(0, totalDue - paidAmount);

    setRemainingAmount(remaining);
    setPaymentData(prev => ({ ...prev, amount: remaining }));
  }, [queueItem]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setPaymentData(prev => ({
      ...prev,
      [name]: name === 'amount' || name === 'discount' ? parseFloat(value) || 0 : value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const paymentAmount = toNumber(paymentData.amount);

    if (paymentAmount <= 0) return toast.error('Enter valid amount');
    if (paymentAmount > remainingAmount) {
      return toast.error(`Cannot pay more than remaining $${remainingAmount.toFixed(2)}`);
    }

    onSubmit(queueItem, {
      ...paymentData,
      amount: paymentAmount,
      discount: toNumber(paymentData.discount)
    });
  };

  const handleFullPayment = () => {
    setPaymentData(prev => ({ ...prev, amount: remainingAmount }));
  };

  // **FIXED: Direct Thermal Printer Function for XP-S200M**
  const handlePrintBill = async () => {
    setIsPrinting(true);
    
    try {
      // Step 1: Generate ESC/POS commands
      const escposCommands = generateEscPosCommands();
      
      // Step 2: Multiple printing methods tried in sequence
      await printViaThermalPrinter(escposCommands);
      
    } catch (error) {
      console.error('Print error:', error);
      toast.error('Print failed. Please check printer connection.');
    } finally {
      setIsPrinting(false);
    }
  };

  // Generate ESC/POS commands for thermal printer
  const generateEscPosCommands = () => {
    const tax = toNumber(queueItem.fee) * 0.05;
    const total = totalFee + tax - toNumber(paymentData.discount);
    const paidNow = toNumber(paymentData.amount);
    const remaining = Math.max(0, total - paidNow);
    const currentDate = new Date().toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });

    // ESC/POS commands array
    const commands = [];
    
    // Initialize printer
    commands.push('\x1B\x40'); // Initialize printer
    commands.push('\x1B\x61\x01'); // Center align
    
    // Header
    commands.push('\x1D\x21\x11'); // Double height and width
    commands.push('JINNAH DENTAL CLINIC\n');
    commands.push('\x1D\x21\x00'); // Normal text
    commands.push('\x1B\x61\x00'); // Left align
    
    commands.push('==============================\n');
    commands.push(`Token: #${queueItem.tokenNumber}\n`);
    commands.push(`Patient: ${queueItem.patientName}\n`);
    commands.push(`Phone: ${queueItem.patientPhone || 'N/A'}\n`);
    commands.push(`Date: ${currentDate}\n`);
    commands.push('------------------------------\n');
    
    // Treatments
    if (queueItem.treatment) {
      commands.push('\x1B\x45\x01'); // Bold on
      commands.push('Treatments:\n');
      commands.push('\x1B\x45\x00'); // Bold off
      
      const treatments = queueItem.treatment.split(', ');
      treatments.forEach(treatment => {
        commands.push(`${treatment.trim()}\n`);
      });
      commands.push('------------------------------\n');
    }
    
    // Bill details
    commands.push(`Treatment Fee: $${toNumber(queueItem.fee).toFixed(2)}\n`);
    
    if (previousPending > 0) {
      commands.push(`Previous Pending: $${previousPending.toFixed(2)}\n`);
    }
    
    commands.push(`Tax (5%): $${tax.toFixed(2)}\n`);
    
    if (paymentData.discount > 0) {
      commands.push(`Discount: -$${paymentData.discount.toFixed(2)}\n`);
    }
    
    commands.push('------------------------------\n');
    commands.push('\x1B\x45\x01'); // Bold on
    commands.push(`Total Due: $${total.toFixed(2)}\n`);
    commands.push('\x1B\x45\x00'); // Bold off
    
    commands.push(`Paid Now: $${paidNow.toFixed(2)}\n`);
    commands.push(`Remaining: $${remaining.toFixed(2)}\n`);
    commands.push('==============================\n');
    
    // Footer
    commands.push('\x1B\x61\x01'); // Center align
    commands.push('Thank You! Visit Again\n\n\n');
    
    // Cut paper (partial cut)
    commands.push('\x1D\x56\x00'); // Cut paper
    
    return commands.join('');
  };

  // Multiple printing methods
  const printViaThermalPrinter = async (escposData: string) => {
    // Method 1: Using WebUSB API (if browser supports)
    if ('usb' in navigator) {
      try {
        await printViaWebUSB(escposData);
        return;
      } catch (error) {
        console.log('WebUSB failed, trying next method...');
      }
    }
    
    // Method 2: Using Web Serial API (Chrome 89+)
    if ('serial' in navigator) {
      try {
        await printViaWebSerial(escposData);
        return;
      } catch (error) {
        console.log('WebSerial failed, trying next method...');
      }
    }
    
    // Method 3: Using Raw Socket (if printer is network printer)
    try {
      await printViaNetwork(escposData);
      return;
    } catch (error) {
      console.log('Network print failed...');
    }
    
    // Method 4: Fallback to browser print with thermal styling
    await printViaBrowser(escposData);
  };

  // Method 1: WebUSB API
  const printViaWebUSB = async (escposData: string) => {
    try {
      const device = await (navigator as any).usb.requestDevice({
        filters: [{ vendorId: 0x04B8 }] // Seiko/Epson vendor ID
      });
      
      await device.open();
      await device.selectConfiguration(1);
      await device.claimInterface(0);
      
      // Convert text to Uint8Array
      const encoder = new TextEncoder();
      const data = encoder.encode(escposData);
      
      await device.transferOut(1, data);
      await device.close();
      
      toast.success('Bill printed via USB');
      return true;
    } catch (error) {
      throw new Error('USB printing not available');
    }
  };

  // Method 2: Web Serial API (Best for Chrome/Edge)
  const printViaWebSerial = async (escposData: string) => {
    try {
      const port = await (navigator as any).serial.requestPort();
      await port.open({ baudRate: 9600 });
      
      const writer = port.writable.getWriter();
      const encoder = new TextEncoder();
      const data = encoder.encode(escposData);
      
      await writer.write(data);
      await writer.close();
      await port.close();
      
      toast.success('Bill printed via Serial Port');
      return true;
    } catch (error) {
      throw new Error('Serial printing not available');
    }
  };

  // Method 3: Network Printer (TCP/IP)
  const printViaNetwork = async (escposData: string) => {
    // NOTE: This requires CORS proxy or backend API
    // You need to set up a backend endpoint for printing
    
    try {
      const printerIP = localStorage.getItem('printer_ip') || '192.168.1.100';
      const printerPort = localStorage.getItem('printer_port') || '9100';
      
      // Using WebSocket or fetch to backend
      const response = await fetch('/api/print', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          data: escposData,
          printer: 'thermal',
          type: 'escpos'
        })
      });
      
      if (response.ok) {
        toast.success('Bill sent to printer');
        return true;
      }
      throw new Error('Network print failed');
    } catch (error) {
      throw new Error('Network printing not configured');
    }
  };

  // Method 4: Browser Print Fallback
  const printViaBrowser = (escposData: string) => {
    return new Promise((resolve, reject) => {
      const printWindow = window.open('', '_blank');
      if (!printWindow) {
        reject(new Error('Please allow popups for printing'));
        return;
      }
      
      const htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>Print Bill</title>
          <style>
            @media print {
              @page {
                size: 80mm auto;
                margin: 0;
                padding: 0;
              }
              body {
                width: 80mm;
                margin: 0;
                padding: 10px;
                font-family: 'Courier New', monospace;
                font-size: 12px;
                white-space: pre-line;
              }
              .no-print { display: none; }
            }
            body {
              width: 80mm;
              margin: 0;
              padding: 10px;
              font-family: 'Courier New', monospace;
              font-size: 12px;
              white-space: pre-line;
            }
            .header {
              text-align: center;
              font-size: 16px;
              font-weight: bold;
              margin-bottom: 10px;
            }
            .footer {
              text-align: center;
              margin-top: 20px;
              font-weight: bold;
            }
            .divider {
              border-top: 1px dashed #000;
              margin: 10px 0;
            }
            button {
              padding: 10px 20px;
              background: #007bff;
              color: white;
              border: none;
              border-radius: 5px;
              cursor: pointer;
              margin: 20px auto;
              display: block;
            }
          </style>
        </head>
        <body>
          <div class="header">JINNAH DENTAL CLINIC</div>
          <div class="divider"></div>
          <div>${escposData.replace(/\n/g, '<br>').replace(/\x1B\[[0-9;]*[a-zA-Z]/g, '')}</div>
          <div class="footer">Thank You! Visit Again</div>
          <div class="no-print">
            <button onclick="window.print()">Print Now</button>
            <button onclick="window.close()">Close</button>
            <p>Note: For best results, use thermal printer paper and set page size to 80mm in print settings.</p>
          </div>
          <script>
            setTimeout(() => {
              window.print();
              setTimeout(() => window.close(), 1000);
            }, 500);
          </script>
        </body>
        </html>
      `;
      
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      
      printWindow.onbeforeunload = () => {
        resolve(true);
      };
      
      setTimeout(() => {
        resolve(true);
      }, 2000);
    });
  };

  // Calculate functions
  const calculateTax = () => toNumber(queueItem.fee) * 0.05;
  const calculateTotal = () => {
    const tax = calculateTax();
    return totalFee + tax - toNumber(paymentData.discount);
  };

  const patientBills = bills.filter(bill => bill.patientId === queueItem.patientNumber);
  const totalPaid = patientBills.reduce((sum, bill) => sum + toNumber(bill.amountPaid), 0);
  const paidAmount = toNumber(queueItem.amountPaid);
  const discountAmount = toNumber(paymentData.discount);
  const currentRemaining = Math.max(0, (totalFee + previousPending) - paidAmount);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b sticky top-0 bg-white">
          <h2 className="text-lg font-semibold">Payment for {queueItem.patientName}</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Patient Info */}
          <div className="bg-blue-50 p-3 rounded-lg">
            <h3 className="font-semibold text-blue-800 mb-2">Patient Information</h3>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <span className="text-gray-600">Token:</span>
                <span className="font-semibold ml-2">#{queueItem.tokenNumber}</span>
              </div>
              <div>
                <span className="text-gray-600">Age:</span>
                <span className="font-semibold ml-2">{queueItem.age || 'N/A'}</span>
              </div>
              <div className="col-span-2">
                <span className="text-gray-600">Treatment:</span>
                <span className="font-semibold ml-2">{queueItem.treatment || 'N/A'}</span>
              </div>
            </div>
          </div>

          {/* Payment History */}
          {patientBills.length > 0 && (
            <div className="border rounded-lg p-3">
              <div className="flex items-center gap-2 mb-2">
                <History className="w-4 h-4" />
                <h3 className="font-semibold">Payment History</h3>
              </div>
              <div className="text-sm space-y-1 max-h-32 overflow-y-auto">
                {patientBills.map((bill, index) => (
                  <div key={index} className="flex justify-between items-center py-1 border-b">
                    <div>
                      <span className="text-gray-600">{new Date(bill.date).toLocaleDateString()}</span>
                      <span className="ml-2">({bill.paymentMethod})</span>
                    </div>
                    <span className="font-semibold">${toNumber(bill.amountPaid).toFixed(2)}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between mt-2 pt-2 border-t">
                <span className="font-semibold">Total Paid:</span>
                <span className="font-semibold text-green-600">${totalPaid.toFixed(2)}</span>
              </div>
            </div>
          )}

          {/* Bill Summary */}
          <div className="border rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <Receipt className="w-4 h-4" />
              <h3 className="font-semibold">Bill Summary</h3>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Treatment Fee:</span>
                <span>${toNumber(queueItem.fee).toFixed(2)}</span>
              </div>
              {previousPending > 0 && (
                <div className="flex justify-between text-amber-600">
                  <span>Previous Pending:</span>
                  <span>${previousPending.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Tax (5%):</span>
                <span>${(toNumber(queueItem.fee) * 0.05).toFixed(2)}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Discount:</span>
                  <span>-${discountAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between font-semibold pt-2 border-t">
                <span>Total Due:</span>
                <span>${calculateTotal().toFixed(2)}</span>
              </div>
              {paidAmount > 0 && (
                <div className="flex justify-between text-blue-600">
                  <span>Already Paid:</span>
                  <span>${paidAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-lg pt-2 border-t">
                <span>Remaining:</span>
                <span className={currentRemaining > 0 ? 'text-red-600' : 'text-green-600'}>
                  ${currentRemaining.toFixed(2)}
                </span>
              </div>
            </div>
          </div>

          {/* Payment Form */}
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <Label htmlFor="amount">Amount to Pay</Label>
              <div className="flex gap-2">
                <Input
                  id="amount"
                  name="amount"
                  type="number"
                  step="0.01"
                  value={paymentData.amount}
                  onChange={handleChange}
                  min="0"
                  max={remainingAmount}
                  required
                />
                <Button type="button" variant="outline" onClick={handleFullPayment} className="whitespace-nowrap">
                  Full Payment
                </Button>
              </div>
            </div>

            <div>
              <Label htmlFor="discount">Discount ($)</Label>
              <Input
                id="discount"
                name="discount"
                type="number"
                step="0.01"
                value={paymentData.discount}
                onChange={handleChange}
                min="0"
                max={calculateTotal()}
              />
            </div>

            <div>
              <Label htmlFor="paymentMethod">Payment Method</Label>
              <select
                id="paymentMethod"
                name="paymentMethod"
                value={paymentData.paymentMethod}
                onChange={handleChange}
                className="w-full p-2 border rounded-md"
              >
                <option value="cash">Cash</option>
                <option value="card">Card</option>
                <option value="online">Online</option>
                <option value="insurance">Insurance</option>
              </select>
            </div>

            <div>
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Input
                id="notes"
                name="notes"
                value={paymentData.notes}
                onChange={handleChange}
                placeholder="Payment notes..."
              />
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-2 pt-4 border-t">
              <Button type="button" variant="outline" onClick={onClose} className="flex-1">
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex-1 bg-green-600 hover:bg-green-700 gap-2"
                disabled={currentRemaining <= 0}
              >
                <DollarSign className="w-4 h-4" />
                Process Payment
              </Button>

              <Button
                type="button"
                variant="outline"
                onClick={handlePrintBill}
                disabled={isPrinting}
                className="gap-2 min-w-[120px]"
              >
                {isPrinting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Printing...
                  </>
                ) : (
                  <>
                    <Printer className="w-4 h-4" />
                    Print Bill
                  </>
                )}
              </Button>
            </div>
          </form>
          
          {/* Printer Settings (Optional) */}
          <div className="text-xs text-gray-500 mt-4 p-2 bg-gray-50 rounded">
            <p><strong>Note:</strong> For direct thermal printing:</p>
            <ul className="list-disc pl-4 mt-1">
              <li>Use Chrome/Edge browser</li>
              <li>Allow popups for this site</li>
              <li>Connect XP-S200M via USB</li>
              <li>Select "Thermal Printer" when prompted</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}