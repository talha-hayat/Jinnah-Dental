'use client';

import React from 'react';
import { X, Edit, Trash2, DollarSign, Phone, Mail, Calendar, MapPin, Briefcase, Clock, History } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Staff, SalaryPayment } from '@/types';

interface StaffDetailsModalProps {
  open: boolean;
  onClose: () => void;
  staff: Staff | null;
  salaryPayments: SalaryPayment[];
  onEdit: () => void;
  onDelete: (staff: Staff) => void;
  onPaySalary: () => void;
}

export default function StaffDetailsModal({
  open,
  onClose,
  staff,
  salaryPayments,
  onEdit,
  onDelete,
  onPaySalary
}: StaffDetailsModalProps) {
  if (!open || !staff) return null;

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const totalSalaryPaid = salaryPayments.reduce((sum, p) => sum + p.amount, 0);

  return (
    <div 
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      onClick={handleBackdropClick}
    >
      <div className="bg-white rounded-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
              <Briefcase className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h2 className="text-xl font-bold">{staff.name}</h2>
              <p className="text-muted-foreground">{staff.role}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-6">
          {/* Staff Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Badge className={
                  staff.status === 'Active' ? 'bg-green-100 text-green-800' :
                  staff.status === 'On Leave' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800'
                }>
                  {staff.status}
                </Badge>
                <Badge className="bg-blue-100 text-blue-800">
                  {staff.specialization || 'General'}
                </Badge>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <span>{staff.phone}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  <span>{staff.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                  <span>Joined: {new Date(staff.joinDate).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span>Experience: {staff.experience}</span>
                </div>
                {staff.address && (
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <span>{staff.address}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-medium mb-2">Salary Information</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Monthly Salary:</span>
                    <span className="font-bold">${staff.salary}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Pending Salary:</span>
                    <span className={`font-bold ${staff.pendingSalary > 0 ? 'text-red-600' : 'text-green-600'}`}>
                      ${staff.pendingSalary}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Paid:</span>
                    <span className="font-bold text-green-600">${staff.totalPaid}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t font-bold">
                    <span>Total Salary Due:</span>
                    <span>${(staff.salary + staff.pendingSalary)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Salary Payment History */}
          {salaryPayments.length > 0 && (
            <div>
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <History className="w-4 h-4" />
                Salary Payment History
              </h3>
              <div className="border rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left p-3">Date</th>
                      <th className="text-left p-3">Month</th>
                      <th className="text-left p-3">Amount</th>
                      <th className="text-left p-3">Method</th>
                      <th className="text-left p-3">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {salaryPayments.map(payment => (
                      <tr key={payment.id} className="border-t hover:bg-gray-50">
                        <td className="p-3">{new Date(payment.date).toLocaleDateString()}</td>
                        <td className="p-3">{payment.month}</td>
                        <td className="p-3 font-medium">${payment.amount}</td>
                        <td className="p-3">
                          <Badge className="bg-blue-100 text-blue-800">
                            {payment.paymentMethod}
                          </Badge>
                        </td>
                        <td className="p-3">
                          <Badge className="bg-green-100 text-green-800">
                            {payment.status}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-gray-50">
                    <tr>
                      <td colSpan={2} className="p-3 font-bold">Total Paid:</td>
                      <td colSpan={3} className="p-3 font-bold text-green-600">
                        ${totalSalaryPaid}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4 border-t">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Close
            </Button>
            <Button
              variant="outline"
              onClick={() => onDelete(staff)}
              className="text-red-600 border-red-200 hover:bg-red-50"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete Staff
            </Button>
            <Button variant="outline" onClick={onEdit} className="flex-1">
              <Edit className="w-4 h-4 mr-2" />
              Edit Details
            </Button>
            <Button
              onClick={onPaySalary}
              className="flex-1 bg-green-600 hover:bg-green-700"
              disabled={staff.pendingSalary <= 0}
            >
              <DollarSign className="w-4 h-4 mr-2" />
              Pay Salary (${staff.pendingSalary})
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}