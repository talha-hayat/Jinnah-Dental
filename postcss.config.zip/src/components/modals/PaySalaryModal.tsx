'use client';

import React, { useState, useEffect } from 'react';
import { X, DollarSign, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Staff } from '@/types';

interface PaySalaryModalProps {
  open: boolean;
  onClose: () => void;
  staff: Staff | null;
  onSubmit: (staff: Staff, data: any) => void;
}

export default function PaySalaryModal({
  open,
  onClose,
  staff,
  onSubmit
}: PaySalaryModalProps) {
  const [paymentData, setPaymentData] = useState({
    amount: 0,
    paymentMethod: 'bank',
    month: new Date().toLocaleString('default', { month: 'long', year: 'numeric' }),
    notes: ''
  });

  useEffect(() => {
    if (staff && open) {
      setPaymentData({
        amount: staff.pendingSalary,
        paymentMethod: 'bank',
        month: new Date().toLocaleString('default', { month: 'long', year: 'numeric' }),
        notes: ''
      });
    }
  }, [staff, open]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name === 'amount') {
      setPaymentData(prev => ({ 
        ...prev, 
        [name]: parseFloat(value) || 0 
      }));
    } else {
      setPaymentData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!staff) return;
    
    const maxAmount = staff.pendingSalary;
    if (paymentData.amount <= 0) {
      alert('Please enter a valid amount');
      return;
    }
    
    if (paymentData.amount > maxAmount) {
      alert(`Amount cannot exceed pending salary of $${maxAmount}`);
      return;
    }
    
    onSubmit(staff, paymentData);
  };

  const handleFullPayment = () => {
    if (staff) {
      setPaymentData(prev => ({ 
        ...prev, 
        amount: staff.pendingSalary 
      }));
    }
  };

  const handlePartialPayment = () => {
    if (staff) {
      const halfAmount = Math.floor(staff.pendingSalary / 2);
      setPaymentData(prev => ({ 
        ...prev, 
        amount: halfAmount 
      }));
    }
  };

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  if (!open || !staff) return null;

  return (
    <div 
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      onClick={handleBackdropClick}
    >
      <div className="bg-white rounded-lg w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg font-semibold">Pay Salary to {staff.name}</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Staff Info */}
          <div className="bg-gray-50 border rounded-lg p-3">
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <div className="text-muted-foreground">Staff</div>
                <div className="font-medium">{staff.name}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Role</div>
                <div className="font-medium">{staff.role}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Monthly Salary</div>
                <div className="font-medium">${staff.salary}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Pending Salary</div>
                <div className={`font-medium ${staff.pendingSalary > 0 ? 'text-red-600' : 'text-green-600'}`}>
                  ${staff.pendingSalary}
                </div>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="month">Month</Label>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-muted-foreground" />
                <Input
                  id="month"
                  name="month"
                  value={paymentData.month}
                  onChange={handleChange}
                  placeholder="e.g., January 2024"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Payment Amount *</Label>
              <div className="flex gap-2 mb-2">
                <Button type="button" variant="outline" size="sm" onClick={handleFullPayment}>
                  Full Amount (${staff.pendingSalary})
                </Button>
                <Button type="button" variant="outline" size="sm" onClick={handlePartialPayment}>
                  Half (${Math.floor(staff.pendingSalary / 2)})
                </Button>
              </div>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="amount"
                  name="amount"
                  type="number"
                  value={paymentData.amount}
                  onChange={handleChange}
                  required
                  min="0"
                  max={staff.pendingSalary}
                  step="0.01"
                  className="pl-9"
                />
              </div>
              <p className="text-sm text-muted-foreground">
                Max: ${staff.pendingSalary}
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="paymentMethod">Payment Method</Label>
              <select
                id="paymentMethod"
                name="paymentMethod"
                value={paymentData.paymentMethod}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg"
              >
                <option value="bank">Bank Transfer</option>
                <option value="cash">Cash</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                name="notes"
                value={paymentData.notes}
                onChange={handleChange}
                placeholder="Payment notes..."
                rows={2}
              />
            </div>

            {/* Summary */}
            <div className="border rounded-lg p-3 bg-blue-50">
              <h3 className="font-medium mb-2">Payment Summary</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Pending Salary:</span>
                  <span>${staff.pendingSalary}</span>
                </div>
                <div className="flex justify-between">
                  <span>Payment Amount:</span>
                  <span className="font-bold">${paymentData.amount}</span>
                </div>
                <div className="flex justify-between pt-2 border-t">
                  <span>Remaining After Payment:</span>
                  <span className={`font-bold ${(staff.pendingSalary - paymentData.amount) > 0 ? 'text-red-600' : 'text-green-600'}`}>
                    ${(staff.pendingSalary - paymentData.amount).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4 border-t">
              <Button type="button" variant="outline" onClick={onClose} className="flex-1">
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="flex-1 bg-green-600 hover:bg-green-700 gap-2"
                disabled={paymentData.amount <= 0}
              >
                <DollarSign className="w-4 h-4" />
                Process Payment
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}