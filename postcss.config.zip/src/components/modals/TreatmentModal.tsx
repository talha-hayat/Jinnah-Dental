'use client';

import React, { useState, useEffect } from 'react';
import { X, Save, Plus, Trash } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { QueueItem } from '@/types';
import { toast } from 'sonner';

interface TreatmentModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: { treatment: string; fee: number; doctor: string }) => void;
  queueItem: QueueItem | null;
  doctors: string[];
}

interface SelectedTreatment {
  name: string;
  fee: number;
}

export default function TreatmentModal({
  open,
  onClose,
  onSubmit,
  queueItem,
  doctors,
}: TreatmentModalProps) {
  const defaultTreatments = [
    'Teeth Cleaning',
    'Root Canal',
    'Filling',
    'Extraction',
    'Braces Adjustment',
    'Whitening',
    'Crown Placement',
    'Scaling & Polishing',
  ];

  const [selectedTreatments, setSelectedTreatments] = useState<SelectedTreatment[]>([]);
  const [newTreatmentName, setNewTreatmentName] = useState('');
  const [newTreatmentFee, setNewTreatmentFee] = useState('');
  const [manualTotal, setManualTotal] = useState('');
  const [discount, setDiscount] = useState(0);
  const [selectedDoctor, setSelectedDoctor] = useState('');

  if (!open || !queueItem) return null;

  // Auto-calculate actual total and discount
  const actualTotal = selectedTreatments.reduce((sum, t) => sum + t.fee, 0);

  useEffect(() => {
    const manual = parseFloat(manualTotal) || 0;
    setDiscount(manual > actualTotal ? 0 : actualTotal - manual); // Agar manual kam hai to discount, warna 0
  }, [manualTotal, actualTotal]);

  const handleAddTreatment = () => {
    const feeNum = parseFloat(newTreatmentFee) || 0;
    if (newTreatmentName && feeNum >= 0 && !selectedTreatments.some(t => t.name === newTreatmentName)) {
      setSelectedTreatments([...selectedTreatments, { name: newTreatmentName, fee: feeNum }]);
      setNewTreatmentName('');
      setNewTreatmentFee('');
    } else {
      toast.error('Enter valid treatment name and fee');
    }
  };

  const handleRemoveTreatment = (name: string) => {
    setSelectedTreatments(selectedTreatments.filter(t => t.name !== name));
  };

  const handleSubmit = () => {
    if (selectedTreatments.length === 0) {
      toast.error('At least one treatment is required');
      return;
    }
    if (!manualTotal || parseFloat(manualTotal) < 0) {
      toast.error('Enter valid manual total amount');
      return;
    }
    if (!selectedDoctor) {
      toast.error('Please select a doctor');
      return;
    }

    const treatmentString = selectedTreatments.map(t => `${t.name} ($${t.fee})`).join(', ');

    onSubmit({
      treatment: treatmentString,
      fee: parseFloat(manualTotal), // Manual total as final fee
      doctor: selectedDoctor
    });
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-3xl max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="flex items-center justify-between p-5 border-b sticky top-0 bg-white z-10">
          <h2 className="text-xl font-bold">Complete Treatment - {queueItem.patientName}</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Patient Info */}
          <div className="border rounded-lg p-4 bg-gray-50">
            <h3 className="font-semibold mb-2">Patient Details</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
              <div>
                <Label className="text-xs text-gray-500">Name</Label>
                <p className="font-medium">{queueItem.patientName}</p>
              </div>
              <div>
                <Label className="text-xs text-gray-500">Phone</Label>
                <p className="font-medium">{queueItem.patientPhone || 'N/A'}</p>
              </div>
              <div>
                <Label className="text-xs text-gray-500">Previous Pending</Label>
                <p className="font-medium text-red-600">${(queueItem.previousPending || 0).toFixed(2)}</p>
              </div>
            </div>
          </div>

          {/* Add Treatments */}
          <div className="space-y-3">
            <Label>Add Treatment</Label>
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1">
                <Select onValueChange={setNewTreatmentName} value={newTreatmentName}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select or type..." />
                  </SelectTrigger>
                  <SelectContent>
                    {defaultTreatments.map(t => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Input
                placeholder="Or type new treatment"
                value={newTreatmentName}
                onChange={e => setNewTreatmentName(e.target.value)}
                className="flex-1"
              />
              <Input
                type="number"
                placeholder="Fee ($)"
                value={newTreatmentFee}
                onChange={e => setNewTreatmentFee(e.target.value)}
                className="w-32"
                min="0"
                step="0.01"
              />
              <Button onClick={handleAddTreatment} className="gap-1">
                <Plus className="w-4 h-4" /> Add
              </Button>
            </div>
          </div>

          {/* Selected Treatments Table */}
          {selectedTreatments.length > 0 ? (
            <div className="border rounded-lg overflow-hidden">
              <Table>
                <TableHeader className="bg-gray-100">
                  <TableRow>
                    <TableHead>Treatment</TableHead>
                    <TableHead className="text-right">Fee ($)</TableHead>
                    <TableHead className="w-16 text-center">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedTreatments.map((t, index) => (
                    <TableRow key={index}>
                      <TableCell>{t.name}</TableCell>
                      <TableCell className="text-right font-medium">${t.fee.toFixed(2)}</TableCell>
                      <TableCell className="text-center">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveTreatment(t.name)}
                        >
                          <Trash className="w-4 h-4 text-red-600" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              {/* Actual Total */}
              <div className="p-4 bg-gray-50 border-t flex justify-between items-center">
                <span className="font-semibold">Actual Total (Sum of Treatments):</span>
                <span className="text-xl font-bold text-green-700">${actualTotal.toFixed(2)}</span>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500 border rounded-lg">
              No treatments added yet
            </div>
          )}

          {/* Manual Total & Discount */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="manualTotal">Final / Manual Total Amount</Label>
              <Input
                id="manualTotal"
                type="number"
                value={manualTotal}
                onChange={e => setManualTotal(e.target.value)}
                placeholder="Enter final amount (after adjustment)"
                min="0"
                step="0.01"
              />
              <p className="text-xs text-gray-500 mt-1">
                Enter amount patient will pay (can be less/more than actual total)
              </p>
            </div>

            <div>
              <Label>Discount (Auto Calculated)</Label>
              <Input value={discount.toFixed(2)} disabled className="bg-gray-100" />
              <p className="text-xs text-gray-500 mt-1">
                {discount > 0 ? 'Discount applied' : 'No discount'}
              </p>
            </div>
          </div>

          {/* Doctor */}
          <div>
            <Label>Assign Doctor</Label>
            <Select onValueChange={setSelectedDoctor} value={selectedDoctor}>
              <SelectTrigger>
                <SelectValue placeholder="Select doctor" />
              </SelectTrigger>
              <SelectContent>
                {doctors.map(d => (
                  <SelectItem key={d} value={d}>{d}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Buttons */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button
              onClick={handleSubmit}
              disabled={selectedTreatments.length === 0 || !manualTotal || !selectedDoctor}
              className="gap-2 bg-green-600 hover:bg-green-700"
            >
              <Save className="w-4 h-4" /> Save & Complete
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}