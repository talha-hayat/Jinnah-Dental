'use client';

import React, { useState, useEffect } from 'react';
import { X, Search, User, DollarSign, AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

interface Patient {
  id: string;           // Firebase document ID
  patientNumber?: string;   // Custom 4-digit number (0001, 0002...)
  name: string;
  phone: string;
  age?: string | number;
  gender?: string;
  address?: string;
  openingBalance?: number;
}

interface PatientFormModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  patient?: Patient | null;
  isEditing?: boolean;
  mode?: 'patient' | 'walk-in';
  existingPatients?: Patient[];
  title?: string;
  loading?: boolean;
}

export default function PatientFormModal({
  open,
  onClose,
  onSubmit,
  patient,
  isEditing = false,
  mode = 'walk-in',
  existingPatients = [],
  title = 'Patient Registration',
  loading = false
}: PatientFormModalProps) {
  const [formData, setFormData] = useState({
    patientNumber: '',
    name: '',
    phone: '',
    age: '',
    gender: '',
    address: '',
    openingBalance: '0'
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const [filteredPatients, setFilteredPatients] = useState<Patient[]>([]);
  const [isExistingPatient, setIsExistingPatient] = useState(false);
  const [idError, setIdError] = useState('');
  const [lastGeneratedId, setLastGeneratedId] = useState('');
  const [selectedPatientId, setSelectedPatientId] = useState<string | undefined>(undefined);

  // Generate next available 4-digit number
  const generateNextSequentialNumber = () => {
    if (existingPatients.length === 0) return '0001';

    const numericIds = existingPatients
      .map(p => p.patientNumber || '')
      .filter(id => /^\d{4}$/.test(id))
      .map(id => parseInt(id, 10))
      .filter(id => !isNaN(id) && id >= 1 && id <= 9999);

    if (numericIds.length === 0) return '0001';

    let nextId = Math.max(...numericIds) + 1;

    while (numericIds.includes(nextId) && nextId <= 9999) {
      nextId++;
    }

    if (nextId > 9999) {
      for (let i = 1; i <= 9999; i++) {
        if (!numericIds.includes(i)) {
          nextId = i;
          break;
        }
      }
    }

    return nextId.toString().padStart(4, '0');
  };

  const checkNumberExists = (id: string) =>
    existingPatients.some(p => p.patientNumber === id);

  const getPatientByNumber = (id: string) =>
    existingPatients.find(p => p.patientNumber === id);

  // Initialize form when modal opens
  useEffect(() => {
    if (!open) return;

    if (patient && isEditing) {
      // Editing existing patient
      setFormData({
        patientNumber: patient.patientNumber || '',
        name: patient.name || '',
        phone: patient.phone || '',
        age: patient.age?.toString() || '',
        gender: patient.gender || '',
        address: patient.address || '',
        openingBalance: patient.openingBalance?.toString() || '0'
      });
      setSearchQuery(patient.name || '');
      setIsExistingPatient(true);
      setSelectedPatientId(patient.id);
      setIdError('');
    } else {
      // New patient / walk-in
      const newNumber = generateNextSequentialNumber();
      setFormData({
        patientNumber: newNumber,
        name: '',
        phone: '',
        age: '',
        gender: '',
        address: '',
        openingBalance: '0'
      });
      setLastGeneratedId(newNumber);
      setSearchQuery('');
      setIsExistingPatient(false);
      setSelectedPatientId(undefined);
      setIdError('');
    }

    setShowDropdown(false);
    setFilteredPatients([]);
  }, [open, patient, isEditing, existingPatients]);

  // Live search
  useEffect(() => {
    if (searchQuery.length < 1) {
      setFilteredPatients([]);
      setShowDropdown(false);
      return;
    }

    const lowerQuery = searchQuery.toLowerCase();
    const filtered = existingPatients.filter(p =>
      p.name?.toLowerCase().includes(lowerQuery) ||
      p.phone?.includes(searchQuery) ||
      (p.patientNumber && p.patientNumber.includes(searchQuery)) ||
      p.id?.includes(searchQuery)
    );

    setFilteredPatients(filtered);
    setShowDropdown(true);
  }, [searchQuery, existingPatients]);

  const handleSelectPatient = (selected: Patient) => {
    setFormData({
      patientNumber: selected.patientNumber || '',
      name: selected.name || '',
      phone: selected.phone || '',
      age: selected.age?.toString() || '',
      gender: selected.gender || '',
      address: selected.address || '',
      openingBalance: selected.openingBalance?.toString() || '0'
    });
    setSearchQuery(selected.name || '');
    setShowDropdown(false);
    setIsExistingPatient(true);
    setSelectedPatientId(selected.id);
    setIdError('');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;

    if (name === 'patientNumber') {
      let newValue = value.replace(/\D/g, '').slice(0, 4);

      if (newValue.length > 0 && newValue.length !== 4) {
        setIdError('Number must be exactly 4 digits');
      } else if (!isExistingPatient && newValue && checkNumberExists(newValue)) {
        const existing = getPatientByNumber(newValue);
        setIdError(`Number ${newValue} already exists (${existing?.name || 'unknown'})`);
      } else {
        setIdError('');
      }

      setFormData(prev => ({ ...prev, [name]: newValue }));
    }
    else if (name === 'openingBalance') {
      const cleaned = value.replace(/[^0-9.-]/g, '');
      const parts = cleaned.split('.');
      const formatted = parts.length > 2 ? parts[0] + '.' + parts.slice(1).join('') : cleaned;
      setFormData(prev => ({ ...prev, [name]: formatted }));
    }
    else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
  

    // Basic validation
    if (!formData.name.trim()) return toast.error('Patient name is required');
    if (!formData.phone.trim()) return toast.error('Phone number is required');
    if (!formData.patientNumber || formData.patientNumber.length !== 4) {
      return toast.error('Patient Number must be exactly 4 digits (0001-9999)');
    }

    // console.log('Data', isExistingPatient[0] , formData.patientNumber, selectedPatientId);

    // **CRITICAL CHECK**: Duplicate number prevention for NEW patients
    if (!isExistingPatient && checkNumberExists(formData.patientNumber)) {
      toast.error(`Patient Number ${formData.patientNumber} already exists! Please use a different number.`);
      setIdError(`Number ${formData.patientNumber} already exists`);
      return;
    }

    // If editing existing patient → allow same number (it's already theirs)
    if (isExistingPatient && isEditing) {
      const currentPatient = existingPatients.find(p => p.id === selectedPatientId);
      if (currentPatient?.patientNumber !== formData.patientNumber) {
        toast.error('Cannot change number of existing patient');
        return;
      }
    }

    let openingBalance = 0;
    if (formData.openingBalance) {
      const num = parseFloat(formData.openingBalance);
      if (!isNaN(num)) openingBalance = num;
    }

    const submitData = {
      id: selectedPatientId,
      patientNumber: formData.patientNumber,      // custom 4-digit number
      name: formData.name.trim(),
      phone: formData.phone.trim(),
      age: formData.age ? parseInt(formData.age) : undefined,
      gender: formData.gender || undefined,
      address: formData.address?.trim() || undefined,
      openingBalance,
      isExistingPatient,
      isEditing,
    };

    console.log('Submitting:', submitData);
    onSubmit(submitData);
    // toast.success message is already handled in parent
  };

  const handleClear = () => {
    const newNumber = generateNextSequentialNumber();
    setFormData({
      patientNumber: newNumber,
      name: '',
      phone: '',
      age: '',
      gender: '',
      address: '',
      openingBalance: '0'
    });
    setSearchQuery('');
    setLastGeneratedId(newNumber);
    setIsExistingPatient(false);
    setSelectedPatientId(undefined);
    setIdError('');
  };

  const handleGenerateNewNumber = () => {
    if (isExistingPatient) return;
    const newNumber = generateNextSequentialNumber();
    setFormData(prev => ({ ...prev, patientNumber: newNumber }));
    setLastGeneratedId(newNumber);
    setIdError('');
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-md max-h-[92vh] overflow-y-auto shadow-2xl">
        <div className="flex items-center justify-between p-5 border-b sticky top-0 bg-white z-10">
          <h2 className="text-xl font-bold">{title}</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            disabled={loading}
            type="button"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-6">
          {/* Search Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label>Search Existing Patient</Label>
              {searchQuery && (
                <button
                  type="button"
                  onClick={handleClear}
                  className="text-sm text-blue-600 hover:text-blue-800"
                >
                  Clear
                </button>
              )}
            </div>

            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Name, phone or number (e.g. 0001)"
                className="pl-10"
                disabled={loading}
              />
            </div>

            {isExistingPatient && (
              <div className="text-xs bg-green-50 text-green-700 px-3 py-1.5 rounded-md inline-flex items-center gap-1.5">
                <span className="font-medium">✓ Existing Patient</span>
              </div>
            )}

            {/* Dropdown */}
            {showDropdown && (
              // console.log('Filtered Patients:', filteredPatients[0] ? filteredPatients.map(p => p.patientNumber) : 'None'),
              <div className="absolute z-50 w-full bg-white border rounded-lg shadow-xl mt-1 max-h-64 overflow-y-auto divide-y">
                {filteredPatients.length > 0 ? (
                  filteredPatients.map(p => (
                    // console.log('Rendering Patient:', p),
                    <div
                      key={p.id}
                      onClick={() => handleSelectPatient(p)}
                      className="px-4 py-3 hover:bg-gray-50 cursor-pointer flex items-center gap-3 transition-colors"
                    >
                      <User className="w-5 h-5 text-blue-600 flex-shrink-0" />
                      <div className="min-w-0 flex-1">
                        <div className="font-medium truncate">{p.name}</div>
                        <div className="text-sm text-gray-600 flex flex-wrap gap-x-3 gap-y-1 mt-0.5">
                          <span>Number: <strong>{p.patientNumber || '—'}</strong></span>
                          <span>Ph: {p.phone}</span>
                          {p.openingBalance !== undefined && p.openingBalance !== 0 && (
                            <span className={p.openingBalance > 0 ? 'text-red-600' : 'text-emerald-600'}>
                              Bal: {p.openingBalance > 0 ? '+' : ''}{p.openingBalance.toFixed(2)}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-6 text-center text-gray-500">
                    No matching patient found
                    <div className="text-xs mt-2 text-gray-400">
                      Register as new patient below
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Patient Number */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="patientNumber" className="flex items-center gap-1.5">
                Patient Number <span className="text-red-500">*</span>
                <span className="text-xs text-gray-500 font-normal">
                  ({isExistingPatient ? 'existing' : 'new'})
                </span>
              </Label>

              {!isExistingPatient && (
                <button
                  type="button"
                  onClick={handleGenerateNewNumber}
                  className="text-xs flex items-center gap-1.5 text-blue-600 hover:text-blue-800"
                >
                  <RefreshCw size={13} />
                  Generate New
                </button>
              )}
            </div>

            <Input
              id="patientNumber"
              name="patientNumber"
              value={formData.patientNumber}
              onChange={handleChange}
              
              placeholder="0001"
              maxLength={4}
              pattern="[0-9]{4}"
              className="font-mono text-center text-lg tracking-wider"
              required
              disabled={loading || isExistingPatient}
            />

            {idError && (
              <p className="text-red-600 text-xs flex items-center gap-1.5">
                <AlertCircle size={14} />
                {idError}
              </p>
            )}

            {!isExistingPatient && (
              <p className="text-xs text-gray-500">
                Next available: <strong>{generateNextSequentialNumber()}</strong>
              </p>
            )}
          </div>

          {/* Patient Details */}
          <div className="space-y-4 pt-4 border-t">
            <h3 className="text-sm font-medium text-gray-700">Patient Details</h3>

            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Full Name <span className="text-red-500">*</span></Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Enter full name"
                  required
                  disabled={loading}
                />
              </div>

              <div>
                <Label htmlFor="phone">Phone Number <span className="text-red-500">*</span></Label>
                <Input
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="03001234567"
                  required
                  disabled={loading}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    name="age"
                    type="number"
                    value={formData.age}
                    onChange={handleChange}
                    placeholder="25"
                    min="0"
                    max="120"
                    disabled={loading}
                  />
                </div>

                <div>
                  <Label htmlFor="gender">Gender</Label>
                  <select
                    id="gender"
                    name="gender"
                    value={formData.gender}
                    onChange={handleChange}
                    className="w-full rounded-md border border-input px-3 py-2"
                    disabled={loading}
                  >
                    <option value="">Select</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <Label htmlFor="address">Address</Label>
                <Input
                  id="address"
                  name="address"
                  value={formData.address}
                  onChange={handleChange}
                  placeholder="House #, Street, Area"
                  disabled={loading}
                />
              </div>

              <div>
                <Label htmlFor="openingBalance" className="flex items-center gap-2">
                  <DollarSign size={16} />
                  Opening Balance
                </Label>
                <Input
                  id="openingBalance"
                  name="openingBalance"
                  value={formData.openingBalance}
                  onChange={handleChange}
                  placeholder="0.00"
                  disabled={loading}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Positive = due • Negative = advance
                </p>
              </div>
            </div>
          </div>

          {/* Buttons */}
          <div className="flex justify-end gap-3 pt-6 border-t">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={loading}
            >
              Cancel
            </Button>

            <Button
              type="submit"
              disabled={loading || !!idError}
              className={mode === 'walk-in' ? "bg-green-600 hover:bg-green-700" : "bg-blue-600 hover:bg-blue-700"}
            >
              {loading ? 'Saving...' : (
                mode === 'walk-in'
                  ? (isEditing ? 'Update & Add to Queue' : 'Add to Queue')
                  : (isEditing ? 'Update Patient' : 'Save Patient')
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}