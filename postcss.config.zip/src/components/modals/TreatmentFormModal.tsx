'use client';

import React, { useState, useEffect } from 'react';
import { X, Clock, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Treatment } from '@/types';

interface TreatmentFormModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (treatmentData: any) => void;
  treatment?: Treatment | null;
  isEditing?: boolean;
}

// Treatment categories
const categoryOptions = [
  'consultation',
  'cleaning',
  'restoration',
  'endodontics',
  'cosmetic',
  'prosthodontics',
  'surgery',
  'orthodontics',
  'pediatric',
  'other'
];

export default function TreatmentFormModal({
  open,
  onClose,
  onSubmit,
  treatment,
  isEditing = false
}: TreatmentFormModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    fee: '',
    category: 'consultation',
    duration: '',
    description: ''
  });

  useEffect(() => {
    if (treatment) {
      setFormData({
        name: treatment.name || '',
        fee: treatment.fee?.toString() || '',
        category: treatment.category || 'consultation',
        duration: treatment.duration?.toString() || '',
        description: treatment.description || ''
      });
    } else {
      // Reset form for new treatment
      setFormData({
        name: '',
        fee: '',
        category: 'consultation',
        duration: '',
        description: ''
      });
    }
  }, [treatment]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.name.trim()) {
      alert('Treatment name is required');
      return;
    }
    
    if (!formData.fee || parseFloat(formData.fee) <= 0) {
      alert('Valid fee is required');
      return;
    }
    
    if (!formData.duration || parseInt(formData.duration) <= 0) {
      alert('Valid duration is required');
      return;
    }
    
    onSubmit(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-semibold">
            {isEditing ? 'Edit Treatment' : 'Add New Treatment'}
          </h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {/* Treatment Name */}
          <div>
            <Label htmlFor="name">Treatment Name *</Label>
            <Input
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="e.g., Root Canal, Teeth Cleaning"
              required
            />
          </div>

          {/* Fee and Duration */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="fee" className="flex items-center gap-1">
                <DollarSign className="w-3 h-3" />
                Fee (USD) *
              </Label>
              <Input
                id="fee"
                name="fee"
                type="number"
                step="0.01"
                value={formData.fee}
                onChange={handleChange}
                placeholder="0.00"
                min="0"
                required
              />
            </div>
            <div>
              <Label htmlFor="duration" className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                Duration (minutes) *
              </Label>
              <Input
                id="duration"
                name="duration"
                type="number"
                value={formData.duration}
                onChange={handleChange}
                placeholder="30"
                min="1"
                required
              />
            </div>
          </div>

          {/* Category */}
          <div>
            <Label htmlFor="category">Category *</Label>
            <select
              id="category"
              name="category"
              value={formData.category}
              onChange={handleChange}
              className="w-full px-3 py-2 border rounded-lg"
              required
            >
              {categoryOptions.map(category => (
                <option key={category} value={category}>
                  {category.charAt(0).toUpperCase() + category.slice(1)}
                </option>
              ))}
            </select>
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              placeholder="Description of the treatment..."
              rows={3}
            />
          </div>

          {/* Buttons */}
          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button type="submit" className="bg-green-600 hover:bg-green-700">
              {isEditing ? 'Update Treatment' : 'Add Treatment'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}