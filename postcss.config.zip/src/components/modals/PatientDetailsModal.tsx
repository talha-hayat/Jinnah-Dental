'use client';

import React, { useState, useEffect } from 'react';
import {
  X,
  User,
  Phone,
  Calendar,
  MapPin,
  Activity,
  DollarSign,
  FileText,
  Edit,
  Trash2,
  Clock,
  UserCheck,
  AlertCircle,
  TrendingUp,
  CreditCard,
  History,
  ClipboardList,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Patient, QueueItem, Bill } from '@/types';
import { format, parseISO } from 'date-fns';
import { toast } from 'sonner';

interface PatientDetailsModalProps {
  patient: Patient;
  patientInfo?: Patient | null;
  onClose: () => void;
  onEdit: () => void;
  onDelete: () => void;
  showActions?: boolean;
  // Optional: Pass history data directly if not fetching in modal
  queueHistory?: QueueItem[];
  bills?: Bill[];
}

export default function PatientDetailsModal({
  patient,
  patientInfo,
  onClose,
  onEdit,
  onDelete,
  showActions = true,
  queueHistory = [],
  bills = []
}: PatientDetailsModalProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'queue' | 'payments' | 'bills'>('overview');
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<{
    queueHistory: QueueItem[];
    paymentHistory: Bill[];
    bills: Bill[];
  }>({
    queueHistory: [],
    paymentHistory: [],
    bills: []
  });

  // Use props if provided, otherwise fetch
  useEffect(() => {
    if (queueHistory.length > 0 || bills.length > 0) {
      // Use provided data
      setHistory({
        queueHistory: queueHistory || [],
        paymentHistory: bills || [],
        bills: bills || []
      });
    } else {
      // Fetch data (for backward compatibility)
      fetchPatientHistory();
    }
  }, [queueHistory, bills]);

  const fetchPatientHistory = async () => {
    try {
      setLoading(true);
      // You can keep your fetch logic here if needed
      // For now, we'll use empty arrays since data is passed via props
      setHistory({
        queueHistory: [],
        paymentHistory: [],
        bills: []
      });
    } catch (error) {
      console.error('Error fetching patient history:', error);
      toast.error('Failed to load patient history');
    } finally {
      setLoading(false);
    }
  };

  // Safely calculate statistics with defaults
  const totalTreatments = history?.queueHistory?.length || 0;
  const totalAmount = (history?.queueHistory || []).reduce((sum, item) => sum + (item.fee || 0), 0);
  const totalPaid = (history?.paymentHistory || []).reduce((sum, payment) => sum + (payment.amountPaid || 0), 0);
  const pendingAmount = totalAmount - totalPaid + ((patient?.openingBalance) || 0);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in_treatment': return 'bg-yellow-100 text-yellow-800';
      case 'waiting': return 'bg-blue-100 text-blue-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'bg-green-100 text-green-800';
      case 'partial': return 'bg-yellow-100 text-yellow-800';
      case 'pending': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (amount: number | undefined) => {
    const numAmount = amount || 0;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(numAmount);
  };

  const safeFormatDate = (dateString: string | undefined | null): string => {
    if (!dateString) return 'N/A';
    
    try {
      const date = parseISO(dateString);
      if (isNaN(date.getTime())) {
        return 'Invalid Date';
      }
      return format(date, 'MMM dd, yyyy hh:mm a');
    } catch (error) {
      try {
        const date = new Date(dateString);
        if (isNaN(date.getTime())) {
          return 'N/A';
        }
        return format(date, 'MMM dd, yyyy hh:mm a');
      } catch {
        return 'N/A';
      }
    }
  };

  // Don't render if patient is null
  if (!patient) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-6xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center gap-3">
            <User className="w-8 h-8 text-primary" />
            <div>
              <h2 className="text-2xl font-bold">{patient.name || 'N/A'}</h2>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <User className="w-3 h-3" />
                  ID: {patient.patientNumber || patient.id || 'N/A'}
                </span>
                <span>|</span>
                <span>Patient since {safeFormatDate(patient.createdAt)}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {showActions && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onEdit}
                  className="gap-2"
                >
                  <Edit className="w-4 h-4" />
                  Edit
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onDelete}
                  className="gap-2 text-red-600 border-red-200 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4" />
                  Delete
                </Button>
              </>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-8 w-8 p-0"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Stats Bar */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-6 bg-gray-50 border-b">
          <div className="bg-white rounded-lg p-4 border">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold text-blue-600">{totalTreatments}</div>
                <div className="text-sm text-gray-600">Total Treatments</div>
              </div>
              <Activity className="w-8 h-8 text-blue-500" />
            </div>
          </div>
          <div className="bg-white rounded-lg p-4 border">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold text-green-600">{formatCurrency(totalAmount)}</div>
                <div className="text-sm text-gray-600">Total Billed</div>
              </div>
              <TrendingUp className="w-8 h-8 text-green-500" />
            </div>
          </div>
          <div className="bg-white rounded-lg p-4 border">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold text-purple-600">{formatCurrency(totalPaid)}</div>
                <div className="text-sm text-gray-600">Total Paid</div>
              </div>
              <CreditCard className="w-8 h-8 text-purple-500" />
            </div>
          </div>
          <div className="bg-white rounded-lg p-4 border">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold text-orange-600">{formatCurrency(pendingAmount)}</div>
                <div className="text-sm text-gray-600">Pending Balance</div>
              </div>
              <AlertCircle className="w-8 h-8 text-orange-500" />
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b">
          <div className="flex space-x-1 px-6">
            <Button
              variant={activeTab === 'overview' ? 'default' : 'ghost'}
              onClick={() => setActiveTab('overview')}
              className="gap-2"
            >
              <User className="w-4 h-4" />
              Overview
            </Button>
            <Button
              variant={activeTab === 'queue' ? 'default' : 'ghost'}
              onClick={() => setActiveTab('queue')}
              className="gap-2"
            >
              <History className="w-4 h-4" />
              Queue History ({history?.queueHistory?.length || 0})
            </Button>
            <Button
              variant={activeTab === 'bills' ? 'default' : 'ghost'}
              onClick={() => setActiveTab('bills')}
              className="gap-2"
            >
              <ClipboardList className="w-4 h-4" />
              Bills ({history?.bills?.length || 0})
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
              <span className="ml-2">Loading patient history...</span>
            </div>
          ) : (
            <>
              {/* Overview Tab */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Personal Info */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold flex items-center gap-2">
                        <User className="w-5 h-5" />
                        Personal Information
                      </h3>
                      <div className="space-y-3">
                        <div className="flex items-center gap-3">
                          <Phone className="w-4 h-4 text-gray-500" />
                          <div>
                            <div className="text-sm text-gray-600">Phone</div>
                            <div className="font-medium">{patient.phone || 'N/A'}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Calendar className="w-4 h-4 text-gray-500" />
                          <div>
                            <div className="text-sm text-gray-600">Age / Gender</div>
                            <div className="font-medium">{patient.age || 0} years / {(patient.gender || 'N/A')}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <MapPin className="w-4 h-4 text-gray-500" />
                          <div>
                            <div className="text-sm text-gray-600">Address</div>
                            <div className="font-medium">{patient.address || 'N/A'}</div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Financial Summary */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold flex items-center gap-2">
                        <DollarSign className="w-5 h-5" />
                        Financial Summary
                      </h3>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-gray-600">Opening Balance:</span>
                          <span className={`font-medium ${(patient.openingBalance || 0) > 0 ? 'text-red-600' : 'text-gray-800'}`}>
                            {formatCurrency(patient.openingBalance)}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-gray-600">Total Billed:</span>
                          <span className="font-medium text-green-600">{formatCurrency(totalAmount)}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-gray-600">Total Paid:</span>
                          <span className="font-medium text-blue-600">{formatCurrency(totalPaid)}</span>
                        </div>
                        <div className="flex justify-between items-center pt-2 border-t">
                          <span className="font-semibold">Current Balance:</span>
                          <span className={`font-bold text-lg ${pendingAmount > 0 ? 'text-red-600' : 'text-green-600'}`}>
                            {formatCurrency(pendingAmount)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Recent Queue History */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold flex items-center gap-2">
                      <History className="w-5 h-5" />
                      Recent Queue History
                    </h3>
                    {history?.queueHistory && history.queueHistory.length > 0 ? (
                      <div className="border rounded-lg overflow-hidden">
                        <table className="w-full">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="text-left p-3 text-sm font-medium">Date</th>
                              <th className="text-left p-3 text-sm font-medium">Treatment</th>
                              <th className="text-left p-3 text-sm font-medium">Status</th>
                              <th className="text-left p-3 text-sm font-medium">Fee</th>
                              <th className="text-left p-3 text-sm font-medium">Doctor</th>
                            </tr>
                          </thead>
                          <tbody>
                            {history.queueHistory.slice(0, 5).map((item) => (
                              <tr key={item.id} className="border-t hover:bg-gray-50">
                                <td className="p-3 text-sm">
                                  {safeFormatDate(item.checkInTime)}
                                </td>
                                <td className="p-3 text-sm">{item.treatment || 'Not specified'}</td>
                                <td className="p-3">
                                  <Badge className={getStatusColor(item.status || '')}>
                                    {(item.status || '').replace('_', ' ').toUpperCase()}
                                  </Badge>
                                </td>
                                <td className="p-3 text-sm">{formatCurrency(item.fee)}</td>
                                <td className="p-3 text-sm">{item.doctor || 'Not assigned'}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        No queue history found
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Queue History Tab */}
              {activeTab === 'queue' && (
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Complete Queue History</h3>
                  {history?.queueHistory && history.queueHistory.length > 0 ? (
                    <div className="border rounded-lg overflow-hidden">
                      <table className="w-full">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="text-left p-3 text-sm font-medium">Date</th>
                            <th className="text-left p-3 text-sm font-medium">Token</th>
                            <th className="text-left p-3 text-sm font-medium">Treatment</th>
                            <th className="text-left p-3 text-sm font-medium">Status</th>
                            <th className="text-left p-3 text-sm font-medium">Fee</th>
                            <th className="text-left p-3 text-sm font-medium">Payment</th>
                            <th className="text-left p-3 text-sm font-medium">Doctor</th>
                          </tr>
                        </thead>
                        <tbody>
                          {history.queueHistory.map((item) => (
                            <tr key={item.id} className="border-t hover:bg-gray-50">
                              <td className="p-3 text-sm">
                                {safeFormatDate(item.checkInTime)}
                              </td>
                              <td className="p-3 text-sm font-medium">#{item.tokenNumber || 0}</td>
                              <td className="p-3 text-sm">{item.treatment || 'Not specified'}</td>
                              <td className="p-3">
                                <Badge className={getStatusColor(item.status || '')}>
                                  {(item.status || '').replace('_', ' ').toUpperCase()}
                                </Badge>
                              </td>
                              <td className="p-3 text-sm">{formatCurrency(item.fee)}</td>
                              <td className="p-3">
                                <Badge className={getPaymentStatusColor(item.paymentStatus || '')}>
                                  {(item.paymentStatus || '').toUpperCase()}
                                </Badge>
                              </td>
                              <td className="p-3 text-sm">{item.doctor || 'Not assigned'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-12 text-gray-500">
                      <Activity className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                      <p>No queue history found for this patient</p>
                    </div>
                  )}
                </div>
              )}

              {/* Bills Tab */}
              {activeTab === 'bills' && (
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Bill History</h3>
                  {history?.bills && history.bills.length > 0 ? (
                    <div className="space-y-3">
                      {history.bills.map((bill) => (
                        <div key={bill.id} className="border rounded-lg p-4 hover:bg-gray-50">
                          <div className="flex justify-between items-start">
                            <div>
                              <div className="font-medium flex items-center gap-2">
                                <FileText className="w-4 h-4" />
                                {bill.billNumber || 'N/A'}
                              </div>
                              <div className="text-sm text-gray-600">
                                {safeFormatDate(bill.createdDate)}
                              </div>
                              <div className="mt-2">
                                <div className="font-medium">{bill.treatment || 'N/A'}</div>
                                {bill.notes && (
                                  <div className="text-sm text-gray-500">{bill.notes}</div>
                                )}
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="space-y-2">
                                <div>
                                  <div className="text-sm text-gray-600">Total</div>
                                  <div className="font-bold text-lg">
                                    {formatCurrency(bill.totalAmount)}
                                  </div>
                                </div>
                                <div>
                                  <div className="text-sm text-gray-600">Paid</div>
                                  <div className="font-medium text-green-600">
                                    {formatCurrency(bill.amountPaid)}
                                  </div>
                                </div>
                                <Badge className={getPaymentStatusColor(bill.paymentStatus || '')}>
                                  {(bill.paymentStatus || '').toUpperCase()}
                                </Badge>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12 text-gray-500">
                      <ClipboardList className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                      <p>No bills found</p>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-between items-center p-4 border-t">
          <div className="text-sm text-gray-600">
            Last updated: {patient.updatedAt ? safeFormatDate(patient.updatedAt) : 'Never'}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}