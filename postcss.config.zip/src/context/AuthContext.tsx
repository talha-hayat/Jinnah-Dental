import React, { createContext, useContext, useState, useCallback, ReactNode, useEffect } from 'react';
import { User, UserRole, AuthState } from '@/types';

interface AuthContextType extends AuthState {
  login: (role: UserRole, password: string) => Promise<boolean>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Demo credentials - in production, these would be securely stored
const DEMO_CREDENTIALS = {
  operator: '123',
  admin: '123',
};

const DEMO_USERS: Record<UserRole, User> = {
  operator: {
    id: 'op-001',
    role: 'operator',
    name: 'Front Desk Operator',
  },
  admin: {
    id: 'admin-001',
    role: 'admin',
    name: 'Clinic Administrator',
  },
};

// Session storage keys
const AUTH_STORAGE_KEY = 'clinic_auth_state';

export function AuthProvider({ children }: { children: ReactNode }) {
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    user: null,
  });

  // Initialize auth state from sessionStorage on component mount
  useEffect(() => {
    const savedAuthState = sessionStorage.getItem(AUTH_STORAGE_KEY);
    if (savedAuthState) {
      try {
        const parsedState = JSON.parse(savedAuthState);
        setAuthState(parsedState);
      } catch (error) {
        console.error('Failed to parse saved auth state:', error);
        sessionStorage.removeItem(AUTH_STORAGE_KEY);
      }
    }
  }, []);

  // Save auth state to sessionStorage whenever it changes
  useEffect(() => {
    if (authState.isAuthenticated && authState.user) {
      sessionStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(authState));
    } else {
      sessionStorage.removeItem(AUTH_STORAGE_KEY);
    }
  }, [authState]);

  const login = useCallback(async (role: UserRole, password: string): Promise<boolean> => {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 500));

    if (DEMO_CREDENTIALS[role] === password) {
      const newAuthState = {
        isAuthenticated: true,
        user: DEMO_USERS[role],
      };
      setAuthState(newAuthState);
      return true;
    }
    return false;
  }, []);

  const logout = useCallback(() => {
    const newAuthState = {
      isAuthenticated: false,
      user: null,
    };
    setAuthState(newAuthState);
    sessionStorage.removeItem(AUTH_STORAGE_KEY);
  }, []);

  // Clear auth state on page refresh/reload for specific scenarios
  useEffect(() => {
    const handleBeforeUnload = () => {
      // Agar aap chahte hain ki refresh par bhi logout ho jaye, to isko use karein
      // sessionStorage.removeItem(AUTH_STORAGE_KEY);
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []);

  return (
    <AuthContext.Provider value={{ ...authState, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}