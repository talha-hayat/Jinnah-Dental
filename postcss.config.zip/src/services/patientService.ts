import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  getDocs,
  query,
  orderBy,
  Timestamp,
  serverTimestamp
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Patient } from "@/types";

const patientsRef = collection(db, "patients");

export const getAllPatients = async (): Promise<Patient[]> => {
  try {
    const patientsCol = collection(db, 'patients');
    const snapshot = await getDocs(patientsCol);

    const patients = snapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        patientNumber: data.patientNumber || undefined,
        name: data.name || '',
        phone: data.phone || '',
        age: data.age || undefined,
        gender: data.gender || undefined,
        address: data.address || undefined,
        openingBalance: data.openingBalance || 0,
        createdAt: data.createdAt?.toDate?.() || data.createdAt, // Timestamp ko Date mein convert
        ...data  // ← yeh line sab kuch laa degi (future-proof)
      } as Patient;
    });

    return patients;
  } catch (error) {
    console.error("Error getting patients:", error);
    return [];
  }
};
export const addPatient = async (data: Omit<Patient, "id">): Promise<string> => {
  try {
    const docRef = await addDoc(patientsRef, {
      ...data,
      createdAt: Timestamp.now()
    });
    return docRef.id;
  } catch (error) {
    console.error("Error adding patient:", error);
    throw error;
  }
};

export const updatePatient = async (id: string, data: Partial<Patient>) => {
  try {
    const patientRef = doc(db, "patients", id);
    await updateDoc(patientRef, data);
  } catch (error) {
    console.error("Error updating patient:", error);
    throw error;
  }
};

export const deletePatient = async (id: string) => {
  try {
    await deleteDoc(doc(db, "patients", id));
  } catch (error) {
    console.error("Error deleting patient:", error);
    throw error;
  }
};



// Add to existing patientService.ts

// Get patient stats from queue and bills
export const getPatientStats = async (patientNumber: string) => {
  try {
    // Import these functions if not already imported
    const { getQueueItemsByPatientNumber } = await import('./queueService');
    const { getBillsByPatientNumber } = await import('./billingService');
    
    const [queueItems, bills] = await Promise.all([
      getQueueItemsByPatientNumber(patientNumber),
      getBillsByPatientNumber(patientNumber)
    ]);
    
    const totalVisits = queueItems.filter(item => item.status === 'completed').length;
    const totalBilled = queueItems.reduce((sum, item) => sum + (item.fee || 0), 0);
    const totalPaid = bills.reduce((sum, bill) => sum + (bill.amountPaid || 0), 0);
    
    return {
      totalVisits,
      totalBilled,
      totalPaid
    };
  } catch (error) {
    console.error('Error getting patient stats:', error);
    return {
      totalVisits: 0,
      totalBilled: 0,
      totalPaid: 0
    };
  }
};

// Update patient with real-time stats
export const updatePatientWithStats = async (patientId: string) => {
  try {
    // Get patient first
    const patient = await getPatientById(patientId);
    if (!patient) return null;
    
    // Get stats
    const stats = await getPatientStats(patient.patientNumber);
    
    // Calculate pending balance
    const pendingBalance = stats.totalBilled - stats.totalPaid + (patient.openingBalance || 0);
    
    // Update patient
    const updateData = {
      totalVisits: stats.totalVisits,
      totalPaid: stats.totalPaid,
      pendingBalance: pendingBalance,
      updatedAt: serverTimestamp()
    };
    
    await updatePatient(patientId, updateData);
    
    return {
      ...patient,
      ...updateData
    };
  } catch (error) {
    console.error('Error updating patient with stats:', error);
    throw error;
  }
};