import { db } from '@/lib/firebase';
import { Patient, QueueItem, Bill } from '@/types';
import { 
  doc, 
  updateDoc, 
  collection, 
  query, 
  where, 
  getDocs,
  serverTimestamp 
} from 'firebase/firestore';

// Sync patient stats after queue item is completed
export const syncPatientAfterTreatment = async (patientNumber: string) => {
  try {
    // 1. Find patient by patientNumber
    const patientsRef = collection(db, 'patients');
    const patientQuery = query(patientsRef, where('patientNumber', '==', patientNumber));
    const patientSnapshot = await getDocs(patientQuery);
    
    if (patientSnapshot.empty) {
      console.warn(`Patient ${patientNumber} not found`);
      return;
    }
    
    const patientDoc = patientSnapshot.docs[0];
    const patientId = patientDoc.id;
    const currentPatient = patientDoc.data() as Patient;
    
    // 2. Get all queue items for this patient
    const queueRef = collection(db, 'queue');
    const queueQuery = query(queueRef, where('patientNumber', '==', patientNumber));
    const queueSnapshot = await getDocs(queueQuery);
    
    // 3. Get all bills for this patient
    const billsRef = collection(db, 'bills');
    const billsQuery = query(billsRef, where('patientId', '==', patientNumber));
    const billsSnapshot = await getDocs(billsQuery);
    
    // 4. Calculate new stats
    const queueItems = queueSnapshot.docs.map(doc => doc.data() as QueueItem);
    const bills = billsSnapshot.docs.map(doc => doc.data() as Bill);
    
    // Calculate totals
    const totalVisits = queueItems.filter(item => item.status === 'completed').length;
    const totalBilled = queueItems.reduce((sum, item) => sum + (item.fee || 0), 0);
    const totalPaid = bills.reduce((sum, bill) => sum + (bill.amountPaid || 0), 0);
    const pendingBalance = totalBilled - totalPaid + (currentPatient.openingBalance || 0);
    
    // Find most recent visit
    const completedVisits = queueItems.filter(item => item.status === 'completed');
    const lastVisit = completedVisits.length > 0 
      ? completedVisits.sort((a, b) => 
          new Date(b.treatmentEndTime || b.checkInTime).getTime() - 
          new Date(a.treatmentEndTime || a.checkInTime).getTime()
        )[0].treatmentEndTime || completedVisits[0].checkInTime
      : undefined;
    
    // 5. Update patient document
    const updateData = {
      totalVisits,
      totalPaid,
      pendingBalance,
      ...(lastVisit && { lastVisit }),
      updatedAt: serverTimestamp()
    };
    
    await updateDoc(doc(db, 'patients', patientId), updateData);
    
    console.log(`Synced patient ${patientNumber}:`, {
      visits: totalVisits,
      billed: totalBilled,
      paid: totalPaid,
      pending: pendingBalance
    });
    
    return updateData;
  } catch (error) {
    console.error('Error syncing patient:', error);
    throw error;
  }
};

// Sync all patients (for batch updates)
export const syncAllPatients = async () => {
  try {
    const patientsRef = collection(db, 'patients');
    const patientsSnapshot = await getDocs(patientsRef);
    
    const results = [];
    
    for (const patientDoc of patientsSnapshot.docs) {
      const patient = patientDoc.data() as Patient;
      try {
        const result = await syncPatientAfterTreatment(patient.patientNumber);
        results.push({
          patientNumber: patient.patientNumber,
          success: true,
          data: result
        });
      } catch (error) {
        results.push({
          patientNumber: patient.patientNumber,
          success: false,
          error: error.message
        });
      }
    }
    
    return results;
  } catch (error) {
    console.error('Error syncing all patients:', error);
    throw error;
  }
};