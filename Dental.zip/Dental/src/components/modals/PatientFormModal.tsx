'use client';

import React, { useState, useEffect } from 'react';
import { X, DollarSign, UserPlus, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Patient, Treatment } from '@/types';

interface PatientFormModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void; // Changed from onSave to onSubmit
  patient: Patient | null;
  isEditing: boolean;
  treatments?: Treatment[];
  doctors?: string[];
  mode?: 'patient' | 'walk-in';
  existingPatients?: Patient[];
  title?: string;
}

export default function PatientFormModal({
  open,
  onClose,
  onSubmit, // Changed from onSave
  patient,
  isEditing,
  treatments = [],
  doctors = [],
  mode = 'patient',
  existingPatients = [],
  title
}: PatientFormModalProps) {
  const [formData, setFormData] = useState<Partial<Patient>>({
    name: '',
    phone: '',
    age: '',
    gender: '',
    address: '',
    medicalHistory: ''
  });

  const [treatmentData, setTreatmentData] = useState({
    treatment: '',
    doctor: '',
    priority: 'normal',
    notes: ''
  });

  const [selectedTreatmentFee, setSelectedTreatmentFee] = useState(0);
  const [showExistingPatients, setShowExistingPatients] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Reset on close
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    if (open) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'auto';
    };
  }, [open, onClose]);

  // Initialize form when modal opens
  useEffect(() => {
    if (open) {
      if (patient && isEditing) {
        setFormData(patient);
      } else {
        setFormData({
          name: '',
          phone: '',
          age: '',
          gender: '',
          address: '',
          medicalHistory: ''
        });
        setTreatmentData({
          treatment: '',
          doctor: '',
          priority: 'normal',
          notes: ''
        });
        setSelectedTreatmentFee(0);
        setShowExistingPatients(false);
        setSearchTerm('');
      }
    }
  }, [open, patient, isEditing]);

  // Update fee when treatment changes
  useEffect(() => {
    if (treatmentData.treatment) {
      const treatment = treatments.find(t => t.name === treatmentData.treatment);
      setSelectedTreatmentFee(treatment?.fee || 0);
    } else {
      setSelectedTreatmentFee(0);
    }
  }, [treatmentData.treatment, treatments]);

  // Filter existing patients
  const filteredPatients = existingPatients.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.phone.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name.startsWith('treatment_')) {
      const fieldName = name.replace('treatment_', '');
      setTreatmentData(prev => ({ ...prev, [fieldName]: value }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSelectPatient = (selectedPatient: Patient) => {
    setFormData(selectedPatient);
    setShowExistingPatients(false);
    setSearchTerm('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name?.trim()) {
      alert('Please enter patient name');
      return;
    }
    
    if (!formData.phone?.trim()) {
      alert('Please enter phone number');
      return;
    }
    
    if (mode === 'walk-in' && !treatmentData.treatment) {
      alert('Please select a treatment');
      return;
    }
    
    const submitData = {
      ...formData,
      ...(mode === 'walk-in' && {
        ...treatmentData,
        fee: selectedTreatmentFee
      }),
      mode: mode
    };
    
    onSubmit(submitData); // Changed from onSave
    onClose(); // Close modal after submit
  };

  // Handle click outside to close
  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  if (!open) return null;

  return (
    <div 
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      onClick={handleBackdropClick}
    >
      <div className="bg-white rounded-lg w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b sticky top-0 bg-white">
          <h2 className="text-lg font-semibold">
            {title || (mode === 'walk-in' ? 'Walk-in Patient' : 
                      isEditing ? 'Edit Patient' : 'Add New Patient')}
          </h2>
          <button 
            onClick={onClose} 
            className="p-1 hover:bg-gray-100 rounded"
            type="button"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {/* Select Existing Patient Button - Only for walk-in mode */}
          {mode === 'walk-in' && existingPatients.length > 0 && !showExistingPatients && !isEditing && (
            <div className="mb-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowExistingPatients(true)}
                className="w-full gap-2"
              >
                <Users className="w-4 h-4" />
                Select Existing Patient
              </Button>
              <p className="text-xs text-center text-muted-foreground mt-2">
                OR fill the form below for new patient
              </p>
            </div>
          )}

          {/* Existing Patients Search - Only for walk-in mode */}
          {showExistingPatients && (
            <div className="space-y-3 border rounded-lg p-3">
              <div className="flex items-center justify-between">
                <h3 className="font-medium">Select Existing Patient</h3>
                <button
                  type="button"
                  onClick={() => setShowExistingPatients(false)}
                  className="text-sm text-blue-600 hover:text-blue-700"
                >
                  Back to form
                </button>
              </div>
              
              <div className="relative">
                <Input
                  placeholder="Search by name or phone..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9"
                />
              </div>
              
              <div className="max-h-60 overflow-y-auto border rounded">
                {filteredPatients.length === 0 ? (
                  <div className="p-4 text-center text-muted-foreground">
                    No patients found
                  </div>
                ) : (
                  filteredPatients.map(p => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => handleSelectPatient(p)}
                      className="w-full p-3 text-left hover:bg-gray-50 border-b last:border-0"
                    >
                      <div className="font-medium">{p.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {p.phone} • {p.age} years • {p.gender}
                      </div>
                    </button>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Patient Information */}
          {!showExistingPatients && (
            <>
              <div className="space-y-3">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    placeholder="John Doe"
                    disabled={isEditing}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    placeholder="+1 (555) 123-4567"
                    disabled={isEditing}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="age">Age</Label>
                    <Input
                      id="age"
                      name="age"
                      type="number"
                      value={formData.age}
                      onChange={handleChange}
                      placeholder="30"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="gender">Gender</Label>
                    <select
                      id="gender"
                      name="gender"
                      value={formData.gender}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border rounded-lg"
                    >
                      <option value="">Select</option>
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <Input
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    placeholder="Street, City"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="medicalHistory">Medical History</Label>
                  <Textarea
                    id="medicalHistory"
                    name="medicalHistory"
                    value={formData.medicalHistory}
                    onChange={handleChange}
                    placeholder="Any medical conditions or allergies..."
                    rows={2}
                  />
                </div>
              </div>

              {/* Treatment Details - Only for walk-in mode */}
              {mode === 'walk-in' && (
                <div className="space-y-3 border-t pt-4">
                  <h3 className="font-medium">Treatment Details</h3>
                  
                  <div className="space-y-2">
                    <Label htmlFor="treatment_treatment">Treatment *</Label>
                    <select
                      id="treatment_treatment"
                      name="treatment_treatment"
                      value={treatmentData.treatment}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border rounded-lg"
                      required={mode === 'walk-in'}
                    >
                      <option value="">Select Treatment</option>
                      {treatments.map(treatment => (
                        <option key={treatment.id} value={treatment.name}>
                          {treatment.name} - ${treatment.fee}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Fee Display */}
                  {selectedTreatmentFee > 0 && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <DollarSign className="w-4 h-4 text-blue-600" />
                          <span className="font-medium">Treatment Fee:</span>
                        </div>
                        <span className="text-lg font-bold text-blue-700">${selectedTreatmentFee}</span>
                      </div>
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="treatment_doctor">Doctor</Label>
                    <select
                      id="treatment_doctor"
                      name="treatment_doctor"
                      value={treatmentData.doctor}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border rounded-lg"
                    >
                      <option value="">Select Doctor</option>
                      {doctors.map(doctor => (
                        <option key={doctor} value={doctor}>{doctor}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="treatment_priority">Priority</Label>
                    <select
                      id="treatment_priority"
                      name="treatment_priority"
                      value={treatmentData.priority}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border rounded-lg"
                    >
                      <option value="normal">Normal</option>
                      <option value="urgent">Urgent</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="treatment_notes">Notes</Label>
                    <Textarea
                      id="treatment_notes"
                      name="treatment_notes"
                      value={treatmentData.notes}
                      onChange={handleChange}
                      placeholder="Any special instructions..."
                      rows={2}
                    />
                  </div>
                </div>
              )}
            </>
          )}

          {/* Submit Button */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className={mode === 'walk-in' ? 'bg-green-600 hover:bg-green-700' : ''}
            >
              {mode === 'walk-in' ? 'Add to Queue' : 
               isEditing ? 'Update' : 'Save Patient'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}