'use client';

import React, { useState, useEffect } from 'react';
import { X, DollarSign, Receipt, History } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { QueueItem, Bill } from '@/types';

interface PaymentModalProps {
  queueItem: QueueItem;
  bills: Bill[];
  onClose: () => void;
  onSubmit: (queueItem: QueueItem, data: any) => void;
}

export default function PaymentModal({ queueItem, bills, onClose, onSubmit }: PaymentModalProps) {
  const [paymentData, setPaymentData] = useState({
    amount: 0,
    paymentMethod: 'cash',
    discount: 0,
    notes: ''
  });

  const [totalFee, setTotalFee] = useState(0);
  const [remainingAmount, setRemainingAmount] = useState(0);
  const [previousPending, setPreviousPending] = useState(0);

  // Safe number conversion helper
  const toNumber = (value: any): number => {
    if (value === null || value === undefined) return 0;
    const num = Number(value);
    return isNaN(num) ? 0 : num;
  };

  // Initialize values
  useEffect(() => {
    const paidAmount = toNumber(queueItem.amountPaid);
    const fee = toNumber(queueItem.fee);
    const pending = toNumber(queueItem.previousPending);
    
    setTotalFee(fee);
    setPreviousPending(pending);
    
    const totalDue = fee + pending;
    const remaining = Math.max(0, totalDue - paidAmount);
    
    setRemainingAmount(remaining);
    setPaymentData(prev => ({ 
      ...prev, 
      amount: remaining 
    }));
  }, [queueItem]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name === 'discount' || name === 'amount') {
      setPaymentData(prev => ({ 
        ...prev, 
        [name]: parseFloat(value) || 0 
      }));
    } else {
      setPaymentData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const paymentAmount = toNumber(paymentData.amount);
    if (paymentAmount <= 0) {
      alert('Please enter a valid amount');
      return;
    }
    
    if (paymentAmount > remainingAmount) {
      alert(`Payment cannot exceed remaining amount of $${remainingAmount.toFixed(2)}`);
      return;
    }
    
    onSubmit(queueItem, {
      ...paymentData,
      amount: paymentAmount,
      discount: toNumber(paymentData.discount)
    });
  };

  const handleFullPayment = () => {
    setPaymentData(prev => ({ 
      ...prev, 
      amount: remainingAmount 
    }));
  };

  const calculateTax = () => {
    return totalFee * 0.05; // 5% tax
  };

  const calculateTotal = () => {
    const tax = calculateTax();
    return totalFee + tax - toNumber(paymentData.discount);
  };

  const patientBills = bills.filter(bill => bill.patientId === queueItem.patientId);
  const totalPaid = patientBills.reduce((sum, bill) => sum + toNumber(bill.amountPaid), 0);

  const paidAmount = toNumber(queueItem.amountPaid);
  const discountAmount = toNumber(paymentData.discount);
  const totalDue = totalFee + previousPending;
  const currentRemaining = Math.max(0, totalDue - paidAmount);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b sticky top-0 bg-white">
          <h2 className="text-lg font-semibold">Payment for {queueItem.patientName}</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Patient Info */}
          <div className="bg-gray-50 border rounded-lg p-3">
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <div className="text-muted-foreground">Patient</div>
                <div className="font-medium">{queueItem.patientName}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Phone</div>
                <div className="font-medium">{queueItem.phone}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Treatment</div>
                <div className="font-medium">{queueItem.treatment}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Token</div>
                <div className="font-medium">#{queueItem.tokenNumber}</div>
              </div>
            </div>
          </div>

          {/* Payment History */}
          {patientBills.length > 0 && (
            <div className="border rounded-lg p-3">
              <div className="flex items-center gap-2 mb-2">
                <History className="w-4 h-4" />
                <h3 className="font-medium">Payment History</h3>
              </div>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {patientBills.map(bill => (
                  <div key={bill.id} className="flex items-center justify-between text-sm p-2 bg-gray-50 rounded">
                    <div>
                      <div className="font-medium">{bill.billNumber}</div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(bill.createdDate).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">${toNumber(bill.amountPaid).toFixed(2)}</div>
                      <div className={`text-xs ${
                        bill.paymentStatus === 'paid' ? 'text-green-600' : 
                        bill.paymentStatus === 'partial' ? 'text-yellow-600' : 'text-red-600'
                      }`}>
                        {bill.paymentStatus}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex justify-between items-center pt-2 mt-2 border-t">
                <div className="font-medium">Total Paid:</div>
                <div className="font-bold">${totalPaid.toFixed(2)}</div>
              </div>
            </div>
          )}

          {/* Bill Summary */}
          <div className="border rounded-lg p-3">
            <h3 className="font-medium mb-3">Bill Summary</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Treatment Fee:</span>
                <span>${totalFee.toFixed(2)}</span>
              </div>
              
              {previousPending > 0 && (
                <div className="flex justify-between text-orange-600">
                  <span>Previous Pending:</span>
                  <span>${previousPending.toFixed(2)}</span>
                </div>
              )}
              
              <div className="flex justify-between">
                <span>Tax (5%):</span>
                <span>${calculateTax().toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between">
                <span>Discount:</span>
                <span>-${discountAmount.toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between pt-2 border-t font-bold text-lg">
                <span>Total Due:</span>
                <span>${calculateTotal().toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between text-green-600">
                <span>Already Paid:</span>
                <span>${paidAmount.toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between text-red-600 font-bold">
                <span>Remaining Amount:</span>
                <span>${currentRemaining.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Payment Form */}
          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="space-y-2">
              <Label htmlFor="amount">Payment Amount *</Label>
              <div className="flex gap-2">
                <Input
                  id="amount"
                  name="amount"
                  type="number"
                  value={paymentData.amount}
                  onChange={handleChange}
                  required
                  min="0"
                  step="0.01"
                  max={currentRemaining}
                  className="flex-1"
                />
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={handleFullPayment}
                  disabled={currentRemaining <= 0}
                >
                  Full Amount
                </Button>
              </div>
              <p className="text-sm text-muted-foreground">
                Max: ${currentRemaining.toFixed(2)}
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="discount">Discount</Label>
              <Input
                id="discount"
                name="discount"
                type="number"
                value={paymentData.discount}
                onChange={handleChange}
                min="0"
                step="0.01"
                max={totalFee}
                placeholder="0"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="paymentMethod">Payment Method</Label>
              <select
                id="paymentMethod"
                name="paymentMethod"
                value={paymentData.paymentMethod}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg"
              >
                <option value="cash">Cash</option>
                <option value="card">Credit/Debit Card</option>
              </select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Input
                id="notes"
                name="notes"
                value={paymentData.notes}
                onChange={handleChange}
                placeholder="Payment notes..."
              />
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 pt-4 border-t">
              <Button type="button" variant="outline" onClick={onClose} className="flex-1">
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="flex-1 bg-green-600 hover:bg-green-700 gap-2"
                disabled={currentRemaining <= 0}
              >
                <DollarSign className="w-4 h-4" />
                Process Payment
              </Button>
              {paidAmount > 0 && (
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => {
                    const latestBill = patientBills[0];
                    if (latestBill) {
                      console.log('Printing existing bill:', latestBill);
                    }
                  }}
                  className="gap-2"
                >
                  <Receipt className="w-4 h-4" />
                  Print Bill
                </Button>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}