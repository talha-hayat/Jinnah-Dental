import React from 'react';
import { 
  X, 
  Phone, 
  Calendar, 
  DollarSign, 
  FileText,
  MapPin,
  User,
  CheckCircle,
  Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Patient, Payment } from '@/types';

interface PatientDetailsModalProps {
  patient: Patient;
  payments: Payment[];
  onClose: () => void;
}

export default function PatientDetailsModal({ patient, payments, onClose }: PatientDetailsModalProps) {
  const totalPaid = payments
    .filter(p => p.status === 'paid')
    .reduce((sum, p) => sum + p.amount, 0);

  const lastPayment = payments[0];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
              <User className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h2 className="text-xl font-bold">{patient.name}</h2>
              <p className="text-sm text-muted-foreground">Patient Details</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-6">
          {/* Basic Information */}
          <div>
            <h3 className="font-semibold mb-3">Basic Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <span>{patient.phone}</span>
                </div>
                <div className="text-sm">
                  <span className="font-medium">Age:</span> {patient.age}
                </div>
                <div className="text-sm">
                  <span className="font-medium">Gender:</span> {patient.gender}
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span>{patient.address}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                  <span>Joined: {new Date(patient.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Medical History */}
          {patient.medicalHistory && (
            <div>
              <h3 className="font-semibold mb-2 flex items-center gap-2">
                <FileText className="w-4 h-4" />
                Medical History
              </h3>
              <div className="bg-gray-50 border rounded-lg p-3 text-sm">
                {patient.medicalHistory}
              </div>
            </div>
          )}

          {/* Payment Summary */}
          <div>
            <h3 className="font-semibold mb-3 flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              Payment Summary
            </h3>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-blue-700">${totalPaid}</div>
                  <div className="text-sm text-blue-600">Total Paid</div>
                </div>
                <div>
                  <div className="text-lg font-semibold">{payments.length}</div>
                  <div className="text-sm text-blue-600">Total Payments</div>
                </div>
                {lastPayment && (
                  <div>
                    <div className="text-sm font-medium">
                      Last: {new Date(lastPayment.date).toLocaleDateString()}
                    </div>
                    <div className="text-xs text-blue-600">${lastPayment.amount}</div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Payment History Table */}
          {payments.length > 0 && (
            <div>
              <h3 className="font-semibold mb-3">Payment History</h3>
              <div className="border rounded-lg overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left p-3 text-sm font-medium">Date</th>
                      <th className="text-left p-3 text-sm font-medium">Treatment</th>
                      <th className="text-left p-3 text-sm font-medium">Amount</th>
                      <th className="text-left p-3 text-sm font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {payments.map((payment) => (
                      <tr key={payment.id} className="border-t hover:bg-gray-50">
                        <td className="p-3 text-sm">
                          {new Date(payment.date).toLocaleDateString()}
                        </td>
                        <td className="p-3 text-sm">{payment.treatment}</td>
                        <td className="p-3 text-sm font-medium">
                          ${payment.amount}
                        </td>
                        <td className="p-3">
                          <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs ${
                            payment.status === 'paid' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {payment.status === 'paid' ? (
                              <CheckCircle className="w-3 h-3" />
                            ) : (
                              <Clock className="w-3 h-3" />
                            )}
                            {payment.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        <div className="p-4 border-t">
          <div className="flex justify-end">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}