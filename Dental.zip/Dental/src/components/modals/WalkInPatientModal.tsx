'use client';

import React, { useState, useEffect } from 'react';
import { X, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Treatment } from '@/types';

interface WalkInPatientModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  treatments: Treatment[];
  doctors: string[];
}

export default function WalkInPatientModal({
  open,
  onClose,
  onSubmit,
  treatments = [],
  doctors = []
}: WalkInPatientModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    age: '',
    gender: '',
    address: '',
    medicalHistory: '',
    treatment: '',
    doctor: '',
    priority: 'normal',
    notes: ''
  });

  const [selectedTreatmentFee, setSelectedTreatmentFee] = useState(0);

  // Reset form when modal opens
  useEffect(() => {
    if (open) {
      setFormData({
        name: '',
        phone: '',
        age: '',
        gender: '',
        address: '',
        medicalHistory: '',
        treatment: '',
        doctor: '',
        priority: 'normal',
        notes: ''
      });
      setSelectedTreatmentFee(0);
    }
  }, [open]);

  // Update fee when treatment changes
  useEffect(() => {
    if (formData.treatment) {
      const treatment = treatments.find(t => t.name === formData.treatment);
      setSelectedTreatmentFee(treatment?.fee || 0);
    } else {
      setSelectedTreatmentFee(0);
    }
  }, [formData.treatment, treatments]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.name.trim()) {
      alert('Please enter patient name');
      return;
    }
    if (!formData.phone.trim()) {
      alert('Please enter phone number');
      return;
    }
    if (!formData.treatment) {
      alert('Please select a treatment');
      return;
    }
    
    onSubmit({
      ...formData,
      fee: selectedTreatmentFee
    });
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b sticky top-0 bg-white">
          <h2 className="text-lg font-semibold">Walk-in Patient Registration</h2>
          <button 
            onClick={onClose} 
            className="p-1 hover:bg-gray-100 rounded"
            type="button"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {/* Basic Information */}
          <div className="space-y-3">
            <h3 className="font-medium text-sm text-gray-600">Patient Details</h3>
            
            <div className="space-y-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="John Doe"
                autoFocus
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number *</Label>
              <Input
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                required
                placeholder="+1 (555) 123-4567"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="age">Age</Label>
                <Input
                  id="age"
                  name="age"
                  type="number"
                  value={formData.age}
                  onChange={handleChange}
                  placeholder="30"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="gender">Gender</Label>
                <select
                  id="gender"
                  name="gender"
                  value={formData.gender}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border rounded-lg"
                >
                  <option value="">Select</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <Input
                id="address"
                name="address"
                value={formData.address}
                onChange={handleChange}
                placeholder="Street, City"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="medicalHistory">Medical History</Label>
              <Textarea
                id="medicalHistory"
                name="medicalHistory"
                value={formData.medicalHistory}
                onChange={handleChange}
                placeholder="Any medical conditions or allergies..."
                rows={2}
              />
            </div>
          </div>

          {/* Treatment Details */}
          <div className="space-y-3 border-t pt-4">
            <h3 className="font-medium text-sm text-gray-600">Treatment Details</h3>
            
            <div className="space-y-2">
              <Label htmlFor="treatment">Treatment *</Label>
              <select
                id="treatment"
                name="treatment"
                value={formData.treatment}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg"
                required
              >
                <option value="">Select Treatment</option>
                {treatments.map(treatment => (
                  <option key={treatment.id} value={treatment.name}>
                    {treatment.name} - ${treatment.fee}
                  </option>
                ))}
              </select>
            </div>

            {/* Fee Display */}
            {selectedTreatmentFee > 0 && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-blue-600" />
                    <span className="font-medium">Treatment Fee:</span>
                  </div>
                  <span className="text-lg font-bold text-blue-700">${selectedTreatmentFee}</span>
                </div>
                <p className="text-xs text-blue-600 mt-1">
                  This amount will be added to the patient's bill
                </p>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="doctor">Doctor</Label>
              <select
                id="doctor"
                name="doctor"
                value={formData.doctor}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg"
              >
                <option value="">Select Doctor</option>
                {doctors.map(doctor => (
                  <option key={doctor} value={doctor}>{doctor}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="priority">Priority</Label>
              <select
                id="priority"
                name="priority"
                value={formData.priority}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg"
              >
                <option value="normal">Normal</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                name="notes"
                value={formData.notes}
                onChange={handleChange}
                placeholder="Any special instructions..."
                rows={2}
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-green-600 hover:bg-green-700"
            >
              Add to Queue
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}