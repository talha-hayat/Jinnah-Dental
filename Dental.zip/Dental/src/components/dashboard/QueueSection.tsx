import React from 'react';
import { Clock, User, MoreHorizontal, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { QueueItem } from '@/types';
import { cn } from '@/lib/utils';

interface QueueSectionProps {
  title: string;
  items: QueueItem[];
  status: 'waiting' | 'in-treatment' | 'completed';
  onAction?: (item: QueueItem, action: string) => void;
}

const statusConfig = {
  waiting: {
    badge: 'bg-warning/10 text-warning border-warning/20',
    headerBg: 'bg-warning/5',
    headerBorder: 'border-warning/20',
    icon: Clock,
  },
  'in-treatment': {
    badge: 'bg-primary/10 text-primary border-primary/20',
    headerBg: 'bg-primary/5',
    headerBorder: 'border-primary/20',
    icon: User,
  },
  completed: {
    badge: 'bg-success/10 text-success border-success/20',
    headerBg: 'bg-success/5',
    headerBorder: 'border-success/20',
    icon: CheckCircle2,
  },
};

export function QueueSection({ title, items, status, onAction }: QueueSectionProps) {
  const config = statusConfig[status];
  const StatusIcon = config.icon;

  return (
    <div className="queue-section">
      <div className={cn("queue-header", config.headerBg, config.headerBorder)}>
        <div className="flex items-center gap-2">
          <StatusIcon className="w-4 h-4" />
          <span>{title}</span>
        </div>
        <Badge variant="secondary" className="text-xs">
          {items.length}
        </Badge>
      </div>

      <div className="queue-list scrollbar-thin">
        {items.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground text-sm">
            No patients in this queue
          </div>
        ) : (
          items.map((item) => (
            <div key={item.id} className="queue-item">
              <div className="flex items-center gap-3">
                <div className={cn(
                  "w-10 h-10 rounded-lg flex items-center justify-center font-bold text-sm",
                  config.badge
                )}>
                  {item.tokenNumber.toString().padStart(2, '0')}
                </div>
                <div>
                  <p className="font-medium text-sm">{item.patientName}</p>
                  <p className="text-xs text-muted-foreground">
                    {item.treatment || 'General Checkup'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">
                  {new Date(item.checkInTime).toLocaleTimeString([], { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </span>
                
                {status === 'waiting' && (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 px-2 text-primary hover:text-primary"
                    onClick={() => onAction?.(item, 'start-treatment')}
                  >
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                )}
                
                {status === 'in-treatment' && (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 px-2 text-success hover:text-success"
                    onClick={() => onAction?.(item, 'complete')}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                  </Button>
                )}

                <Button size="sm" variant="ghost" className="h-7 px-2">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
