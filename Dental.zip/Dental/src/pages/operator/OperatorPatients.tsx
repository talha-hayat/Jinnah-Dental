'use client';

import React, { useState, useEffect } from 'react';
import { 
  UserPlus, 
  Search, 
  Edit, 
  Trash2, 
  DollarSign,
  ChevronLeft,
  ChevronRight,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Patient, Payment } from '@/types';
import { toast } from 'sonner';
import PatientModal from '@/components/modals/PatientFormModal';
import PatientDetailsModal from '@/components/modals/PatientDetailsModal';
import { 
  getAllPatients, 
  addPatient, 
  updatePatient, 
  deletePatient 
} from '@/services/patientService';

// Mock payment data (agar aap payments bhi Firebase me save karna chahte hain, to separate service banayein)
const initialPayments: Payment[] = [
  { id: 'p1', patientId: '1', amount: 150, date: '2024-01-10', treatment: 'Checkup', status: 'paid' },
  { id: 'p2', patientId: '1', amount: 500, date: '2023-12-15', treatment: 'Root Canal', status: 'paid' },
  { id: 'p3', patientId: '2', amount: 200, date: '2024-01-12', treatment: 'Cleaning', status: 'paid' },
  { id: 'p4', patientId: '2', amount: 300, date: '2023-11-20', treatment: 'Filling', status: 'paid' },
  { id: 'p5', patientId: '3', amount: 100, date: '2024-01-05', treatment: 'Consultation', status: 'paid' },
];

export default function OperatorPatients() {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [payments] = useState<Payment[]>(initialPayments);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [showPatientForm, setShowPatientForm] = useState(false);
  const [showPatientDetails, setShowPatientDetails] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const patientsPerPage = 5;

  // 🔥 Firebase se patients load karna
  useEffect(() => {
    fetchPatients();
  }, []);

  const fetchPatients = async () => {
    try {
      setLoading(true);
      const data = await getAllPatients();
      setPatients(data);
    } catch (error) {
      console.error('Error loading patients:', error);
      toast.error('Failed to load patients');
    } finally {
      setLoading(false);
    }
  };

  // Filter patients
  const filteredPatients = patients.filter(patient =>
    patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.phone.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Pagination
  const indexOfLastPatient = currentPage * patientsPerPage;
  const indexOfFirstPatient = indexOfLastPatient - patientsPerPage;
  const currentPatients = filteredPatients.slice(indexOfFirstPatient, indexOfLastPatient);
  const totalPages = Math.ceil(filteredPatients.length / patientsPerPage);

  // Handle search
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1);
  };

  // Handle add patient
  const handleAddPatient = () => {
    setSelectedPatient(null);
    setIsEditing(false);
    setShowPatientForm(true);
  };

  // Handle edit patient
  const handleEditPatient = (patient: Patient, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedPatient(patient);
    setIsEditing(true);
    setShowPatientForm(true);
  };

  // 🔥 Handle delete patient (Firebase integrated)
  const handleDeletePatient = async (patient: Patient, e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!confirm(`Are you sure you want to delete patient ${patient.name}?`)) return;

    try {
      await deletePatient(patient.id);
      
      // Local state update
      setPatients(prev => prev.filter(p => p.id !== patient.id));
      toast.success(`${patient.name} deleted successfully`);
      
      // Agar selected patient delete ho raha hai to modal band karo
      if (selectedPatient?.id === patient.id) {
        setSelectedPatient(null);
      }
    } catch (error) {
      console.error('Error deleting patient:', error);
      toast.error('Failed to delete patient');
    }
  };

  // 🔥 UPDATED: Handle save patient with Firebase integration
  const handleSavePatient = async (patientData: any) => {
    try {
      setSaving(true);

      if (isEditing && selectedPatient) {
        // Update existing patient in Firebase
        await updatePatient(selectedPatient.id, {
          name: patientData.name,
          phone: patientData.phone,
          age: Number(patientData.age),
          gender: patientData.gender,
          address: patientData.address,
          medicalHistory: patientData.medicalHistory
        });

        // Update local state
        setPatients(prev => prev.map(p => 
          p.id === selectedPatient.id 
            ? { 
                ...p, 
                name: patientData.name,
                phone: patientData.phone,
                age: Number(patientData.age),
                gender: patientData.gender,
                address: patientData.address,
                medicalHistory: patientData.medicalHistory
              }
            : p
        ));

        toast.success('Patient updated successfully');
      } else {
        // Add new patient to Firebase
        const newPatientData = {
          name: patientData.name,
          phone: patientData.phone,
          age: Number(patientData.age),
          gender: patientData.gender,
          address: patientData.address,
          medicalHistory: patientData.medicalHistory,
          createdAt: new Date().toISOString()
        };

        const newPatientId = await addPatient(newPatientData);

        // Update local state with new patient
        const newPatient: Patient = {
          id: newPatientId,
          ...newPatientData
        };
        
        setPatients(prev => [newPatient, ...prev]);
        toast.success(`${patientData.name} added successfully`);
      }

      setShowPatientForm(false);
      setSelectedPatient(null);
    } catch (error) {
      console.error('Error saving patient:', error);
      toast.error('Failed to save patient. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  // Handle add payment
  const handleAddPayment = (patientId: string) => {
    const patient = patients.find(p => p.id === patientId);
    if (patient) {
      toast.info(`Add payment for ${patient.name}`);
      // In real app, open payment modal here
    }
  };

  // Handle double click for details
  const handlePatientDoubleClick = (patient: Patient) => {
    setSelectedPatient(patient);
    setShowPatientDetails(true);
  };

  // Get patient payments
  const getPatientPayments = (patientId: string) => {
    return payments.filter(payment => payment.patientId === patientId);
  };

  // Calculate total payments for patient
  const getTotalPaid = (patientId: string) => {
    return getPatientPayments(patientId)
      .filter(p => p.status === 'paid')
      .reduce((sum, payment) => sum + payment.amount, 0);
  };

  return (
    <div className="space-y-6 p-4 md:p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Patients Management</h1>
          <p className="text-muted-foreground">Total: {patients.length} patients</p>
        </div>
        <Button onClick={handleAddPatient} className="gap-2">
          <UserPlus className="w-4 h-4" />
          Add Patient
        </Button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input 
          placeholder="Search by name or phone..." 
          className="pl-9"
          value={searchTerm}
          onChange={handleSearch}
        />
      </div>

      {/* Loading State */}
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <span className="ml-2">Loading patients...</span>
        </div>
      ) : (
        <>
          {/* Patients Table */}
          <div className="bg-white rounded-lg border overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="text-left p-3 font-medium">Name</th>
                    <th className="text-left p-3 font-medium">Phone</th>
                    <th className="text-left p-3 font-medium">Age/Gender</th>
                    <th className="text-left p-3 font-medium">Address</th>
                    <th className="text-left p-3 font-medium">Total Paid</th>
                    <th className="text-left p-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {currentPatients.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center p-8 text-muted-foreground">
                        {patients.length === 0 ? 'No patients found. Add your first patient!' : 'No matching patients found.'}
                      </td>
                    </tr>
                  ) : (
                    currentPatients.map((patient) => (
                      <tr 
                        key={patient.id}
                        className="border-b hover:bg-gray-50 cursor-pointer transition-colors"
                        onDoubleClick={() => handlePatientDoubleClick(patient)}
                      >
                        <td className="p-3">
                          <div className="font-medium">{patient.name}</div>
                          <div className="text-xs text-muted-foreground">
                            ID: {patient.id}
                          </div>
                        </td>
                        <td className="p-3">{patient.phone}</td>
                        <td className="p-3">
                          {patient.age} / {patient.gender}
                        </td>
                        <td className="p-3">
                          <div className="max-w-[200px] truncate" title={patient.address}>
                            {patient.address}
                          </div>
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <DollarSign className="w-4 h-4 text-green-600" />
                            <span className="font-medium">${getTotalPaid(patient.id)}</span>
                          </div>
                        </td>
                        <td className="p-3">
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={(e) => handleEditPatient(patient, e)}
                              className="h-8 w-8 p-0"
                              title="Edit"
                            >
                              <Edit className="w-3 h-3" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleAddPayment(patient.id)}
                              className="h-8 px-2"
                              title="Add Payment"
                            >
                              <DollarSign className="w-3 h-3" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={(e) => handleDeletePatient(patient, e)}
                              className="h-8 w-8 p-0 text-red-600 border-red-200 hover:bg-red-50"
                              title="Delete"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {filteredPatients.length > 0 && (
              <div className="flex flex-col sm:flex-row items-center justify-between p-3 border-t gap-3">
                <div className="text-sm text-muted-foreground">
                  Showing {indexOfFirstPatient + 1}-{Math.min(indexOfLastPatient, filteredPatients.length)} of {filteredPatients.length}
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <span className="flex items-center px-3 text-sm">
                    Page {currentPage} of {totalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages}
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            )}
          </div>
        </>
      )}

      {/* ✅ UPDATED: Simple Patient Modal */}
      {showPatientForm && (
        <PatientModal
          open={showPatientForm}
          onClose={() => {
            setShowPatientForm(false);
            setSelectedPatient(null);
          }}
          onSubmit={handleSavePatient}
          patient={selectedPatient}
          isEditing={isEditing}
          title={isEditing ? 'Edit Patient' : 'Add New Patient'}
          loading={saving}
        />
      )}

      {/* Patient Details Modal */}
      {showPatientDetails && selectedPatient && (
        <PatientDetailsModal
          patient={selectedPatient}
          payments={getPatientPayments(selectedPatient.id)}
          onClose={() => setShowPatientDetails(false)}
        />
      )}
    </div>
  );
}