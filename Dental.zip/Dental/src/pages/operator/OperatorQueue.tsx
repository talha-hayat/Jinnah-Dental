'use client';

import React, { useState, useEffect } from 'react';
import { 
  UserPlus, 
  Clock, 
  Activity, 
  CheckCircle, 
  Plus,
  Filter,
  Search,
  Printer,
  DollarSign,
  Users,
  Edit,
  Trash2,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { QueueSection } from '@/components/dashboard/QueueSection';
import { QueueItem, Patient, Bill, Treatment } from '@/types';
import { toast } from 'sonner';
import PatientFormModal from '@/components/modals/PatientFormModal';
import PaymentModal from '@/components/modals/PaymentModal';
import PatientDetailsModal from '@/components/modals/PatientDetailsModal';
import { 
  addPatient, 
  getAllPatients, 
  updatePatient, 
  deletePatient 
} from '@/services/patientService';
import { 
  addQueueItem, 
  getAllQueueItems, 
  updateQueueItem, 
  deleteQueueItem 
} from '@/services/queueService';
import { 
  addBill, 
  getPatientBills, 
  updateBillPayment 
} from '@/services/billingService';

// Mock treatments data (isko Firebase se bhi fetch kar sakte hain)
const treatments: Treatment[] = [
  { id: '1', name: 'General Checkup', fee: 50, category: 'consultation', duration: 15 },
  { id: '2', name: 'Teeth Cleaning', fee: 80, category: 'cleaning', duration: 30 },
  { id: '3', name: 'Filling', fee: 120, category: 'restoration', duration: 45 },
  { id: '4', name: 'Root Canal', fee: 500, category: 'endodontics', duration: 90 },
];

const doctors = ['Dr. Smith', 'Dr. Johnson', 'Dr. Wilson', 'Dr. Brown', 'Dr. Taylor'];

export default function OperatorQueue() {
  const [queueData, setQueueData] = useState<QueueItem[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [bills, setBills] = useState<Bill[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showPatientModal, setShowPatientModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState<QueueItem | null>(null);
  const [selectedDoctor, setSelectedDoctor] = useState('all');
  const [selectedTreatment, setSelectedTreatment] = useState('all');
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [showPatientDetails, setShowPatientDetails] = useState<QueueItem | null>(null);
  const [modalMode, setModalMode] = useState<'patient' | 'walk-in'>('walk-in');
  const [loading, setLoading] = useState({
    queue: true,
    patients: true,
    bills: true
  });
  const [saving, setSaving] = useState(false);

  // Firebase se data fetch karna
  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = async () => {
    try {
      // Parallel data fetching
      const [queueRes, patientsRes] = await Promise.all([
        fetchQueueData(),
        fetchPatientsData()
      ]);
      
      // Bills fetch karna patients ke baad
      await fetchBillsData();
      
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to load data');
    }
  };

  const fetchQueueData = async () => {
    try {
      setLoading(prev => ({ ...prev, queue: true }));
      const data = await getAllQueueItems();
      setQueueData(data);
    } catch (error) {
      console.error('Error fetching queue data:', error);
      toast.error('Failed to load queue data');
    } finally {
      setLoading(prev => ({ ...prev, queue: false }));
    }
  };

  const fetchPatientsData = async () => {
    try {
      setLoading(prev => ({ ...prev, patients: true }));
      const data = await getAllPatients();
      setPatients(data);
    } catch (error) {
      console.error('Error fetching patients:', error);
      toast.error('Failed to load patients');
    } finally {
      setLoading(prev => ({ ...prev, patients: false }));
    }
  };

  const fetchBillsData = async () => {
    try {
      setLoading(prev => ({ ...prev, bills: true }));
      // Agar aapke paas getAllBills function hai to use karein
      // const data = await getAllBills();
      // setBills(data);
      
      // Ya har patient ke bills individually fetch karein
      const billsPromises = patients.map(patient => getPatientBills(patient.id));
      const billsResults = await Promise.all(billsPromises);
      const allBills = billsResults.flat();
      setBills(allBills);
      
    } catch (error) {
      console.error('Error fetching bills:', error);
    } finally {
      setLoading(prev => ({ ...prev, bills: false }));
    }
  };

  // Filter queue data
  const filteredQueueData = queueData.filter(item => {
    const matchesSearch = item.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.phone.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDoctor = selectedDoctor === 'all' || item.doctor === selectedDoctor;
    const matchesTreatment = selectedTreatment === 'all' || item.treatment === selectedTreatment;
    
    return matchesSearch && matchesDoctor && matchesTreatment;
  });

  const waitingPatients = filteredQueueData.filter(p => p.status === 'waiting');
  const inTreatmentPatients = filteredQueueData.filter(p => p.status === 'in-treatment');
  const completedPatients = filteredQueueData.filter(p => p.status === 'completed');

  // ✅ Naya Patient save karna (Firebase integrated)
  const handleSavePatient = async (patientData: any) => {
    try {
      setSaving(true);

      const newPatientData = {
        name: patientData.name,
        phone: patientData.phone,
        age: Number(patientData.age),
        gender: patientData.gender,
        address: patientData.address,
        medicalHistory: patientData.medicalHistory,
        createdAt: new Date().toISOString()
      };

      if (patientData.id && modalMode === 'walk-in') {
        // Update existing patient
        await updatePatient(patientData.id, newPatientData);
        
        // Local state update
        setPatients(prev => prev.map(p => 
          p.id === patientData.id 
            ? { ...p, ...newPatientData }
            : p
        ));
      } else if (modalMode === 'patient') {
        // New patient save karna
        const newPatientId = await addPatient(newPatientData);
        const newPatient: Patient = {
          id: newPatientId,
          ...newPatientData
        };
        setPatients(prev => [newPatient, ...prev]);
      }

      toast.success(`${patientData.name} saved successfully`);
      
    } catch (error) {
      console.error('Error saving patient:', error);
      toast.error('Failed to save patient');
    } finally {
      setSaving(false);
    }
  };

  // ✅ Walk-in Patient ko queue mein add karna
  const handleWalkInPatient = async (patientData: any) => {
    try {
      setSaving(true);
      
      let patientId = patientData.id;
      
      // Agar new patient hai to Firebase mein save karein
      if (!patientId) {
        const newPatientData = {
          name: patientData.name,
          phone: patientData.phone,
          age: Number(patientData.age),
          gender: patientData.gender,
          address: patientData.address,
          medicalHistory: patientData.medicalHistory,
          createdAt: new Date().toISOString()
        };
        
        patientId = await addPatient(newPatientData);
        
        // Local state update
        const newPatient: Patient = {
          id: patientId,
          ...newPatientData
        };
        setPatients(prev => [newPatient, ...prev]);
      }

      // Next token number calculate karein
      const todayQueue = queueData.filter(item => {
        const itemDate = new Date(item.checkInTime);
        const today = new Date();
        return itemDate.getDate() === today.getDate() && 
               itemDate.getMonth() === today.getMonth() && 
               itemDate.getFullYear() === today.getFullYear();
      });
      
      const nextTokenNumber = todayQueue.length > 0 
        ? Math.max(...todayQueue.map(q => q.tokenNumber)) + 1 
        : 1;

      // Firebase mein queue item add karein
      const queueItemData = {
        patientId,
        patientName: patientData.name,
        phone: patientData.phone,
        tokenNumber: nextTokenNumber,
        status: 'waiting' as const,
        checkInTime: new Date().toISOString(),
        treatment: patientData.treatment,
        doctor: patientData.doctor || doctors[0],
        priority: patientData.priority || 'normal',
        notes: patientData.notes,
        fee: patientData.fee || 0,
        paymentStatus: 'pending' as const,
        amountPaid: 0,
        previousPending: await getPreviousPendingAmount(patientId)
      };

      const newQueueId = await addQueueItem(queueItemData);
      
      // Local state update
      const newQueueItem: QueueItem = {
        id: newQueueId,
        ...queueItemData
      };
      
      setQueueData(prev => [...prev, newQueueItem]);
      
      toast.success(`${patientData.name} added to queue (Token #${nextTokenNumber})`);
      setShowPatientModal(false);
      
      // Auto open payment modal for walk-in
      if (modalMode === 'walk-in') {
        setTimeout(() => {
          setShowPaymentModal(newQueueItem);
        }, 800);
      }
      
    } catch (error) {
      console.error('Error adding walk-in patient:', error);
      toast.error('Failed to add patient to queue');
    } finally {
      setSaving(false);
    }
  };

  // ✅ Get previous pending amount for a patient (Firebase se)
  const getPreviousPendingAmount = async (patientId: string) => {
    try {
      const patientBills = await getPatientBills(patientId);
      return patientBills
        .filter(bill => bill.paymentStatus !== 'paid')
        .reduce((sum, bill) => sum + (bill.totalAmount - bill.amountPaid), 0);
    } catch (error) {
      console.error('Error getting pending amount:', error);
      return 0;
    }
  };

  // ✅ Handle queue actions (Firebase integrated)
  const handleQueueAction = async (item: QueueItem, action: string) => {
    try {
      const now = new Date().toISOString();
      
      if (action === 'start-treatment') {
        await updateQueueItem(item.id, {
          status: 'in-treatment',
          treatmentStartTime: now
        });
        
        // Local state update
        setQueueData(prev => prev.map(p => 
          p.id === item.id 
            ? { ...p, status: 'in-treatment', treatmentStartTime: now }
            : p
        ));
        
        toast.success(`Started treatment for ${item.patientName}`);
      }
      
      if (action === 'complete') {
        await updateQueueItem(item.id, {
          status: 'completed',
          treatmentEndTime: now
        });
        
        // Local state update
        const updatedItem = { 
          ...item, 
          status: 'completed' as const,
          treatmentEndTime: now
        };
        
        setQueueData(prev => prev.map(p => 
          p.id === item.id ? updatedItem : p
        ));
        
        toast.success(`Completed treatment for ${item.patientName}`);
        
        // Auto open payment modal if payment pending
        if (item.paymentStatus !== 'paid') {
          setTimeout(() => setShowPaymentModal(updatedItem), 500);
        }
      }
      
      if (action === 'cancel') {
        await updateQueueItem(item.id, {
          status: 'cancelled',
          cancelledAt: now
        });
        
        // Local state update
        setQueueData(prev => prev.map(p => 
          p.id === item.id 
            ? { ...p, status: 'cancelled', cancelledAt: now }
            : p
        ));
        
        toast.info(`Cancelled treatment for ${item.patientName}`);
      }
      
      if (action === 'edit') {
        const patient = patients.find(pt => pt.id === item.patientId);
        if (patient) {
          setSelectedPatient(patient);
          setModalMode('walk-in');
          setShowPatientModal(true);
        }
      }
      
      if (action === 'delete') {
        if (confirm(`Remove ${item.patientName} from queue?`)) {
          await deleteQueueItem(item.id);
          setQueueData(prev => prev.filter(q => q.id !== item.id));
          toast.success(`Removed ${item.patientName} from queue`);
        }
      }
      
    } catch (error) {
      console.error('Error performing queue action:', error);
      toast.error('Failed to update queue');
    }
  };

  // Handle double click on queue item
  const handleQueueItemDoubleClick = (item: QueueItem) => {
    setShowPatientDetails(item);
  };

  // ✅ Handle add payment (Firebase integrated)
  const handleAddPayment = async (queueItem: QueueItem, paymentData: any) => {
    try {
      const updatedAmountPaid = (queueItem.amountPaid || 0) + paymentData.amount;
      const previousPending = queueItem.previousPending || 0;
      const totalFee = (queueItem.fee || 0) + previousPending;
      const remainingAmount = totalFee - updatedAmountPaid;
      
      const paymentStatus = remainingAmount <= 0 ? 'paid' : 
                          updatedAmountPaid > 0 ? 'partial' : 'pending';
      
      // Queue item update in Firebase
      await updateQueueItem(queueItem.id, {
        amountPaid: updatedAmountPaid,
        paymentStatus
      });
      
      // Local state update
      setQueueData(prev => prev.map(item => 
        item.id === queueItem.id 
          ? {
              ...item,
              amountPaid: updatedAmountPaid,
              paymentStatus
            }
          : item
      ));
      
      // ✅ Firebase mein bill create karna
      const billNumber = `BILL-${String(bills.length + 1).padStart(3, '0')}`;
      const tax = (queueItem.fee || 0) * 0.05;
      const totalAmount = (queueItem.fee || 0) + tax - (paymentData.discount || 0);
      
      const newBillData = {
        patientId: queueItem.patientId,
        patientName: queueItem.patientName,
        queueId: queueItem.id,
        treatment: queueItem.treatment,
        fee: queueItem.fee || 0,
        amountPaid: paymentData.amount,
        discount: paymentData.discount || 0,
        tax,
        totalAmount,
        paymentStatus,
        paymentMethod: paymentData.paymentMethod,
        createdAt: new Date().toISOString(),
        billNumber,
        items: [
          { id: '1', name: queueItem.treatment, quantity: 1, price: queueItem.fee || 0, total: queueItem.fee || 0 }
        ]
      };
      
      const newBillId = await addBill(newBillData);
      
      // Local state update
      const newBill: Bill = {
        id: newBillId,
        ...newBillData
      };
      
      setBills(prev => [...prev, newBill]);
      
      toast.success(`Payment of $${paymentData.amount} recorded`);
      setShowPaymentModal(null);
      
      // Auto print bill if fully paid
      if (paymentStatus === 'paid') {
        setTimeout(() => handlePrintBill(newBill), 1000);
      }
      
    } catch (error) {
      console.error('Error processing payment:', error);
      toast.error('Failed to process payment');
    }
  };

  // Handle print bill
  const handlePrintBill = (bill: Bill) => {
    const printContent = `
================================
        DENTAL CLINIC
================================
Bill No: ${bill.billNumber}
Date: ${new Date(bill.createdAt).toLocaleString()}
--------------------------------
Patient: ${bill.patientName}
Treatment: ${bill.treatment}
--------------------------------
Fee: $${bill.fee.toFixed(2)}
Discount: $${(bill.discount || 0).toFixed(2)}
Tax: $${(bill.tax || 0).toFixed(2)}
--------------------------------
TOTAL: $${bill.totalAmount.toFixed(2)}
Amount Paid: $${bill.amountPaid.toFixed(2)}
Payment Method: ${bill.paymentMethod}
Status: ${bill.paymentStatus}
--------------------------------
Thank you for visiting!
================================
    `;
    
    console.log('Printing Bill:', printContent);
    toast.success('Bill sent to thermal printer');
  };

  // Get patient bills from local state
  const getPatientBillsLocal = (patientId: string) => {
    return bills.filter(bill => bill.patientId === patientId);
  };

  // Get total pending for patient from local state
  const getTotalPending = (patientId: string) => {
    return bills
      .filter(bill => bill.patientId === patientId && bill.paymentStatus !== 'paid')
      .reduce((sum, bill) => sum + (bill.totalAmount - bill.amountPaid), 0);
  };

  return (
    <div className="space-y-6">
      {/* Header with two buttons */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Queue Management</h1>
          <p className="text-muted-foreground">
            Total in Queue: {queueData.length} • Saved Patients: {patients.length}
            {(loading.queue || loading.patients) && (
              <Loader2 className="w-3 h-3 inline ml-2 animate-spin" />
            )}
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={() => {
              setModalMode('patient');
              setSelectedPatient(null);
              setShowPatientModal(true);
            }}
            variant="outline"
            className="gap-2"
            disabled={saving}
          >
            <UserPlus className="w-4 h-4" />
            New Patient
          </Button>
          <Button 
            onClick={() => {
              setModalMode('walk-in');
              setSelectedPatient(null);
              setShowPatientModal(true);
            }}
            className="gap-2 bg-green-600 hover:bg-green-700"
            disabled={saving}
          >
            <Users className="w-4 h-4" />
            Generate Bill
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-blue-700">{waitingPatients.length}</div>
              <div className="text-sm text-blue-600 font-medium">Waiting</div>
            </div>
            <Clock className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-yellow-700">{inTreatmentPatients.length}</div>
              <div className="text-sm text-yellow-600 font-medium">In Treatment</div>
            </div>
            <Activity className="w-8 h-8 text-yellow-600" />
          </div>
        </div>
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-purple-700">{patients.length}</div>
              <div className="text-sm text-purple-600 font-medium">Saved Patients</div>
            </div>
            <Users className="w-8 h-8 text-purple-600" />
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search by name or phone..." 
              className="pl-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button variant="outline" onClick={() => {
            setSearchTerm('');
            setSelectedDoctor('all');
            setSelectedTreatment('all');
          }}>
            Clear Filters
          </Button>
        </div>

        <div className="flex flex-wrap gap-3">
          <select
            value={selectedDoctor}
            onChange={(e) => setSelectedDoctor(e.target.value)}
            className="px-3 py-2 border rounded-lg"
          >
            <option value="all">All Doctors</option>
            {doctors.map(doctor => (
              <option key={doctor} value={doctor}>{doctor}</option>
            ))}
          </select>

          <select
            value={selectedTreatment}
            onChange={(e) => setSelectedTreatment(e.target.value)}
            className="px-3 py-2 border rounded-lg"
          >
            <option value="all">All Treatments</option>
            {treatments.map(treatment => (
              <option key={treatment.id} value={treatment.name}>
                {treatment.name} (${treatment.fee})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Loading State */}
      {loading.queue ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <span className="ml-2">Loading queue data...</span>
        </div>
      ) : (
        /* Queue Sections */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <QueueSection
            title="Waiting"
            items={waitingPatients}
            status="waiting"
            onAction={handleQueueAction}
            onPayment={setShowPaymentModal}
            onPrint={(item) => {
              const bill = bills.find(b => b.queueId === item.id);
              if (bill) handlePrintBill(bill);
            }}
            onDoubleClick={handleQueueItemDoubleClick}
            showPending={true}
            getPendingAmount={getTotalPending}
          />
          <QueueSection
            title="In Treatment"
            items={inTreatmentPatients}
            status="in-treatment"
            onAction={handleQueueAction}
            onPayment={setShowPaymentModal}
            onDoubleClick={handleQueueItemDoubleClick}
            showPending={true}
            getPendingAmount={getTotalPending}
          />
          <QueueSection
            title="Completed"
            items={completedPatients}
            status="completed"
            onAction={handleQueueAction}
            onPayment={setShowPaymentModal}
            onDoubleClick={handleQueueItemDoubleClick}
            showPending={true}
            getPendingAmount={getTotalPending}
          />
        </div>
      )}

      {/* Patient Modal */}
      <PatientFormModal
        open={showPatientModal}
        onClose={() => setShowPatientModal(false)}
        onSubmit={modalMode === 'walk-in' ? handleWalkInPatient : handleSavePatient}
        patient={selectedPatient}
        isEditing={!!selectedPatient}
        treatments={modalMode === 'walk-in' ? treatments : []}
        doctors={doctors}
        mode={modalMode}
        existingPatients={patients}
        title={modalMode === 'walk-in' ? 
               (selectedPatient ? 'Edit & Add to Queue' : 'Walk-in Patient') : 
               (selectedPatient ? 'Edit Patient' : 'Save New Patient')}
        loading={saving}
      />

      {/* Payment Modal */}
      {showPaymentModal && (
        <PaymentModal
          queueItem={showPaymentModal}
          bills={getPatientBillsLocal(showPaymentModal.patientId)}
          onClose={() => setShowPaymentModal(null)}
          onSubmit={handleAddPayment}
        />
      )}

      {/* Patient Details Modal */}
      {showPatientDetails && (
        <PatientDetailsModal
          patient={showPatientDetails}
          patientInfo={patients.find(p => p.id === showPatientDetails.patientId)}
          bills={getPatientBillsLocal(showPatientDetails.patientId)}
          totalPending={getTotalPending(showPatientDetails.patientId)}
          onClose={() => setShowPatientDetails(null)}
          onEdit={() => {
            const patient = patients.find(p => p.id === showPatientDetails.patientId);
            if (patient) {
              setSelectedPatient(patient);
              setModalMode('walk-in');
              setShowPatientModal(true);
            }
            setShowPatientDetails(null);
          }}
          onDelete={() => {
            if (confirm(`Remove ${showPatientDetails.patientName} from queue?`)) {
              deleteQueueItem(showPatientDetails.id);
              setQueueData(prev => prev.filter(q => q.id !== showPatientDetails.id));
              toast.success(`Removed ${showPatientDetails.patientName} from queue`);
              setShowPatientDetails(null);
            }
          }}
        />
      )}
    </div>
  );
}