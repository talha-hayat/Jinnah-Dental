import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  getDocs,
  query,
  orderBy,
  Timestamp
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Patient } from "@/types";

const patientsRef = collection(db, "patients");

export const getAllPatients = async (): Promise<Patient[]> => {
  try {
    const q = query(patientsRef, orderBy("createdAt", "desc"));
    const snapshot = await getDocs(q);

    return snapshot.docs.map(doc => ({
      id: doc.id,
      name: doc.data().name,
      phone: doc.data().phone,
      age: doc.data().age,
      gender: doc.data().gender,
      address: doc.data().address,
      medicalHistory: doc.data().medicalHistory,
      createdAt: doc.data().createdAt
    })) as Patient[];
  } catch (error) {
    console.error("Error fetching patients:", error);
    throw error;
  }
};

export const addPatient = async (data: Omit<Patient, "id">): Promise<string> => {
  try {
    const docRef = await addDoc(patientsRef, {
      ...data,
      createdAt: Timestamp.now()
    });
    return docRef.id;
  } catch (error) {
    console.error("Error adding patient:", error);
    throw error;
  }
};

export const updatePatient = async (id: string, data: Partial<Patient>) => {
  try {
    const patientRef = doc(db, "patients", id);
    await updateDoc(patientRef, data);
  } catch (error) {
    console.error("Error updating patient:", error);
    throw error;
  }
};

export const deletePatient = async (id: string) => {
  try {
    await deleteDoc(doc(db, "patients", id));
  } catch (error) {
    console.error("Error deleting patient:", error);
    throw error;
  }
};