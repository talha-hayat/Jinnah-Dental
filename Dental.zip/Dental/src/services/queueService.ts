import { db } from '@/lib/firebase';
import { FirebaseQueueItem } from '@/types';
import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  getDocs, 
  query, 
  orderBy,
  serverTimestamp,
  Timestamp,
  getDoc
} from 'firebase/firestore';

const QUEUE_COLLECTION = 'queue';

// Queue item add karna
export const addQueueItem = async (queueData: Omit<FirebaseQueueItem, 'createdAt' | 'updatedAt'>) => {
  try {
    const queueRef = collection(db, QUEUE_COLLECTION);
    
    const newQueueItem = {
      ...queueData,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };
    
    const docRef = await addDoc(queueRef, newQueueItem);
    return docRef.id;
  } catch (error) {
    console.error('Error adding queue item:', error);
    throw error;
  }
};

// Sabhi queue items fetch karna
export const getAllQueueItems = async () => {
  try {
    const queueRef = collection(db, QUEUE_COLLECTION);
    const q = query(queueRef, orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);
    
    const queueItems = snapshot.docs.map(doc => {
      const data = doc.data();
      
      // Convert Firestore Timestamps to ISO strings
      const convertTimestamp = (timestamp: any) => {
        if (timestamp?.toDate) {
          return timestamp.toDate().toISOString();
        }
        return timestamp;
      };
      
      return {
        id: doc.id,
        patientId: data.patientId,
        patientName: data.patientName,
        phone: data.phone,
        tokenNumber: data.tokenNumber,
        status: data.status,
        checkInTime: convertTimestamp(data.checkInTime),
        treatment: data.treatment,
        doctor: data.doctor,
        treatmentStartTime: convertTimestamp(data.treatmentStartTime),
        treatmentEndTime: convertTimestamp(data.treatmentEndTime),
        cancelledAt: convertTimestamp(data.cancelledAt),
        createdAt: convertTimestamp(data.createdAt),
        updatedAt: convertTimestamp(data.updatedAt)
      };
    });
    
    return queueItems;
  } catch (error) {
    console.error('Error fetching queue items:', error);
    throw error;
  }
};

// Queue item update karna
export const updateQueueItem = async (id: string, updateData: Partial<FirebaseQueueItem>) => {
  try {
    const queueRef = doc(db, QUEUE_COLLECTION, id);
    
    await updateDoc(queueRef, {
      ...updateData,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error updating queue item:', error);
    throw error;
  }
};

// Queue item delete karna
export const deleteQueueItem = async (id: string) => {
  try {
    const queueRef = doc(db, QUEUE_COLLECTION, id);
    await deleteDoc(queueRef);
  } catch (error) {
    console.error('Error deleting queue item:', error);
    throw error;
  }
};

// Get token number for today
export const getTodayTokenCount = async () => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const queueRef = collection(db, QUEUE_COLLECTION);
    const snapshot = await getDocs(queueRef);
    
    const todayItems = snapshot.docs.filter(doc => {
      const data = doc.data();
      const itemDate = data.createdAt?.toDate();
      return itemDate >= today;
    });
    
    return todayItems.length;
  } catch (error) {
    console.error('Error getting today token count:', error);
    return 0;
  }
};