import { db } from '@/lib/firebase';
import { Bill, FirebaseBill } from '@/types';
import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  getDocs, 
  query, 
  where,
  orderBy,
  serverTimestamp,
  Timestamp
} from 'firebase/firestore';

const BILLS_COLLECTION = 'bills';

// Bill add karna
export const addBill = async (billData: Omit<FirebaseBill, 'createdAt' | 'updatedAt'>) => {
  try {
    const billRef = collection(db, BILLS_COLLECTION);
    
    const newBill = {
      ...billData,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };
    
    const docRef = await addDoc(billRef, newBill);
    return docRef.id;
  } catch (error) {
    console.error('Error adding bill:', error);
    throw error;
  }
};

// Patient ke bills fetch karna
export const getPatientBills = async (patientId: string) => {
  try {
    const billsRef = collection(db, BILLS_COLLECTION);
    const q = query(
      billsRef, 
      where('patientId', '==', patientId),
      orderBy('createdDate', 'desc')
    );
    
    const snapshot = await getDocs(q);
    
    const bills = snapshot.docs.map(doc => {
      const data = doc.data();
      
      // Convert Firestore Timestamps to ISO strings
      const convertTimestamp = (timestamp: any) => {
        if (timestamp?.toDate) {
          return timestamp.toDate().toISOString();
        }
        return timestamp;
      };
      
      return {
        id: doc.id,
        patientId: data.patientId,
        patientName: data.patientName,
        queueId: data.queueId,
        treatment: data.treatment,
        fee: data.fee,
        amountPaid: data.amountPaid,
        discount: data.discount || 0,
        tax: data.tax || 0,
        totalAmount: data.totalAmount,
        paymentStatus: data.paymentStatus,
        paymentMethod: data.paymentMethod,
        createdDate: convertTimestamp(data.createdDate),
        billNumber: data.billNumber,
        items: data.items || []
      };
    });
    
    return bills;
  } catch (error) {
    console.error('Error fetching patient bills:', error);
    throw error;
  }
};

// Bill payment update karna
export const updateBillPayment = async (billId: string, updateData: Partial<Bill>) => {
  try {
    const billRef = doc(db, BILLS_COLLECTION, billId);
    
    await updateDoc(billRef, {
      ...updateData,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error updating bill:', error);
    throw error;
  }
};