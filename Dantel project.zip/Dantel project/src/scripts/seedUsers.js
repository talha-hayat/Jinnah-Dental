// Firebase mein initial users create karne ke liye script
const bcrypt = require('bcryptjs');
const { initializeApp } = require('firebase/app');
const { getFirestore, collection, addDoc } = require('firebase/firestore');

const firebaseConfig = {
  // Your Firebase config here
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const seedUsers = async () => {
  try {
    // Default passwords hash karna
    const operatorPassword = 'operator123';
    const adminPassword = 'admin123';
    
    const operatorHash = await bcrypt.hash(operatorPassword, 10);
    const adminHash = await bcrypt.hash(adminPassword, 10);
    
    // Users array
    const users = [
      {
        name: 'Front Desk Operator',
        role: 'operator',
        passwordHash: operatorHash,
        isActive: true,
        createdAt: new Date().toISOString()
      },
      {
        name: 'Clinic Administrator',
        role: 'admin',
        passwordHash: adminHash,
        isActive: true,
        createdAt: new Date().toISOString()
      }
    ];
    
    // Firestore mein add karna
    for (const user of users) {
      const docRef = await addDoc(collection(db, 'users'), user);
      console.log(`User added with ID: ${docRef.id}`, user);
    }
    
    console.log('Users seeded successfully!');
    console.log('\nDefault Credentials:');
    console.log('Operator: operator123');
    console.log('Admin: admin123');
    
  } catch (error) {
    console.error('Error seeding users:', error);
  }
};

seedUsers();