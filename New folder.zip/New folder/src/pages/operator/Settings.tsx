'use client';

import React, { useState, useEffect } from 'react';
import { 
  Save,
  Download,
  Upload,
  Lock,
  User,
  Calendar,
  Clock,
  DollarSign,
  Plus,
  Edit,
  Trash2,
  Search,
  Database,
  Settings as SettingsIcon,
  FileText,
  Eye,
  EyeOff,
  CheckCircle,
  AlertCircle,
  RefreshCw // Added for sync button
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Treatment } from '@/types';
import TreatmentFormModal from '@/components/modals/TreatmentFormModal';

// Firebase
import { db } from '@/lib/firebase';
import {
  collection,
  getDocs,
  doc,
  setDoc,
  deleteDoc,
  query
} from 'firebase/firestore';

// IndexedDB Helpers
const openDB = () => new Promise<IDBDatabase>((resolve, reject) => {
  const request = indexedDB.open('ClinicDB', 6); // Updated to version 5
  request.onupgradeneeded = (event) => {
    const db = (event.target as IDBOpenDBRequest).result;
    if (!db.objectStoreNames.contains('treatments')) {
      db.createObjectStore('treatments', { keyPath: 'id' });
    }
    if (!db.objectStoreNames.contains('clinicSettings')) {
      db.createObjectStore('clinicSettings', { keyPath: 'id' });
    }
    if (!db.objectStoreNames.contains('backups')) {
      db.createObjectStore('backups', { keyPath: 'id' });
    }
  };
  request.onsuccess = () => resolve(request.result);
  request.onerror = () => reject(request.error);
});

const getAll = async (storeName: string): Promise<any[]> => {
  const db = await openDB();
  return new Promise((resolve) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result);
  });
};

const getItem = async (storeName: string, id: string): Promise<any> => {
  const db = await openDB();
  return new Promise((resolve) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.get(id);
    req.onsuccess = () => resolve(req.result);
  });
};

const putItem = async (storeName: string, item: any) => {
  const db = await openDB();
  const tx = db.transaction(storeName, 'readwrite');
  const store = tx.objectStore(storeName);
  await store.put(item);
};

const deleteItem = async (storeName: string, id: string) => {
  const db = await openDB();
  const tx = db.transaction(storeName, 'readwrite');
  const store = tx.objectStore(storeName);
  await store.delete(id);
};

// Firebase sync helpers
const syncToFirebase = (collectionName: string, item: any) => {
  setDoc(doc(db, collectionName, item.id), item).catch(console.error); // Background sync
};

const loadFromFirebase = async (collectionName: string): Promise<any[]> => {
  try {
    const q = query(collection(db, collectionName));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => doc.data());
  } catch (err) {
    console.error("Firebase load failed:", err);
    return [];
  }
};

export default function OperatorSettings() {
  const [activeTab, setActiveTab] = useState('security');
  const [treatments, setTreatments] = useState<Treatment[]>([]); // No mock
  const [selectedTreatment, setSelectedTreatment] = useState<Treatment | null>(null);
  const [showTreatmentForm, setShowTreatmentForm] = useState(false);
  const [isEditingTreatment, setIsEditingTreatment] = useState(false);
  const [backupHistory, setBackupHistory] = useState([]); // No mock
  const [isSyncing, setIsSyncing] = useState(false);
  
  // Password Change
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Clinic Settings
  const [clinicData, setClinicData] = useState({
    id: 'clinic-settings', // Fixed ID for single settings doc
    clinicName: '',
    address: '',
    phone: '',
    email: '',
    taxRate: '',
    currency: 'USD',
    businessHours: ''
  });

  // Backup Selection
  const [backupSelection, setBackupSelection] = useState({
    patients: true,
    appointments: true,
    bills: true,
    inventory: true,
    staff: true,
    treatments: true,
    expenses: true,
  });

  // Load data on mount: Local first
  useEffect(() => {
    async function loadData() {
      // Treatments
      let localTreatments = await getAll('treatments') as Treatment[];
      if (localTreatments.length === 0) {
        const remoteTreatments = await loadFromFirebase('treatments') as Treatment[];
        if (remoteTreatments.length > 0) {
          setTreatments(remoteTreatments);
          for (const item of remoteTreatments) await putItem('treatments', item);
        }
      } else {
        setTreatments(localTreatments);
      }

      // Clinic Settings (single doc)
      let localClinic = await getItem('clinicSettings', 'clinic-settings');
      if (!localClinic) {
        const remoteClinicSnap = await getDocs(query(collection(db, 'clinicSettings')));
        if (!remoteClinicSnap.empty) {
          localClinic = remoteClinicSnap.docs[0].data();
          await putItem('clinicSettings', localClinic);
        } else {
          localClinic = clinicData; // Default if no remote
          await putItem('clinicSettings', localClinic);
        }
      }
      setClinicData(localClinic);

      // Backup History
      let localBackups = await getAll('backups');
      if (localBackups.length === 0) {
        const remoteBackups = await loadFromFirebase('backups');
        if (remoteBackups.length > 0) {
          setBackupHistory(remoteBackups);
          for (const item of remoteBackups) await putItem('backups', item);
        }
      } else {
        setBackupHistory(localBackups);
      }
    }
    loadData().catch(console.error);
  }, []);

  // Manual Sync
  const handleSync = async () => {
    setIsSyncing(true);
    try {
      // Sync treatments
      const remoteTreatments = await loadFromFirebase('treatments') as Treatment[];
      setTreatments(remoteTreatments);
      for (const item of remoteTreatments) await putItem('treatments', item);

      // Sync clinic settings
      const remoteClinicSnap = await getDocs(query(collection(db, 'clinicSettings')));
      let remoteClinic = clinicData;
      if (!remoteClinicSnap.empty) {
        remoteClinic = remoteClinicSnap.docs[0].data();
      }
      setClinicData(remoteClinic);
      await putItem('clinicSettings', remoteClinic);

      // Sync backups
      const remoteBackups = await loadFromFirebase('backups');
      setBackupHistory(remoteBackups);
      for (const item of remoteBackups) await putItem('backups', item);

      toast.success('Settings synced from Firebase!');
    } catch (err) {
      toast.error('Sync failed. Check connection.');
    } finally {
      setIsSyncing(false);
    }
  };

  // Handle change password (local only, or sync if needed)
  const handleChangePassword = () => {
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast.error('New passwords do not match');
      return;
    }
    if (passwordData.newPassword.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }
    
    toast.success('Password changed successfully');
    setPasswordData({
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
    });
  };

  // Handle save clinic settings
  const handleSaveClinicSettings = async () => {
    await putItem('clinicSettings', clinicData); // Local save
    syncToFirebase('clinicSettings', clinicData); // Background sync
    toast.success('Clinic settings saved');
  };

  // Handle backup
  const handleBackup = async () => {
    const selectedItems = Object.entries(backupSelection)
      .filter(([_, value]) => value)
      .map(([key]) => key);
    
    if (selectedItems.length === 0) {
      toast.error('Select at least one item to backup');
      return;
    }

    const newBackup = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      type: selectedItems.length === Object.keys(backupSelection).length ? 'full' : 'partial',
      size: `${Math.floor(Math.random() * 50 + 10)} MB`, // Simulate size
      status: 'success',
      items: selectedItems
    };

    setBackupHistory(prev => [newBackup, ...prev]);

    // Local save
    await putItem('backups', newBackup);

    // Background sync
    syncToFirebase('backups', newBackup);

    // Trigger download
    downloadBackup(newBackup);

    toast.success('Backup created successfully');
  };

  // Handle download backup
  const downloadBackup = (backup) => {
    const backupData = {
      timestamp: backup.date,
      items: backup.items,
      // In real, fetch actual data for items
      data: {} // Placeholder, add real data fetching if needed
    };

    const dataStr = JSON.stringify(backupData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `clinic_backup_${new Date(backup.date).toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Handle download individual data
  const handleDownloadData = async (type: string) => {
    let data: any = {};
    
    switch(type) {
      case 'patients':
        data = { patients: [] }; // Fetch real if needed
        break;
      case 'doctors':
        data = { doctors };
        break;
      case 'treatments':
        data = { treatments };
        break;
      case 'bills':
        data = { bills: [] };
        break;
      case 'staff':
        data = { staff: [] };
        break;
      default:
        data = { message: 'Data export' };
    }

    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${type}_export_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast.success(`${type.charAt(0).toUpperCase() + type.slice(1)} data exported`);
  };

  // Handle restore backup
  const handleRestoreBackup = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.json')) {
      toast.error('Please select a JSON backup file');
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        toast.success('Backup file loaded successfully');
        // Restore logic: Update local stores based on data.items
        // For example, if 'treatments' in data, update treatments store
        console.log('Restored data:', data);
        // Implement actual restore as needed
      } catch (error) {
        toast.error('Invalid backup file format');
      }
    };
    reader.readAsText(file);
  };

  // Handle treatment CRUD
  const handleAddTreatment = () => {
    setSelectedTreatment(null);
    setIsEditingTreatment(false);
    setShowTreatmentForm(true);
  };

  const handleEditTreatment = (treatment: Treatment) => {
    setSelectedTreatment(treatment);
    setIsEditingTreatment(true);
    setShowTreatmentForm(true);
  };

  const handleDeleteTreatment = async (treatment: Treatment) => {
    if (confirm(`Delete treatment "${treatment.name}"?`)) {
      setTreatments(prev => prev.filter(t => t.id !== treatment.id));

      // Local delete
      await deleteItem('treatments', treatment.id);

      // Background delete
      deleteDoc(doc(db, 'treatments', treatment.id)).catch(console.error);

      toast.success(`Treatment "${treatment.name}" deleted`);
    }
  };

  const handleSaveTreatment = async (treatmentData: any) => {
    let updatedTreatment: Treatment;
    if (isEditingTreatment && selectedTreatment) {
      updatedTreatment = {
        ...selectedTreatment,
        name: treatmentData.name,
        fee: parseFloat(treatmentData.fee),
        category: treatmentData.category,
        duration: parseInt(treatmentData.duration),
        description: treatmentData.description
      };
      setTreatments(prev => prev.map(t => t.id === selectedTreatment.id ? updatedTreatment : t));
    } else {
      updatedTreatment = {
        id: `t${Date.now()}`,
        name: treatmentData.name,
        fee: parseFloat(treatmentData.fee),
        category: treatmentData.category,
        duration: parseInt(treatmentData.duration),
        description: treatmentData.description
      };
      setTreatments(prev => [...prev, updatedTreatment]);
    }

    // Local save
    await putItem('treatments', updatedTreatment);

    // Close modal
    setShowTreatmentForm(false);

    // Background sync
    syncToFirebase('treatments', updatedTreatment);

    toast.success(`Treatment "${treatmentData.name}" saved`);
  };

  // Handle toggle all backup selections
  const toggleAllBackup = (checked: boolean) => {
    setBackupSelection({
      patients: checked,
      appointments: checked,
      bills: checked,
      inventory: checked,
      staff: checked,
      treatments: checked,
      expenses: checked,
    });
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <div className="space-y-6 p-4 md:p-6">
      {/* Header with Sync */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Settings</h1>
          <p className="text-muted-foreground">Manage clinic settings and configurations</p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={handleSync}
            variant="outline"
            disabled={isSyncing}
            className="gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            Sync Settings
          </Button>
          <Button 
            variant="outline" 
            className="gap-2"
            onClick={handleBackup}
          >
            <Database className="w-4 h-4" />
            Create Backup
          </Button>
        </div>
      </div>

      {/* Tabs - Only 4 tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid grid-cols-2 sm:grid-cols-4">
          <TabsTrigger value="security">
            <Lock className="w-4 h-4 mr-2" />
            Security
          </TabsTrigger>
          <TabsTrigger value="clinic">
            <SettingsIcon className="w-4 h-4 mr-2" />
            Clinic
          </TabsTrigger>
          <TabsTrigger value="treatments">
            <FileText className="w-4 h-4 mr-2" />
            Treatments
          </TabsTrigger>
          <TabsTrigger value="backup">
            <Database className="w-4 h-4 mr-2" />
            Backup
          </TabsTrigger>
        </TabsList>

        {/* Security Tab */}
        <TabsContent value="security" className="space-y-6">
          <div className="bg-white rounded-lg border p-6">
            <h3 className="text-lg font-medium mb-4">Change Password</h3>
            <div className="space-y-4 max-w-md">
              <div>
                <label className="block text-sm font-medium mb-2">Current Password</label>
                <div className="relative">
                  <Input
                    type={showCurrentPassword ? "text" : "password"}
                    value={passwordData.currentPassword}
                    onChange={(e) => setPasswordData({...passwordData, currentPassword: e.target.value})}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 -translate-y-1/2"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                  >
                    {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">New Password</label>
                <div className="relative">
                  <Input
                    type={showNewPassword ? "text" : "password"}
                    value={passwordData.newPassword}
                    onChange={(e) => setPasswordData({...passwordData, newPassword: e.target.value})}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 -translate-y-1/2"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                  >
                    {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Confirm New Password</label>
                <div className="relative">
                  <Input
                    type={showConfirmPassword ? "text" : "password"}
                    value={passwordData.confirmPassword}
                    onChange={(e) => setPasswordData({...passwordData, confirmPassword: e.target.value})}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 -translate-y-1/2"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
              <div className="pt-2">
                <Button onClick={handleChangePassword}>
                  <Lock className="w-4 h-4 mr-2" />
                  Change Password
                </Button>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Clinic Tab */}
        <TabsContent value="clinic" className="space-y-6">
          <div className="bg-white rounded-lg border p-6">
            <h3 className="text-lg font-medium mb-4">Clinic Information</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Clinic Name</label>
                <Input
                  value={clinicData.clinicName}
                  onChange={(e) => setClinicData({...clinicData, clinicName: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Address</label>
                <Input
                  value={clinicData.address}
                  onChange={(e) => setClinicData({...clinicData, address: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Phone</label>
                  <Input
                    value={clinicData.phone}
                    onChange={(e) => setClinicData({...clinicData, phone: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Email</label>
                  <Input
                    type="email"
                    value={clinicData.email}
                    onChange={(e) => setClinicData({...clinicData, email: e.target.value})}
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Tax Rate (%)</label>
                  <Input
                    type="number"
                    value={clinicData.taxRate}
                    onChange={(e) => setClinicData({...clinicData, taxRate: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Currency</label>
                  <select
                    value={clinicData.currency}
                    onChange={(e) => setClinicData({...clinicData, currency: e.target.value})}
                    className="w-full px-3 py-2 border rounded-lg"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="PKR">PKR (₨)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Business Hours</label>
                  <Input
                    value={clinicData.businessHours}
                    onChange={(e) => setClinicData({...clinicData, businessHours: e.target.value})}
                  />
                </div>
              </div>
              <div className="pt-4">
                <Button onClick={handleSaveClinicSettings}>
                  <Save className="w-4 h-4 mr-2" />
                  Save Clinic Settings
                </Button>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Treatments Tab */}
        <TabsContent value="treatments" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">Manage Treatments</h3>
            <Button onClick={handleAddTreatment} className="gap-2">
              <Plus className="w-4 h-4" />
              Add Treatment
            </Button>
          </div>

          <div className="bg-white rounded-lg border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="text-left p-3 font-medium">Treatment</th>
                    <th className="text-left p-3 font-medium">Category</th>
                    <th className="text-left p-3 font-medium">Fee</th>
                    <th className="text-left p-3 font-medium">Duration</th>
                    <th className="text-left p-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {treatments.map((treatment) => (
                    <tr key={treatment.id} className="border-b hover:bg-gray-50">
                      <td className="p-3">
                        <div className="font-medium">{treatment.name}</div>
                        {treatment.description && (
                          <div className="text-sm text-gray-500">{treatment.description}</div>
                        )}
                      </td>
                      <td className="p-3">
                        <Badge variant="outline">{treatment.category}</Badge>
                      </td>
                      <td className="p-3 font-bold">{formatCurrency(treatment.fee)}</td>
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4" />
                          {treatment.duration} min
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEditTreatment(treatment)}
                          >
                            <Edit className="w-3 h-3" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDeleteTreatment(treatment)}
                            className="text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </TabsContent>

        {/* Backup Tab */}
        <TabsContent value="backup" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Backup Settings */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white rounded-lg border p-6">
                <h3 className="text-lg font-medium mb-4">Backup Settings</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <label className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={Object.values(backupSelection).every(v => v)}
                        onChange={(e) => toggleAllBackup(e.target.checked)}
                        className="w-4 h-4"
                      />
                      <span className="font-medium">Select All</span>
                    </label>
                  </div>
                  
                  {Object.entries(backupSelection).map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between p-3 border rounded-lg">
                      <label className="flex items-center gap-3">
                        <input
                          type="checkbox"
                          checked={value}
                          onChange={(e) => setBackupSelection({...backupSelection, [key]: e.target.checked})}
                          className="w-4 h-4"
                        />
                        <span>{key.charAt(0).toUpperCase() + key.slice(1)}</span>
                      </label>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDownloadData(key)}
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Restore Backup */}
              <div className="bg-white rounded-lg border p-6">
                <h3 className="text-lg font-medium mb-4">Restore Backup</h3>
                <div className="space-y-4">
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <Upload className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-600 mb-4">Upload backup file (.json format)</p>
                    <label className="cursor-pointer">
                      <input
                        type="file"
                        accept=".json"
                        onChange={handleRestoreBackup}
                        className="hidden"
                      />
                      <Button variant="outline" asChild>
                        <span>Choose File</span>
                      </Button>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Backup History */}
            <div className="space-y-6">
              <div className="bg-white rounded-lg border p-6">
                <h3 className="text-lg font-medium mb-4">Backup History</h3>
                <div className="space-y-3">
                  {backupHistory.map((backup) => (
                    <div key={backup.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <div className="font-medium">{backup.date}</div>
                        <div className="text-sm text-gray-500">
                          {backup.type} • {backup.size}
                        </div>
                      </div>
                      <Badge className="bg-green-100 text-green-800">
                        {backup.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quick Actions */}
              <div className="bg-white rounded-lg border p-6">
                <h3 className="text-lg font-medium mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start gap-2"
                    onClick={() => handleDownloadData('patients')}
                  >
                    <Download className="w-4 h-4" />
                    Export Patients
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start gap-2"
                    onClick={() => handleDownloadData('doctors')}
                  >
                    <Download className="w-4 h-4" />
                    Export Doctors
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start gap-2"
                    onClick={() => handleDownloadData('treatments')}
                  >
                    <Download className="w-4 h-4" />
                    Export Treatments
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start gap-2"
                    onClick={() => handleBackup()}
                  >
                    <Database className="w-4 h-4" />
                    Create Full Backup
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Treatment Form Modal */}
      {showTreatmentForm && (
        <TreatmentFormModal
          open={showTreatmentForm}
          onClose={() => setShowTreatmentForm(false)}
          onSubmit={handleSaveTreatment}
          treatment={selectedTreatment}
          isEditing={isEditingTreatment}
        />
      )}
    </div>
  );
}