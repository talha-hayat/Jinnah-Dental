'use client';

import React, { useState, useEffect, useCallback } from 'react';
import {
  UserPlus,
  Search,
  Edit,
  Trash2,
  DollarSign,
  ChevronLeft,
  ChevronRight,
  Loader2,
  Filter,
  Download,
  Phone,
  Calendar,
  MapPin,
  Activity,
  AlertCircle,
  CheckCircle,
  XCircle,
  Users,
  RefreshCw,
  Eye,
  CreditCard,
  FileText
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Patient, QueueItem, Bill } from '@/types';
import { toast } from 'sonner';
import PatientFormModal from '@/components/modals/PatientFormModal';
import PatientDetailsModal from '@/components/modals/PatientDetailsModal';
import {
  getAllPatients,
  addPatient,
  updatePatient,
  deletePatient,
  getPatientStats
} from '@/services/patientService';
import {
  getQueueItemsByPatientNumber
} from '@/services/queueService';
import {
  getBillsByPatientNumber
} from '@/services/billingService';
import { syncPatientAfterTreatment } from '@/services/syncService';
import { format, parseISO } from 'date-fns';

export default function OperatorPatients() {
  // State Management
  const [patients, setPatients] = useState<Patient[]>([]);
  const [filteredPatients, setFilteredPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [syncingPatientId, setSyncingPatientId] = useState<string | null>(null);

  // Search & Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [balanceFilter, setBalanceFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('all');

  // Modals
  const [showPatientForm, setShowPatientForm] = useState(false);
  const [showPatientDetails, setShowPatientDetails] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [selectedPatientHistory, setSelectedPatientHistory] = useState<{
    queueHistory: QueueItem[];
    bills: Bill[];
  }>({ queueHistory: [], bills: [] });

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const patientsPerPage = 10;

  // Stats
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    pendingBalance: 0,
    totalVisits: 0,
    totalRevenue: 0,
    creditPatients: 0
  });

  // Initial Data Fetch
  useEffect(() => {
    fetchPatients();
  }, []);

  // Filter patients when search or filters change
  useEffect(() => {
    applyFilters();
  }, [patients, searchTerm, statusFilter, balanceFilter, dateFilter]);

  // Fetch all patients
  const fetchPatients = async () => {
    try {
      setLoading(true);
      const data = await getAllPatients();

      const patientsWithStats = await Promise.all(
        data.map(async (patient) => {
          try {
            const stats = await getPatientStats(patient.patientNumber);

            const openingBalance = patient.openingBalance || 0;
            const totalTreatmentFees = stats.totalTreatmentFees || 0;
            const totalPaid = stats.totalPaid || 0;
            
            // Calculate pending balance
            const totalDue = openingBalance + totalTreatmentFees;
            const pendingBalance = totalDue - totalPaid;

            return {
              ...patient,
              totalVisits: stats.totalVisits || patient.totalVisits || 0,
              totalPaid,
              pendingBalance,
              totalTreatmentFees,
              openingBalance,
              lastVisit: stats.lastVisit || patient.lastVisit,
              // Calculation metadata
              _calculations: {
                openingBalance,
                totalTreatmentFees,
                totalDue,
                totalPaid,
                rawPending: pendingBalance
              }
            };
          } catch (error) {
            console.error(`Error fetching stats for patient ${patient.patientNumber}:`, error);
            return {
              ...patient,
              totalVisits: patient.totalVisits || 0,
              totalPaid: patient.totalPaid || 0,
              pendingBalance: patient.pendingBalance || 0,
              totalTreatmentFees: 0,
              openingBalance: patient.openingBalance || 0
            };
          }
        })
      );

      setPatients(patientsWithStats);
      calculateStats(patientsWithStats);
    } catch (error) {
      console.error('Error loading patients:', error);
      toast.error('Failed to load patients');
    } finally {
      setLoading(false);
    }
  };

  // Calculate statistics
  const calculateStats = (patientList: Patient[]) => {
    const total = patientList.length;
    const active = patientList.filter(p => p.isActive !== false).length;
    const pendingBalance = patientList.reduce((sum, p) => sum + (p.pendingBalance || 0), 0);
    const totalVisits = patientList.reduce((sum, p) => sum + (p.totalVisits || 0), 0);
    const totalRevenue = patientList.reduce((sum, p) => sum + (p.totalPaid || 0), 0);
    const creditPatients = patientList.filter(p => (p.pendingBalance || 0) < 0).length;

    setStats({
      total,
      active,
      pendingBalance,
      totalVisits,
      totalRevenue,
      creditPatients
    });
  };

  // Apply filters to patients
  const applyFilters = () => {
    let result = patients;

    // Search filter
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase().trim();
      result = result.filter(patient => {
        const nameMatch = patient.name?.toLowerCase().includes(term) || false;
        const phoneMatch = patient.phone?.toLowerCase().includes(term) || false;
        const patientNumberMatch = patient.patientNumber?.toLowerCase().includes(term) || false;
        const emailMatch = patient.email?.toLowerCase().includes(term) || false;
        const addressMatch = patient.address?.toLowerCase().includes(term) || false;

        return nameMatch || phoneMatch || patientNumberMatch || emailMatch || addressMatch;
      });
    }

    // Status filter
    if (statusFilter !== 'all') {
      if (statusFilter === 'active') {
        result = result.filter(p => p.isActive !== false);
      } else if (statusFilter === 'inactive') {
        result = result.filter(p => p.isActive === false);
      }
    }

    // Balance filter
    if (balanceFilter !== 'all') {
      if (balanceFilter === 'zero') {
        result = result.filter(p => (p.pendingBalance || 0) === 0);
      } else if (balanceFilter === 'pending') {
        result = result.filter(p => (p.pendingBalance || 0) > 0);
      } else if (balanceFilter === 'credit') {
        result = result.filter(p => (p.pendingBalance || 0) < 0);
      }
    }

    // Date filter (last visit)
    if (dateFilter !== 'all') {
      const now = new Date();
      const thirtyDaysAgo = new Date(now.setDate(now.getDate() - 30));
      
      if (dateFilter === 'recent') {
        result = result.filter(p => {
          if (!p.lastVisit) return false;
          const lastVisitDate = new Date(p.lastVisit);
          return lastVisitDate >= thirtyDaysAgo;
        });
      } else if (dateFilter === 'old') {
        result = result.filter(p => {
          if (!p.lastVisit) return true;
          const lastVisitDate = new Date(p.lastVisit);
          return lastVisitDate < thirtyDaysAgo;
        });
      }
    }

    setFilteredPatients(result);
    setCurrentPage(1);
  };

  // Handle search
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  // Handle add new patient
  const handleAddPatient = () => {
    setSelectedPatient(null);
    setShowPatientForm(true);
  };

  // Handle edit patient
  const handleEditPatient = (patient: Patient) => {
    setSelectedPatient(patient);
    setShowPatientForm(true);
  };

  // Handle delete patient
  const handleDeletePatient = async (patient: Patient) => {
    if (!confirm(`Are you sure you want to delete patient ${patient.name} (${patient.patientNumber})?\nThis action cannot be undone.`)) {
      return;
    }

    try {
      await deletePatient(patient.id);
      setPatients(prev => prev.filter(p => p.id !== patient.id));
      toast.success(`Patient ${patient.name} deleted successfully`);

      if (selectedPatient?.id === patient.id) {
        setShowPatientDetails(false);
        setSelectedPatient(null);
      }
    } catch (error) {
      console.error('Error deleting patient:', error);
      toast.error('Failed to delete patient');
    }
  };

  // Handle save patient
  const handleSavePatient = async (patientData: any) => {
    try {
      setSaving(true);

      const patientPayload = {
        name: patientData.name?.trim() || '',
        phone: patientData.phone?.trim() || '',
        age: patientData.age ? Number(patientData.age) : 0,
        gender: patientData.gender || 'other',
        address: patientData.address?.trim() || '',
        email: patientData.email?.trim() || '',
        emergencyContact: patientData.emergencyContact?.trim() || '',
        bloodGroup: patientData.bloodGroup?.trim() || '',
        allergies: patientData.allergies?.trim() || '',
        medicalHistory: patientData.medicalHistory?.trim() || '',
        notes: patientData.notes?.trim() || '',
        openingBalance: Number(patientData.openingBalance || 0)
      };

      if (patientData.id && patientData.isEditing) {
        await updatePatient(patientData.id, patientPayload);

        setPatients(prev => prev.map(p =>
          p.id === patientData.id
            ? { ...p, ...patientPayload }
            : p
        ));

        toast.success('Patient updated successfully');
      } else {
        const newPatientData = {
          ...patientPayload,
          patientNumber: patientData.patientNumber,
          registrationDate: new Date().toISOString(),
          totalVisits: 0,
          totalPaid: 0,
          pendingBalance: Number(patientData.openingBalance || 0),
          isActive: true
        };

        const result = await addPatient(newPatientData);

        const newPatient: Patient = {
          id: result.id,
          patientNumber: result.patientNumber,
          ...newPatientData
        };

        setPatients(prev => [newPatient, ...prev]);
        toast.success(`${patientData.name} added successfully (ID: ${result.patientNumber})`);
      }

      setShowPatientForm(false);
      setSelectedPatient(null);
    } catch (error) {
      console.error('Error saving patient:', error);
      toast.error('Failed to save patient');
    } finally {
      setSaving(false);
    }
  };

  // Show patient calculations
  const showPatientCalculations = (patient: Patient) => {
    const calc = (patient as any)._calculations || {
      openingBalance: patient.openingBalance || 0,
      totalTreatmentFees: patient.totalTreatmentFees || 0,
      totalPaid: patient.totalPaid || 0
    };
    
    const totalDue = calc.openingBalance + calc.totalTreatmentFees;
    const pendingBalance = totalDue - calc.totalPaid;
    
    alert(`
Patient: ${patient.name} (${patient.patientNumber})
--------------------------------
Opening Balance: $${calc.openingBalance}
Total Treatment Fees: $${calc.totalTreatmentFees}
Total Due: $${totalDue}
Total Paid: $${calc.totalPaid}
Pending Balance: $${pendingBalance}
--------------------------------
Formula: (${calc.openingBalance} + ${calc.totalTreatmentFees}) - ${calc.totalPaid} = ${pendingBalance}
${pendingBalance < 0 ? 'Status: Credit Available' : pendingBalance > 0 ? 'Status: Payment Due' : 'Status: Settled'}
    `);
  };

  // Handle view patient details
  const handleViewPatientDetails = async (patient: Patient) => {
    setSelectedPatient(patient);

    try {
      const [queueHistory, bills] = await Promise.all([
        getQueueItemsByPatientNumber(patient.patientNumber),
        getBillsByPatientNumber(patient.patientNumber)
      ]);

      setSelectedPatientHistory({
        queueHistory,
        bills
      });

      setShowPatientDetails(true);
    } catch (error) {
      console.error('Error fetching patient history:', error);
      toast.error('Failed to load patient history');
    }
  };

  // Handle sync patient
  const handleSyncPatient = async (patient: Patient) => {
    try {
      setSyncingPatientId(patient.id);
      toast.info(`Syncing ${patient.name}...`);
      
      await syncPatientAfterTreatment(patient.patientNumber);
      
      // Refresh patient data
      await fetchPatients();
      
      toast.success(`${patient.name} synced successfully`);
    } catch (error) {
      console.error('Error syncing patient:', error);
      toast.error('Failed to sync patient');
    } finally {
      setSyncingPatientId(null);
    }
  };

  // Handle sync all patients
  const handleSyncAllPatients = async () => {
    try {
      setSyncing(true);
      toast.info('Syncing all patients...');

      await fetchPatients();

      toast.success('All patients synced successfully');
    } catch (error) {
      console.error('Error syncing all patients:', error);
      toast.error('Failed to sync patients');
    } finally {
      setSyncing(false);
    }
  };

  // Handle export data
  const handleExportData = () => {
    try {
      if (filteredPatients.length === 0) {
        toast.error('No data to export');
        return;
      }

      const headers = [
        'Patient ID', 'Name', 'Phone', 'Email', 'Age', 'Gender', 
        'Address', 'Registration Date', 'Total Visits', 
        'Total Paid', 'Pending Balance', 'Status'
      ];
      
      const csvData = filteredPatients.map(p => [
        p.patientNumber || 'N/A',
        p.name || 'N/A',
        p.phone || 'N/A',
        p.email || '',
        p.age || 0,
        p.gender || 'N/A',
        p.address || '',
        safeFormatDate(p.registrationDate) || 'N/A',
        p.totalVisits || 0,
        p.totalPaid || 0,
        p.pendingBalance || 0,
        p.isActive !== false ? 'Active' : 'Inactive'
      ]);

      const csvContent = [
        headers.join(','),
        ...csvData.map(row => row.map(cell => `"${cell}"`).join(','))
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `patients_${format(new Date(), 'yyyy-MM-dd_HH-mm')}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);

      toast.success('Data exported successfully');
    } catch (error) {
      console.error('Error exporting data:', error);
      toast.error('Failed to export data');
    }
  };

  // Handle clear filters
  const handleClearFilters = () => {
    setSearchTerm('');
    setStatusFilter('all');
    setBalanceFilter('all');
    setDateFilter('all');
  };

  // Safe date formatting
  const safeFormatDate = (dateString: string | undefined | null): string => {
    if (!dateString) return 'N/A';

    try {
      const date = parseISO(dateString);
      if (isNaN(date.getTime())) {
        return 'Invalid Date';
      }
      return format(date, 'MMM dd, yyyy');
    } catch (error) {
      try {
        const date = new Date(dateString);
        if (isNaN(date.getTime())) {
          return 'N/A';
        }
        return format(date, 'MMM dd, yyyy');
      } catch {
        return 'N/A';
      }
    }
  };

  // Format currency
  const formatCurrency = (amount: number | undefined): string => {
    const numAmount = amount || 0;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(numAmount);
  };

  // Get status badge
  const getStatusBadge = (patient: Patient) => {
    if (patient.isActive === false) {
      return <Badge variant="destructive" className="text-xs">Inactive</Badge>;
    }

    const pending = patient.pendingBalance || 0;
    
    if (pending > 0) {
      return (
        <Badge variant="outline" className="border-orange-200 text-orange-800 bg-orange-50 text-xs">
          Payment Due
        </Badge>
      );
    } else if (pending < 0) {
      return (
        <Badge variant="outline" className="border-blue-200 text-blue-800 bg-blue-50 text-xs">
          Credit Available
        </Badge>
      );
    }

    return (
      <Badge variant="outline" className="border-green-200 text-green-800 bg-green-50 text-xs">
        Active
      </Badge>
    );
  };

  // Get pending amount display
  const getPendingDisplay = (patient: Patient) => {
    const pending = patient.pendingBalance || 0;
    
    if (pending === 0) {
      return <span className="text-gray-600 text-sm">--</span>;
    }
    
    const colorClass = pending > 0 ? 'text-orange-600' : 'text-blue-600';
    const prefix = pending < 0 ? '(Credit) ' : '';
    const absAmount = Math.abs(pending);
    
    return (
      <span className={`font-semibold text-sm ${colorClass}`}>
        {prefix}{formatCurrency(absAmount)}
      </span>
    );
  };

  // Get visits badge
  const getVisitsBadge = (patient: Patient) => {
    const visits = patient.totalVisits || 0;
    
    if (visits === 0) {
      return <Badge variant="outline" className="bg-gray-50 text-xs">New</Badge>;
    }
    
    let variant: "secondary" | "default" | "outline" = "secondary";
    if (visits >= 10) variant = "default";
    
    return (
      <Badge variant={variant} className="text-xs">
        {visits} visit{visits !== 1 ? 's' : ''}
      </Badge>
    );
  };

  // Pagination calculations
  const indexOfLastPatient = currentPage * patientsPerPage;
  const indexOfFirstPatient = indexOfLastPatient - patientsPerPage;
  const currentPatients = filteredPatients.slice(indexOfFirstPatient, indexOfLastPatient);
  const totalPages = Math.ceil(filteredPatients.length / patientsPerPage);

  return (
    <div className="space-y-6 p-4 md:p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Patient Management</h1>
          <p className="text-muted-foreground">
            Manage all patient records and track payments
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={handleSyncAllPatients}
            className="gap-2"
            disabled={syncing || loading}
          >
            <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
            {syncing ? 'Syncing...' : 'Sync All'}
          </Button>
          <Button 
            variant="outline" 
            onClick={handleExportData} 
            className="gap-2"
            disabled={loading}
          >
            <Download className="w-4 h-4" />
            Export
          </Button>
          <Button 
            onClick={handleAddPatient} 
            className="gap-2"
            disabled={loading}
          >
            <UserPlus className="w-4 h-4" />
            Add Patient
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white border rounded-lg p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold">{stats.total}</div>
              <div className="text-sm text-gray-600">Total Patients</div>
            </div>
            <Users className="w-8 h-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white border rounded-lg p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold">{stats.active}</div>
              <div className="text-sm text-gray-600">Active</div>
            </div>
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
        </div>

        <div className="bg-white border rounded-lg p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold">{formatCurrency(stats.pendingBalance)}</div>
              <div className="text-sm text-gray-600">Pending Balance</div>
            </div>
            <AlertCircle className="w-8 h-8 text-orange-500" />
          </div>
        </div>

        <div className="bg-white border rounded-lg p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold">{stats.totalVisits}</div>
              <div className="text-sm text-gray-600">Total Visits</div>
            </div>
            <Activity className="w-8 h-8 text-purple-500" />
          </div>
        </div>

        <div className="bg-white border rounded-lg p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold">{formatCurrency(stats.totalRevenue)}</div>
              <div className="text-sm text-gray-600">Total Revenue</div>
            </div>
            <DollarSign className="w-8 h-8 text-green-500" />
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white border rounded-lg p-4 space-y-4 shadow-sm">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, phone, ID, email..."
              className="pl-9"
              value={searchTerm}
              onChange={handleSearch}
              disabled={loading}
            />
          </div>

          <Select value={statusFilter} onValueChange={setStatusFilter} disabled={loading}>
            <SelectTrigger className="w-[160px]">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
            </SelectContent>
          </Select>

          <Select value={balanceFilter} onValueChange={setBalanceFilter} disabled={loading}>
            <SelectTrigger className="w-[160px]">
              <CreditCard className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Balance" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Balance</SelectItem>
              <SelectItem value="zero">Zero Balance</SelectItem>
              <SelectItem value="pending">Has Pending</SelectItem>
              <SelectItem value="credit">Has Credit</SelectItem>
            </SelectContent>
          </Select>

          <Select value={dateFilter} onValueChange={setDateFilter} disabled={loading}>
            <SelectTrigger className="w-[160px]">
              <Calendar className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Last Visit" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Visits</SelectItem>
              <SelectItem value="recent">Recent (30 days)</SelectItem>
              <SelectItem value="old">Older (30+ days)</SelectItem>
            </SelectContent>
          </Select>

          <Button 
            variant="outline" 
            onClick={handleClearFilters}
            disabled={loading}
          >
            Clear Filters
          </Button>
        </div>

        <div className="flex justify-between items-center">
          <div className="text-sm text-gray-500">
            Showing {filteredPatients.length} of {patients.length} patients
            {searchTerm && ` • Search: "${searchTerm}"`}
          </div>
          <div className="text-sm text-gray-500">
            {stats.creditPatients} patient(s) with credit balance
          </div>
        </div>
      </div>

      {/* Loading State */}
      {loading ? (
        <div className="flex flex-col justify-center items-center h-64 bg-white border rounded-lg">
          <Loader2 className="w-8 h-8 animate-spin text-primary mb-4" />
          <span className="text-gray-600">Loading patients...</span>
        </div>
      ) : (
        <>
          {/* Patients Table */}
          <div className="bg-white rounded-lg border overflow-hidden shadow-sm">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="font-semibold">Patient ID</TableHead>
                  <TableHead className="font-semibold">Name</TableHead>
                  <TableHead className="font-semibold">Contact</TableHead>
                  <TableHead className="font-semibold">Age/Gender</TableHead>
                  <TableHead className="font-semibold">Visits</TableHead>
                  <TableHead className="font-semibold">Balance Status</TableHead>
                  <TableHead className="font-semibold">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {currentPatients.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                      <div className="space-y-3">
                        <Users className="w-16 h-16 mx-auto text-gray-300" />
                        <p className="text-lg font-medium">No patients found</p>
                        <p className="text-sm text-gray-500">
                          {searchTerm || statusFilter !== 'all' || balanceFilter !== 'all' 
                            ? 'Try changing your search or filters' 
                            : 'Add your first patient to get started'}
                        </p>
                        {/* <Button onClick={handleAddPatient} className="mt-4">
                          <UserPlus className="w-4 h-4 mr-2" />
                          Add Patient
                        </Button> */}
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  currentPatients.map((patient) => (
                    <TableRow
                      key={patient.id}
                      className="cursor-pointer hover:bg-gray-50 transition-colors"
                      onClick={() => handleViewPatientDetails(patient)}
                    >
                      <TableCell>
                        <div className="font-mono font-bold text-sm">{patient.patientNumber}</div>
                        <div className="text-xs text-gray-500">
                          {safeFormatDate(patient.registrationDate)}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{patient.name}</div>
                        {patient.email && (
                          <div className="text-xs text-gray-500 truncate max-w-[180px]">
                            {patient.email}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Phone className="w-3 h-3 text-gray-500" />
                          <span className="text-sm">{patient.phone || '--'}</span>
                        </div>
                        {patient.emergencyContact && (
                          <div className="text-xs text-gray-500 mt-1">
                            Emergency: {patient.emergencyContact}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          {patient.age || 0} years
                        </div>
                        <div className="text-xs text-gray-600 capitalize">
                          {patient.gender || 'Not specified'}
                        </div>
                      </TableCell>
                      <TableCell>
                        {getVisitsBadge(patient)}
                        {patient.lastVisit && (
                          <div className="text-xs text-gray-500 mt-1">
                            Last: {safeFormatDate(patient.lastVisit)}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="text-xs text-gray-600">
                            Paid: {formatCurrency(patient.totalPaid)}
                          </div>
                          <div
                            className="cursor-help"
                            onClick={(e) => {
                              e.stopPropagation();
                              showPatientCalculations(patient);
                            }}
                            title="Click for calculation details"
                          >
                            {getPendingDisplay(patient)}
                          </div>
                          <div className="mt-1">
                            {getStatusBadge(patient)}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleViewPatientDetails(patient);
                            }}
                            className="h-8 w-8 p-0"
                            title="View Details"
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleSyncPatient(patient);
                            }}
                            className="h-8 w-8 p-0"
                            title="Sync Data"
                            disabled={syncingPatientId === patient.id}
                          >
                            <RefreshCw className={`w-4 h-4 ${syncingPatientId === patient.id ? 'animate-spin' : ''}`} />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEditPatient(patient);
                            }}
                            className="h-8 w-8 p-0"
                            title="Edit"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeletePatient(patient);
                            }}
                            className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {filteredPatients.length > 0 && (
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white border rounded-lg p-4 shadow-sm">
              <div className="text-sm text-muted-foreground">
                Showing {indexOfFirstPatient + 1} to {Math.min(indexOfLastPatient, filteredPatients.length)} of {filteredPatients.length} entries
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className="h-8 w-8 p-0"
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <div className="flex items-center gap-1">
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    let pageNum;
                    if (totalPages <= 5) {
                      pageNum = i + 1;
                    } else if (currentPage <= 3) {
                      pageNum = i + 1;
                    } else if (currentPage >= totalPages - 2) {
                      pageNum = totalPages - 4 + i;
                    } else {
                      pageNum = currentPage - 2 + i;
                    }
                    
                    return (
                      <Button
                        key={pageNum}
                        variant={currentPage === pageNum ? "default" : "outline"}
                        size="sm"
                        onClick={() => setCurrentPage(pageNum)}
                        className="h-8 w-8 p-0"
                      >
                        {pageNum}
                      </Button>
                    );
                  })}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                  className="h-8 w-8 p-0"
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </>
      )}

      {/* Patient Form Modal */}
      {showPatientForm && (
        <PatientFormModal
          open={showPatientForm}
          onClose={() => {
            setShowPatientForm(false);
            setSelectedPatient(null);
          }}
          onSubmit={handleSavePatient}
          patient={selectedPatient}
          isEditing={!!selectedPatient}
          mode="patient"
          existingPatients={patients}
          title={selectedPatient ? 'Edit Patient' : 'Add New Patient'}
          loading={saving}
        />
      )}

      {/* Patient Details Modal */}
      {showPatientDetails && selectedPatient && (
        <PatientDetailsModal
          patient={selectedPatient}
          patientInfo={selectedPatient}
          onClose={() => {
            setShowPatientDetails(false);
            setSelectedPatient(null);
          }}
          onEdit={() => {
            setShowPatientDetails(false);
            setShowPatientForm(true);
          }}
          onDelete={() => handleDeletePatient(selectedPatient)}
          queueHistory={selectedPatientHistory.queueHistory}
          bills={selectedPatientHistory.bills}
        />
      )}
    </div>
  );
}