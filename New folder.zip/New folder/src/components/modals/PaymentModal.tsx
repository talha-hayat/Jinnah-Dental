'use client';

import React, { useState, useEffect } from 'react';
import { X, DollarSign, Receipt, History, Printer, Loader2, Smartphone, Building } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { QueueItem, Bill } from '@/types';
import { toast } from 'sonner';

interface PaymentModalProps {
  queueItem: QueueItem;
  bills: Bill[];          // ← now required (not optional)
  onClose: () => void;
  onSubmit: (queueItem: QueueItem, paymentData: any) => Promise<void> | void;
}

export default function PaymentModal({
  queueItem,
  bills = [],           // fallback empty array
  onClose,
  onSubmit
}: PaymentModalProps) {
  const [paymentData, setPaymentData] = useState({
    amount: 0,
    paymentMethod: 'cash' as 'cash' | 'online' | 'bank',
    discount: 0,
    notes: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);

  // ────────────────────────────────────────────────
  // Calculations
  // ────────────────────────────────────────────────

  const treatmentFee = Number(queueItem.fee || 0);
  const alreadyPaidThisVisit = Number(queueItem.amountPaid || 0);

  // Sum of all PREVIOUS bills' pending (not including current visit)
  const previousPending = bills
    .filter(b => b.patientId === queueItem.patientNumber)
    .reduce((sum, bill) => {
      const total = Number(bill.totalAmount || 0);
      const paid = Number(bill.amountPaid || 0);
      return sum + Math.max(0, total - paid);
    }, 0);

  const totalDueBeforeDiscount = treatmentFee + previousPending;
  const totalDueAfterDiscount = totalDueBeforeDiscount - paymentData.discount;
  const remainingAfterThisPayment = Math.max(0, totalDueAfterDiscount - paymentData.amount);

  // Effective remaining BEFORE this payment attempt
  const maxPayable = Math.max(0, totalDueBeforeDiscount - alreadyPaidThisVisit);

  useEffect(() => {
    // Auto-set full remaining amount when modal opens / data changes
    setPaymentData(prev => ({
      ...prev,
      amount: maxPayable
    }));
  }, [maxPayable]);

  // ────────────────────────────────────────────────
  // Handlers
  // ────────────────────────────────────────────────

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setPaymentData(prev => ({
      ...prev,
      [name]: name === 'amount' || name === 'discount'
        ? Number(value) || 0
        : value
    }));
  };

  const handleFullPayment = () => {
    setPaymentData(prev => ({ ...prev, amount: maxPayable }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const payAmount = Number(paymentData.amount);

    if (payAmount <= 0) return toast.error('Please enter a valid amount');
    if (payAmount > maxPayable) {
      return toast.error(`Cannot pay more than remaining $${maxPayable.toFixed(2)}`);
    }

    setIsSubmitting(true);

    try {
      await onSubmit(queueItem, {
        ...paymentData,
        amount: payAmount,
        discount: Number(paymentData.discount) || 0
      });

      toast.success('Payment processed successfully');
      onClose();
    } catch (err: any) {
      console.error(err);
      toast.error(err.message || 'Failed to process payment');
    } finally {
      setIsSubmitting(false);
    }
  };

  // ────────────────────────────────────────────────
  // Print (simple text version – can be improved with ESC/POS later)
  // ────────────────────────────────────────────────

const handlePrint = () => {
  const printContent = `
JINNAH DENTAL CLINIC
Token: #${queueItem.tokenNumber || '—'}
Patient: ${queueItem.patientName}
Phone: ${queueItem.patientPhone || 'N/A'}
Date: ${new Date().toLocaleString('en-PK')}

──────────────────────────────
Treatment: ${queueItem.treatment || '—'}
Fee:          PKR ${treatmentFee.toFixed(0)}
Prev. Pending: PKR ${previousPending.toFixed(0)}
──────────────────────────────
Total Due:    PKR ${totalDueAfterDiscount.toFixed(0)}
Paid Now:     PKR ${Number(paymentData.amount).toFixed(0)}
Remaining:    PKR ${remainingAfterThisPayment.toFixed(0)}

Method: ${paymentData.paymentMethod.toUpperCase()}
Notes: ${paymentData.notes || '—'}

Thank You! Visit Again
──────────────────────────────
Powered by Sanyz Technologies
`.trim();

  // Important changes ↓↓↓
  const printWindow = window.open('', '_blank');
  if (printWindow) {
    printWindow.document.write(`
      <html>
        <head>
          <title>Receipt</title>
          <style>
            @page {
              size: 72mm 1000mm;   /* ← yeh bohot zaroori hai */
              margin: 0;
            }
            body {
              margin: 0;
              padding: 3mm 4mm;
              font-family: "Courier New", Courier, monospace;
              font-size: 17px !important;   /* chhota rakho */
              line-height: 1.1;
              color: black !important;
              width: 75mm;   /* paper se thoda chhota rakho */
              white-space: pre-wrap;
              word-break: break-all;
            }
            pre {
              margin: 0;
            }
          </style>
        </head>
        <body>
          <pre>${printContent}</pre>
          <script>
            window.onload = function() {
              window.print();
              setTimeout(() => window.close(), 1500);
            }
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  }
};

  // ────────────────────────────────────────────────
  // Render
  // ────────────────────────────────────────────────

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-lg max-h-[92vh] overflow-y-auto shadow-2xl">

        {/* Header */}
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex items-center justify-between z-10">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-green-600" />
            Payment – {queueItem.patientName}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">

          {/* Patient Quick Info */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-gray-50 p-4 rounded-lg border">
            <div>
              <p className="text-xs text-muted-foreground">Token</p>
              <p className="font-semibold">#{queueItem.tokenNumber || '—'}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Phone</p>
              <p className="font-medium">{queueItem.patientPhone || '—'}</p>
            </div>
            {/* <div>
              <p className="text-xs text-muted-foreground">Treatment</p>
              <p className="font-medium">{queueItem.treatment || '—'}</p>
            </div> */}
            <div>
              <p className="text-xs text-muted-foreground">Already Paid</p>
              <p className="font-medium">${alreadyPaidThisVisit.toFixed(2)}</p>
            </div>
          </div>

          {/* Bill Summary */}
          <div className="border rounded-lg p-5 bg-white shadow-sm">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Receipt className="h-4 w-4" />
              Bill Summary
            </h3>

            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span>Treatment Fee</span>
                <span>${treatmentFee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-orange-700">
                <span>Previous Pending</span>
                <span>${previousPending.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Discount</span>
                <Input
                  type="number"
                  disabled={true}
                  name="discount"
                  value={paymentData.discount}
                  onChange={handleChange}
                  min={0}
                  step={0.01}
                  max={totalDueBeforeDiscount}
                  className="w-24 h-8 text-right"
                  placeholder="0"
                />
              </div>
              <div className="flex justify-between pt-3 border-t font-bold text-base">
                <span>Total Due</span>
                <span>${totalDueAfterDiscount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-red-600 font-semibold">
                <span>Remaining to Pay</span>
                <span>${maxPayable.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Payment History (if any) */}
          {bills.length > 0 && (
            <div className="border rounded-lg p-4">
              <h3 className="font-medium mb-3 flex items-center gap-2">
                <History className="h-4 w-4" />
                Previous Payments
              </h3>
              <div className="max-h-40 overflow-y-auto space-y-2 text-sm">
                {bills
                  .filter(b => b.patientId === queueItem.patientNumber)
                  .map(bill => (
                    <div
                      key={bill.id || bill.billNumber}
                      className="flex justify-between items-center p-2 bg-gray-50 rounded"
                    >
                      <div>
                        <div className="font-medium">{bill.billNumber || '—'}</div>
                        <div className="text-xs text-muted-foreground">
                          {bill.createdAt
                            ? new Date(bill.createdAt.seconds * 1000).toLocaleDateString('en-PK')
                            : '—'}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-green-600">
                          ${Number(bill.amountPaid || 0).toFixed(2)}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {bill.paymentStatus || 'pending'}
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* Payment Inputs */}
          <form onSubmit={handleSubmit} className="space-y-5">

            <div className="space-y-2">
              <Label htmlFor="amount">Amount Paying</Label>
              <div className="flex gap-3">
                <Input
                  id="amount"
                  name="amount"
                  type="number"
                  value={paymentData.amount}
                  onChange={handleChange}
                  min={0}
                  max={maxPayable}
                  step={0.01}
                  required
                  className="flex-1"
                />
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={handleFullPayment}
                  disabled={maxPayable <= 0}
                >
                  Pay Full
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Max allowed: ${maxPayable.toFixed(2)}
              </p>
            </div>

            <div className="space-y-2">
              <Label>Payment Method</Label>
              <div className="grid grid-cols-3 gap-3">
                {(['cash', 'online', 'bank'] as const).map(method => (
                  <Button
                    key={method}
                    type="button"
                    variant={paymentData.paymentMethod === method ? 'default' : 'outline'}
                    className="h-11 flex flex-col items-center gap-1 py-2"
                    onClick={() => setPaymentData(prev => ({ ...prev, paymentMethod: method }))}
                  >
                    {method === 'cash' && <DollarSign className="h-4 w-4" />}
                    {method === 'online' && <Smartphone className="h-4 w-4" />}
                    {method === 'bank' && <Building className="h-4 w-4" />}
                    <span className="text-xs capitalize">{method}</span>
                  </Button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes (optional)</Label>
              <Input
                id="notes"
                name="notes"
                value={paymentData.notes}
                onChange={handleChange}
                placeholder="e.g. Paid via JazzCash"
              />
            </div>

            <div className="flex gap-3 pt-4 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="flex-1"
                disabled={isSubmitting}
              >
                Cancel
              </Button>

              <Button
                type="submit"
                disabled={isSubmitting || maxPayable <= 0}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  'Process Payment'
                )}
              </Button>

              <Button
                type="button"
                variant="outline"
                onClick={handlePrint}
                disabled={isPrinting}
                className="min-w-[110px]"
              >
                {isPrinting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Printing...
                  </>
                ) : (
                  <>
                    <Printer className="mr-2 h-4 w-4" />
                    Print
                  </>
                )}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}