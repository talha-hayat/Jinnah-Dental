'use client';

import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

// Types (inlined since import might not work)
type ExpenseCategory = 'rent' | 'salary' | 'supplies' | 'utilities' | 'equipment' | 'medication' | 'maintenance' | 'other';
type PaymentMethod = 'cash' | 'card' | 'bank_transfer' | 'cheque' | 'online';

interface Expense {
  id: string;
  title: string;
  amount: number;
  category: ExpenseCategory;
  paymentMethod: PaymentMethod;
  date: string;
  description: string;
  vendor?: string;
  receiptNumber?: string;
  status: 'paid' | 'pending' | 'cancelled';
  createdAt: string;
  updatedAt: string;
  paidBy?: string;
  attachment?: string;
}

// IndexedDB Helper Functions
const ensureStoreExists = async (storeName: string): Promise<void> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('ClinicDB', 6);
    
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(storeName)) {
        console.log(`Creating ${storeName} store on demand`);
        db.createObjectStore(storeName, { keyPath: 'id' });
      }
    };
    
    request.onsuccess = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      // Check if store exists after upgrade
      if (!db.objectStoreNames.contains(storeName)) {
        // Close and reopen with higher version to force upgrade
        db.close();
        const upgradeRequest = indexedDB.open('ClinicDB', 6);
        
        upgradeRequest.onupgradeneeded = (upgradeEvent) => {
          const upgradeDb = (upgradeEvent.target as IDBOpenDBRequest).result;
          if (!upgradeDb.objectStoreNames.contains(storeName)) {
            console.log(`Creating ${storeName} store during forced upgrade`);
            upgradeDb.createObjectStore(storeName, { keyPath: 'id' });
          }
        };
        
        upgradeRequest.onsuccess = () => {
          console.log(`Store ${storeName} created successfully`);
          resolve();
        };
        
        upgradeRequest.onerror = () => reject(upgradeRequest.error);
      } else {
        console.log(`Store ${storeName} exists`);
        resolve();
      }
    };
    
    request.onerror = () => reject(request.error);
  });
};

const putItem = async (storeName: string, item: any): Promise<void> => {
  try {
    // First ensure store exists
    await ensureStoreExists(storeName);
    
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('ClinicDB', 6);
      
      request.onsuccess = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        
        try {
          const transaction = db.transaction(storeName, 'readwrite');
          const store = transaction.objectStore(storeName);
          const putRequest = store.put(item);
          
          putRequest.onsuccess = () => resolve();
          putRequest.onerror = () => reject(putRequest.error);
        } catch (error) {
          reject(error);
        }
      };
      
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error(`Error in putItem for ${storeName}:`, error);
    throw error;
  }
};

// Category options
const categoryOptions: { value: ExpenseCategory; label: string }[] = [
  { value: 'rent', label: 'Rent' },
  { value: 'salary', label: 'Salary' },
  { value: 'supplies', label: 'Supplies' },
  { value: 'utilities', label: 'Utilities' },
  { value: 'equipment', label: 'Equipment' },
  { value: 'medication', label: 'Medication' },
  { value: 'maintenance', label: 'Maintenance' },
  { value: 'other', label: 'Other' }
];

// Payment method options
const paymentMethodOptions: { value: PaymentMethod; label: string }[] = [
  { value: 'cash', label: 'Cash' },
  { value: 'card', label: 'Card' },
  { value: 'bank_transfer', label: 'Bank Transfer' },
  { value: 'cheque', label: 'Cheque' },
  { value: 'online', label: 'Online' }
];

// Status options
const statusOptions = [
  { value: 'paid', label: 'Paid' },
  { value: 'pending', label: 'Pending' },
  { value: 'cancelled', label: 'Cancelled' }
];

interface ExpenseFormModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (expenseData: any) => void;
  expense?: Expense | null;
  isEditing?: boolean;
}

export default function ExpenseFormModal({
  open,
  onClose,
  onSubmit,
  expense,
  isEditing = false
}: ExpenseFormModalProps) {
  const [formData, setFormData] = useState({
    title: '',
    amount: '',
    category: 'rent' as ExpenseCategory,
    paymentMethod: 'cash' as PaymentMethod,
    date: new Date().toISOString().split('T')[0],
    description: '',
    vendor: '',
    receiptNumber: '',
    status: 'pending' as 'paid' | 'pending' | 'cancelled',
    paidBy: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (expense) {
      setFormData({
        title: expense.title || '',
        amount: expense.amount?.toString() || '',
        category: expense.category || 'rent',
        paymentMethod: expense.paymentMethod || 'cash',
        date: expense.date ? expense.date.split('T')[0] : new Date().toISOString().split('T')[0],
        description: expense.description || '',
        vendor: expense.vendor || '',
        receiptNumber: expense.receiptNumber || '',
        status: expense.status || 'pending',
        paidBy: expense.paidBy || ''
      });
    } else {
      // Reset form for new expense
      setFormData({
        title: '',
        amount: '',
        category: 'rent',
        paymentMethod: 'cash',
        date: new Date().toISOString().split('T')[0],
        description: '',
        vendor: '',
        receiptNumber: '',
        status: 'pending',
        paidBy: ''
      });
    }
  }, [expense]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Validate
      if (!formData.title.trim()) {
        toast.error('Title is required');
        setIsSubmitting(false);
        return;
      }
      
      if (!formData.amount || parseFloat(formData.amount) <= 0) {
        toast.error('Valid amount is required');
        setIsSubmitting(false);
        return;
      }
      
      if (!formData.date) {
        toast.error('Date is required');
        setIsSubmitting(false);
        return;
      }
      
      // Prepare expense data
      const expenseData = {
        ...formData,
        amount: parseFloat(formData.amount),
        date: new Date(formData.date).toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      // If editing, preserve the original ID
      if (isEditing && expense) {
        expenseData.id = expense.id;
      } else {
        expenseData.id = `exp-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      }
      
      // Save to IndexedDB first
      try {
        await putItem('expenses', expenseData);
        console.log('Expense saved to IndexedDB:', expenseData);
      } catch (error) {
        console.error('Failed to save to IndexedDB:', error);
        toast.error('Failed to save expense locally. Please try again.');
        setIsSubmitting(false);
        return;
      }
      
      // Call parent's onSubmit with the complete expense object
      onSubmit(expenseData);
      setIsSubmitting(false);
      
    } catch (error) {
      console.error('Error submitting form:', error);
      toast.error('Failed to submit expense form');
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-semibold">
            {isEditing ? 'Edit Expense' : 'Add New Expense'}
          </h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded"
            disabled={isSubmitting}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {/* Title */}
          <div>
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              name="title"
              value={formData.title}
              onChange={handleChange}
              placeholder="e.g., Monthly Rent, Supplies Purchase"
              required
              disabled={isSubmitting}
            />
          </div>

          {/* Amount and Category */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="amount">Amount (USD) *</Label>
              <Input
                id="amount"
                name="amount"
                type="number"
                step="0.01"
                value={formData.amount}
                onChange={handleChange}
                placeholder="0.00"
                min="0.01"
                required
                disabled={isSubmitting}
              />
            </div>
            <div>
              <Label htmlFor="category">Category *</Label>
              <select
                id="category"
                name="category"
                value={formData.category}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg disabled:bg-gray-100 disabled:cursor-not-allowed"
                required
                disabled={isSubmitting}
              >
                {categoryOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Payment Method and Status */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="paymentMethod">Payment Method</Label>
              <select
                id="paymentMethod"
                name="paymentMethod"
                value={formData.paymentMethod}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg disabled:bg-gray-100 disabled:cursor-not-allowed"
                disabled={isSubmitting}
              >
                {paymentMethodOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Label htmlFor="status">Status</Label>
              <select
                id="status"
                name="status"
                value={formData.status}
                onChange={handleChange}
                className="w-full px-3 py-2 border rounded-lg disabled:bg-gray-100 disabled:cursor-not-allowed"
                disabled={isSubmitting}
              >
                {statusOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Date and Receipt Number */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="date">Date *</Label>
              <Input
                id="date"
                name="date"
                type="date"
                value={formData.date}
                onChange={handleChange}
                required
                disabled={isSubmitting}
              />
            </div>
            <div>
              <Label htmlFor="receiptNumber">Receipt Number</Label>
              <Input
                id="receiptNumber"
                name="receiptNumber"
                value={formData.receiptNumber}
                onChange={handleChange}
                placeholder="OPT-001"
                disabled={isSubmitting}
              />
            </div>
          </div>

          {/* Vendor and Paid By */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="vendor">Vendor/Supplier</Label>
              <Input
                id="vendor"
                name="vendor"
                value={formData.vendor}
                onChange={handleChange}
                placeholder="Company name"
                disabled={isSubmitting}
              />
            </div>
            <div>
              <Label htmlFor="paidBy">Paid By</Label>
              <Input
                id="paidBy"
                name="paidBy"
                value={formData.paidBy}
                onChange={handleChange}
                placeholder="Person who made payment"
                disabled={isSubmitting}
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              placeholder="Details about this expense..."
              rows={3}
              disabled={isSubmitting}
            />
          </div>

          {/* Buttons */}
          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-green-600 hover:bg-green-700"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  {isEditing ? 'Updating...' : 'Adding...'}
                </div>
              ) : (
                isEditing ? 'Update Expense' : 'Add Expense'
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}