import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  getDocs,
  getDoc,
  query,
  where,
  orderBy,
  Timestamp,
  serverTimestamp
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Patient } from "@/types";

const patientsRef = collection(db, "patients");

// Get patient by patientNumber (4-digit ID)
export const getPatientByNumber = async (patientNumber: string): Promise<Patient | null> => {
  try {
    const q = query(patientsRef, where("patientNumber", "==", patientNumber));
    const snapshot = await getDocs(q);
    
    if (snapshot.empty) {
      return null;
    }
    
    const doc = snapshot.docs[0];
    const data = doc.data();
    
    return {
      id: doc.id,
      patientNumber: data.patientNumber || patientNumber,
      name: data.name || '',
      phone: data.phone || '',
      age: data.age || 0,
      gender: data.gender || 'other',
      address: data.address || '',
      openingBalance: data.openingBalance || 0,
      email: data.email || '',
      emergencyContact: data.emergencyContact || '',
      bloodGroup: data.bloodGroup || '',
      allergies: data.allergies || '',
      medicalHistory: data.medicalHistory || '',
      notes: data.notes || '',
      registrationDate: data.registrationDate || '',
      lastVisit: data.lastVisit || '',
      totalVisits: data.totalVisits || 0,
      totalPaid: data.totalPaid || 0,
      pendingBalance: data.pendingBalance || 0,
      isActive: data.isActive !== false, // default true
      createdAt: data.createdAt?.toDate?.()?.toISOString() || data.createdAt || new Date().toISOString(),
      updatedAt: data.updatedAt?.toDate?.()?.toISOString() || data.updatedAt
    } as Patient;
  } catch (error) {
    console.error("Error getting patient by number:", error);
    return null;
  }
};

export const getAllPatients = async (): Promise<Patient[]> => {
  try {
    const q = query(patientsRef, orderBy("createdAt", "desc"));
    const snapshot = await getDocs(q);

    const patients = snapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        patientNumber: data.patientNumber || '',
        name: data.name || '',
        phone: data.phone || '',
        age: data.age || 0,
        gender: data.gender || 'other',
        address: data.address || '',
        openingBalance: data.openingBalance || 0,
        email: data.email || '',
        emergencyContact: data.emergencyContact || '',
        bloodGroup: data.bloodGroup || '',
        allergies: data.allergies || '',
        medicalHistory: data.medicalHistory || '',
        notes: data.notes || '',
        registrationDate: data.registrationDate || '',
        lastVisit: data.lastVisit || '',
        totalVisits: data.totalVisits || 0,
        totalPaid: data.totalPaid || 0,
        pendingBalance: data.pendingBalance || 0,
        isActive: data.isActive !== false,
        createdAt: data.createdAt?.toDate?.()?.toISOString() || data.createdAt || new Date().toISOString(),
        updatedAt: data.updatedAt?.toDate?.()?.toISOString() || data.updatedAt
      } as Patient;
    });

    return patients;
  } catch (error) {
    console.error("Error getting patients:", error);
    return [];
  }
};

export const getPatientById = async (patientId: string): Promise<Patient | null> => {
  try {
    const patientRef = doc(db, 'patients', patientId);
    const snapshot = await getDoc(patientRef);
    
    if (!snapshot.exists()) {
      return null;
    }
    
    const data = snapshot.data();
    return {
      id: snapshot.id,
      patientNumber: data.patientNumber || '',
      name: data.name || '',
      phone: data.phone || '',
      age: data.age || 0,
      gender: data.gender || 'other',
      address: data.address || '',
      openingBalance: data.openingBalance || 0,
      email: data.email || '',
      emergencyContact: data.emergencyContact || '',
      bloodGroup: data.bloodGroup || '',
      allergies: data.allergies || '',
      medicalHistory: data.medicalHistory || '',
      notes: data.notes || '',
      registrationDate: data.registrationDate || '',
      lastVisit: data.lastVisit || '',
      totalVisits: data.totalVisits || 0,
      totalPaid: data.totalPaid || 0,
      pendingBalance: data.pendingBalance || 0,
      isActive: data.isActive !== false,
      createdAt: data.createdAt?.toDate?.()?.toISOString() || data.createdAt || new Date().toISOString(),
      updatedAt: data.updatedAt?.toDate?.()?.toISOString() || data.updatedAt
    } as Patient;
  } catch (error) {
    console.error("Error getting patient by ID:", error);
    return null;
  }
};

export const addPatient = async (data: Omit<Patient, "id">): Promise<{ id: string; patientNumber: string }> => {
  try {
    // Create complete patient data with defaults
    const patientData = {
      patientNumber: data.patientNumber,
      name: data.name || '',
      phone: data.phone || '',
      age: data.age || 0,
      gender: data.gender || 'other',
      address: data.address || '',
      openingBalance: data.openingBalance || 0,
      email: data.email || '',
      emergencyContact: data.emergencyContact || '',
      bloodGroup: data.bloodGroup || '',
      allergies: data.allergies || '',
      medicalHistory: data.medicalHistory || '',
      notes: data.notes || '',
      registrationDate: new Date().toISOString(),
      totalVisits: 0,
      totalPaid: 0,
      pendingBalance: data.openingBalance || 0,
      isActive: true,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    };

    const docRef = await addDoc(patientsRef, patientData);
    return { id: docRef.id, patientNumber: data.patientNumber };
  } catch (error) {
    console.error("Error adding patient:", error);
    throw error;
  }
};

export const updatePatient = async (id: string, data: Partial<Patient>) => {
  try {
    const patientRef = doc(db, "patients", id);
    await updateDoc(patientRef, {
      ...data,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.error("Error updating patient:", error);
    throw error;
  }
};

export const deletePatient = async (id: string) => {
  try {
    await deleteDoc(doc(db, "patients", id));
  } catch (error) {
    console.error("Error deleting patient:", error);
    throw error;
  }
};

// **FIXED: Correct getPatientStats Function**
export const getPatientStats = async (patientNumber: string) => {
  try {
    // Import services dynamically
    const { getQueueItemsByPatientNumber } = await import('./queueService');
    const { getBillsByPatientNumber } = await import('./billingService');
    
    const [queueItems, bills] = await Promise.all([
      getQueueItemsByPatientNumber(patientNumber),
      getBillsByPatientNumber(patientNumber)
    ]);
    
    // Debug log
    console.log(`Stats for ${patientNumber}:`, {
      queueItems: queueItems.map(item => ({
        fee: item.fee,
        previousPending: item.previousPending,
        amountPaid: item.amountPaid,
        status: item.status
      })),
      bills: bills.map(bill => ({
        amountPaid: bill.amountPaid
      }))
    });
    
    // CORRECT CALCULATION:
    // 1. Get patient's opening balance (from first queue item or patient record)
    let openingBalance = 0;
    if (queueItems.length > 0) {
      // Find the highest previousPending from any queue item (should be same for all)
      openingBalance = queueItems.reduce((max, q) => 
        Math.max(max, q.previousPending || 0), 0);
    }
    
    // 2. Calculate total treatment fees (only from completed treatments)
    const completedTreatments = queueItems.filter(item => 
      item.status === 'completed'
    );
    
    const totalTreatmentFees = completedTreatments.reduce(
      (sum, item) => sum + (item.fee || 0), 
      0
    );
    
    // 3. Calculate total paid from ALL sources
    const totalPaidFromQueue = queueItems.reduce(
      (sum, item) => sum + (item.amountPaid || 0), 
      0
    );
    
    const totalPaidFromBills = bills.reduce(
      (sum, bill) => sum + (bill.amountPaid || 0), 
      0
    );
    
    const totalPaid = totalPaidFromQueue + totalPaidFromBills;
    
    // 4. Calculate pending balance CORRECTLY
    const totalDue = openingBalance + totalTreatmentFees;
    const pendingBalance = totalDue - totalPaid;
    
    // 5. Count total visits
    const totalVisits = completedTreatments.length;
    
    // Find most recent visit
    const lastVisit = completedTreatments.length > 0 
      ? completedTreatments.sort((a, b) => {
          const dateA = new Date(a.treatmentEndTime || a.checkInTime || 0).getTime();
          const dateB = new Date(b.treatmentEndTime || b.checkInTime || 0).getTime();
          return dateB - dateA;
        })[0]?.treatmentEndTime || completedTreatments[0]?.checkInTime
      : undefined;
    
    return {
      totalVisits,
      totalTreatmentFees,
      totalPaid,
      pendingBalance,
      openingBalance,
      totalDue,
      lastVisit,
      queueItemsCount: queueItems.length,
      billsCount: bills.length,
      calculations: {
        formula: `(${openingBalance} + ${totalTreatmentFees}) - ${totalPaid} = ${pendingBalance}`
      }
    };
  } catch (error) {
    console.error('Error getting patient stats:', error);
    return {
      totalVisits: 0,
      totalTreatmentFees: 0,
      totalPaid: 0,
      pendingBalance: 0,
      openingBalance: 0,
      totalDue: 0,
      lastVisit: undefined,
      queueItemsCount: 0,
      billsCount: 0,
      calculations: {
        formula: 'Error in calculation'
      }
    };
  }
};

export const updatePatientWithStats = async (patientId: string) => {
  try {
    // Get patient
    const patient = await getPatientById(patientId);
    if (!patient) return null;
    
    // Get updated stats
    const stats = await getPatientStats(patient.patientNumber);
    
    // Update patient with correct stats
    const updateData = {
      totalVisits: stats.totalVisits,
      totalPaid: stats.totalPaid,
      pendingBalance: stats.pendingBalance,
      ...(stats.lastVisit && { lastVisit: stats.lastVisit }),
      updatedAt: serverTimestamp()
    };
    
    await updatePatient(patientId, updateData);
    
    // Return updated patient
    return {
      ...patient,
      ...updateData,
      openingBalance: stats.openingBalance,
      totalTreatmentFees: stats.totalTreatmentFees
    };
  } catch (error) {
    console.error('Error updating patient with stats:', error);
    throw error;
  }
};

// New function: Sync all patients in background
export const syncAllPatientsStats = async () => {
  try {
    const patients = await getAllPatients();
    const results = [];
    
    for (const patient of patients) {
      try {
        const updated = await updatePatientWithStats(patient.id);
        results.push({
          patientNumber: patient.patientNumber,
          name: patient.name,
          success: true,
          data: updated
        });
      } catch (error) {
        results.push({
          patientNumber: patient.patientNumber,
          name: patient.name,
          success: false,
          error: error.message
        });
      }
    }
    
    return results;
  } catch (error) {
    console.error('Error syncing all patients:', error);
    throw error;
  }
};

// New function: Calculate pending balance for display
export const calculatePatientPendingBalance = (patient: Patient, stats?: any) => {
  const openingBalance = patient.openingBalance || 0;
  
  if (stats) {
    return stats.pendingBalance;
  }
  
  // Fallback calculation
  const totalTreatmentFees = patient.totalVisits ? (patient.totalVisits * 100) : (patient.totalVisits * 0) ; // Approximate
  const totalPaid = patient.totalPaid || 0;
  return Math.max(0, (openingBalance + totalTreatmentFees) - totalPaid);
};